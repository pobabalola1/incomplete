import { Pipe, PipeTransform } from '@angular/core';
import { TitleCasePipe } from '@angular/common';

@Pipe({ name: 'titlecase' })
export class CustomTitleCasePipe implements PipeTransform {

    constructor(private titlecasePipe: TitleCasePipe) { }

    transform(value: string): string {
        return this.titlecasePipe.transform(value);
    }
}
