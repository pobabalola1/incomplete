import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Subject } from 'rxjs/Subject';
import { FundCategory} from '../components/call-flows/fund-category/fund-category.model';
import { FundDetail } from '../components/call-flows/fund/fund-detail.model';

@Injectable()
export class FundService {

  fundCat: FundCategory [] = [
    new FundCategory(989, 1, 'test category 1', 4, 'dt76669'),
    new FundCategory(989, 2, 'test category 2', 3, 'dt76669'),
    new FundCategory(989, 3, 'test category 3', 3, 'dt76669'),
  ];

  fundDetails: FundDetail[] = [
    new FundDetail(989, 3, 'test category 3', 101, 'test fund 111', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 3, 'test category 3', 102, 'test fund 122', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 3, 'test category 3', 103, 'test fund 123', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 2, 'test category 2', 111, 'test fund 111', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 2, 'test category 2', 112, 'test fund 122', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 2, 'test category 2', 113, 'test fund 123', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 1, 'test category 1', 121, 'test fund 121', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 1, 'test category 1', 122, 'test fund 122', true, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 1, 'test category 1', 123, 'test fund 123', false, 155, 'test fund Transfer', 'dt76669'),
    new FundDetail(989, 1, 'test category 1', 124, 'test fund 124', false, 155, 'test fund Transfer', 'dt76669')
  ];

  private fundDetailsSelectAPI = '/ivradmin/api/fund-details';
  private fundCatagorySelectAPI = '/ivradmin/api/fund-categories';

  constructor(private http: HttpClient, private router: Router) { }

  fetchDnisFundCategories(callFlowId: number): Observable<FundCategory[]> {
    const api = `${this.fundCatagorySelectAPI}/${callFlowId}`;
    console.log('api = ' + api);
    return this.http.get<FundCategory[]>(api)
        .pipe(
            tap( fd => this.log('fetch fund catagory by Call Flow ID', fd)) ,
            catchError(this.handleError('fetch fd error', []))
        );
  }

  fetchDnisFundDetails(callFlowId: number): Observable<FundDetail[]> {
    const api = `${this.fundDetailsSelectAPI}/${callFlowId}`;
    console.log('api = ' + api);
    return this.http.get<FundDetail[]>(api)
        .pipe(
            tap( fd => this.log('fetch fund details by Call Flow ID', fd)) ,
            catchError(this.handleError('fetch fd error', []))
        );
  }

  private log(message: string, obj: any) {
    console.log(message);
    console.log(obj);
  }

/**
* Handle Http operation that failed.
* Let the app continue.
* @param operation - name of the operation that failed
* @param result - optional value to return as the observable result
*/
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`, []);
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

}
