export class UpdateResponse {
    sqlSuccess: boolean;
    updateCnt: number;
    errorCode: string;
    errorMsg: string;
}
