import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { User } from '../components/login/user.model';

@Injectable()
export class UserService {
  private isUserLoggedIn;
  private username;
  constructor(private http: HttpClient, private router: Router) {
    this.isUserLoggedIn =  false;
  }

  /**
   * Temporary: Created a user model that could pull user details for authentication
   */
  users: User[] = [
    new User('dt208978' , '123', 'Sneha', 'Lagandula', 'slagandula@dstsystems.com'),
    new User('dt208937' , '123', 'Tania', 'Bandyopadhyay', 'tbandyopadhyay@dstsystems.com'),
    new User('dt03907' , '123', 'Patrick', 'Babalola', 'pbabalola@dstsystems.com'),
  ];

  login(username: string, password: string): boolean {
    let token;
    token = Math.random();

    for (const user of this.users) {
      if (user.userId === username && user.password === password) {
        this.setUserLoggedIn();
        this.setCurrentUser(user.first_name + ', ' + user.last_name);
        return true;
      } else {
        this.isUserLoggedIn = false;
        return false;
      }
    }
  }

  logout(): void {
    this.isUserLoggedIn = false;
    this.router.navigate(['']);
  }
  setUserLoggedIn() {
    this.isUserLoggedIn = true;
  }
  getUserLoggedIn() {
    return this.isUserLoggedIn;
  }
  setCurrentUser(username) {
    if (this.getUserLoggedIn()) {
      this.username = username;
    } else {
      this.isUserLoggedIn = false;
      this.username = '';

    }
  }
  getCurrentUser() {
    return this.username;
  }


/*   validateUser(username, password) {
    const data = { username, password};
      return this.http.post('/login', data ).subscribe(response => {console.log(response); });
   // return this.http.get('/ecrptadmin/login').subscribe(data => {console.log(data); });
  }
 */


}

