import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { LoginResponse } from '../components/login/loginResponse.model';
import { LoginRequest } from '../components/login/loginRequest.model';

@Injectable()
export class LoginService {
  private isUserLoggedIn;
  private username;
  private loginAPI = '/ivradmin/api/login';

  constructor(private http: Http, private router: Router) {
    this.isUserLoggedIn =  false;
  }
  /** authenticateUser - service to communicate with spring API (/api/login) for login authentication */
  authenticateUser(body): Observable<LoginResponse> {
    return this.http.post(this.loginAPI, body).map(response => {
      return response.json();
    }).catch(this.handError);
  }

  /** Error handler for login authentication */
  private handError (error: any ) {
   console.error('Login authentication error: ', error);
   return Observable.throw(error);
  }

  /** user logout */
  logout(): void {
    this.isUserLoggedIn = false;
    this.router.navigate(['']);
  }

  setUserLoggedIn(flag: boolean) {
    this.isUserLoggedIn = flag;
  }
  getUserLoggedIn() {
    return this.isUserLoggedIn;
  }
  setCurrentUser(username) {
    if (this.getUserLoggedIn()) {
      this.username = username;
    } else {
      this.isUserLoggedIn = false;
      this.username = '';
    }
  }
  getCurrentUser() {
    return this.username;
  }
}

