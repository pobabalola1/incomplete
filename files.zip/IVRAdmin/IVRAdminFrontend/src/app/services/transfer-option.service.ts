import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { TransferOption } from '../components/client-info/transfer-options/transfer-option.model';

@Injectable()
export class TransferOptionService {

    private transferOptionAPI = '/ivradmin/api/transfer-option';

    constructor(private http: HttpClient, private router: Router) {}

    getTransferOptionByCallFlowId(callFlowId: number) {
        const api = `${this.transferOptionAPI}/${callFlowId}`;
        console.log('api = ' + api);

        return this.http.get<TransferOption>(api).pipe(
            tap(_ => this.log(`fetched line of call flow id=${callFlowId}`, _)),
            catchError(this.handleError<TransferOption>(`Erorr getting line of call flow id=${callFlowId}`))
        );

    }

    private log(message: string, obj: any) {
        console.log(message);
        console.log(obj);
    }

    /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`, []);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
