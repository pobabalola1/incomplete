import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { FunctionGroup } from '../components/call-flows/function/function-group.model';
import { FunctionBusiness } from '../components/call-flows/function/function-business.model';
import { TransferNumber } from '../components/call-flows/function/transfer-number.model';
import { UpdateResponse } from './update-response.model';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class FunctionGroupService {

    private functionGroupSelectAPI = '/ivradmin/api/call-flow-function-group';
    private functionBusinessAPI = '/ivradmin/api/call-flow-business-functions';
    private transferNumberAPI = '/ivradmin/api/call-flow-transfer-numbers';
    private businessFunctionTransferNumberUpdateAPI = '/ivradmin/api/call-flow-business-function-transfer-number';

    constructor(private http: HttpClient, private router: Router) {}

    fetchAllFunctionGroups(callFlowId: number): Observable<FunctionGroup[]> {
        const api = `${this.functionGroupSelectAPI}/${callFlowId}`;
        console.log('api = ' + api);
        return this.http.get<FunctionGroup[]>(api)
            .pipe(
                tap( fgn => this.log('fetch function group names by DNIS', fgn)) ,
                catchError(this.handleError('fetch fgn error', []))
            );
    }

    fetchBusinessFunctions(callFlowId: number, functionGrpId: number): Observable<FunctionBusiness[]> {
        const api = `${this.functionBusinessAPI}/${callFlowId}/${functionGrpId}`;
        console.log('api = ' + api);
        return this.http.get<FunctionBusiness[]>(api)
            .pipe(
                tap( fn => this.log('fetch Function Business Info by DNIS and Function Group', fn)) ,
                catchError(this.handleError('fetch fn error', []))
            );
    }

    fetchTransferNumbers(callFlowId: number): Observable<TransferNumber[]> {
        const api = `${this.transferNumberAPI}/${callFlowId}`;
        console.log('api = ' + api);
        return this.http.get<TransferNumber[]>(api)
            .pipe(
                tap( fn => this.log('fetch Transfer Number for a Function by Call Flow Id', fn)) ,
                catchError(this.handleError('fetch fn error', []))
            );
    }

    updateCallFlowBusinessFunctionTransferNumber(callFlowId: number, functionId: number, transferNumId: number) {
        const api = `${this.businessFunctionTransferNumberUpdateAPI}/${callFlowId}/${functionId}/${transferNumId}`;
        console.log('api = ' + api);
        return this.http.put<UpdateResponse>(api, {})
            .pipe(
                tap( fn => this.log('Update Function Business Info by DNIS and Function Group', fn)) ,
                catchError(this.handleError('fetch fn error', []))
            );
    }

    private log(message: string, obj: any) {
        console.log(message);
        console.log(obj);
    }

    /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`, []);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
