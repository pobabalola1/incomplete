import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { LineOfBusiness } from '../components/side-nav/line-of-business.model';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class LineOfBusinessService {

    private lineOfBussinessAPI = '/ivradmin/api/data/line-of-businesses';

    private lineOfBussinessByClientIdAPI = '/ivradmin/api/data/line-of-business';

    private selectedLineOfBusiness: LineOfBusiness;

    private changeSelectedLineOfBusiness = new Subject<LineOfBusiness>();

    constructor(private http: HttpClient, private router: Router) {}

    getLineOfBusinessWithClientById(id: number) {
        const api = `${this.lineOfBussinessByClientIdAPI}/${id}`;
        console.log('api = ' + api);
        return this.http.get<LineOfBusiness>(api).pipe(
            tap(_ => this.log(`fetched line of business id=${id}`, _)),
            catchError(this.handleError<LineOfBusiness>(`Erorr getting line of business id=${id}`))
        );
    }

    fetchAllLineOFBusiness(): Observable<LineOfBusiness[]> {
        return this.http.get<LineOfBusiness[]>(this.lineOfBussinessAPI)
            .pipe(
                tap( lobs => this.log('fetch line of business', lobs)) ,
                catchError(this.handleError('fetch lob error', []))
            );
    }

    saveSelected(lineOfBusiness: LineOfBusiness) {
        this.selectedLineOfBusiness = lineOfBusiness;
        this.changeSelectedLineOfBusiness.next(lineOfBusiness);
    }

    getSelected(): LineOfBusiness {
        return this.selectedLineOfBusiness;
    }

    subscribedSelectedChange(): Observable<LineOfBusiness> {
        return this.changeSelectedLineOfBusiness.asObservable();
    }

    private log(message: string, obj: any) {
        console.log(message);
        console.log(obj);
    }

    /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`, []);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
