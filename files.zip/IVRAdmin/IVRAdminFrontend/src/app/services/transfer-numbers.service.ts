import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { TransferNumbers } from '../components/client-info/transfer-numbers/transfer-numbers.model';
import { CallTransferNumberHours } from '../components/client-info/transfer-numbers/transfer-numbers-displayHours.model';

import { Subject } from 'rxjs/Subject';

@Injectable()
export class TransferNumbersService {

    private transferNumbersByDnisAPI = '/ivradmin/api/data/asset-management-dnises-call-transfer-number';

    constructor(private http: HttpClient, private router: Router) {}

    getTransferNumbersByDnis(dnis: number) {

        console.log('transferNumbersByDnisAPI - dnis = ' + dnis);
        const api = `${this.transferNumbersByDnisAPI}/${dnis}`;
        console.log('api = ' + api);
        return this.http.get<TransferNumbers>(api).pipe(
            tap(_ => this.log(`fetched line of business id=${dnis}`, _)),
            catchError(this.handleError<TransferNumbers>(`Erorr getting Transfer Numbers dnis=${dnis}`))
        );
    }

    private log(message: string, obj: any) {
        console.log(message);
        console.log(obj);
    }

    /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
    private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`, []);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
    }
}
