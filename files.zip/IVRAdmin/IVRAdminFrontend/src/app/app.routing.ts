import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ClientInfoComponent } from './components/client-info/client-info.component';
import { LoginAuthGuard} from './authguard/login-auth.guard';
import { CallFlowsComponent } from './components/call-flows/call-flows.component';
import { RecordingManagementComponent } from './components/recording-management/recording-management.component';



const appRoutes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'ivradmin',
    component: LoginComponent
  },
  {
    path: 'dashboard',
    canActivate: [LoginAuthGuard],
    component: DashboardComponent
  },
  {
    path: 'client-info',
    canActivate: [LoginAuthGuard],
    component: ClientInfoComponent
  },
  {
    path: 'call-flows',
    canActivate: [LoginAuthGuard],
    component: CallFlowsComponent
  },
  {
    path: 'recording-management',
    canActivate: [LoginAuthGuard],
    component: RecordingManagementComponent
  }

];

export const appRouting = RouterModule.forRoot(appRoutes);
