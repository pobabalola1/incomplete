/**
 * This is a temporary model created for mocking of data for each client
 */
export class ClientInfo {
  constructor ( public client: string) {}
}
