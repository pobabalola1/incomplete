import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

// import { Dnis } from '../../side-nav/dnis.model';
// import { DNISClientService } from '../../../services/dnis-client.service';

import { CallFlow } from '../../side-nav/call-flow.model';
import { CallFlowsClientService } from '../../../services/call-flow-client.service';

import { TransferOption } from './transfer-option.model';
import { TransferOptionService } from '../../../services/transfer-option.service';

@Component({
  selector: 'app-transfer-options',
  templateUrl: './transfer-options.component.html',
  styleUrls: ['./transfer-options.component.css']
})

export class TransferOptionsComponent implements OnInit {

  selectedCallFlow: CallFlow;

  changedCallFlowSubscription: Subscription;

  transferOption: TransferOption;

  constructor( private modalService: NgbModal, private route: ActivatedRoute, private location: Location,
      private callFlowClientService: CallFlowsClientService, private transferOptionService: TransferOptionService ) {
    this.changedCallFlowSubscription = callFlowClientService.subscribedSelectedChange().subscribe(
      callFlow => {
        this.selectedCallFlow = callFlow;
        this.getTransferOption( this.selectedCallFlow );
      }
  );

  }

  closeResult: string;
  messageText = 'This is a sample of the message text. It may be (variable)' +
   'lines long or possibly even longer than that. This is probably a best practice as to message length';
   time = {hour: 13, minute: 30};  meridian = true;

   ngOnInit() {
    this.selectedCallFlow = this.callFlowClientService.getSelected();
    if (this.selectedCallFlow != null) {
      this.getTransferOption(this.selectedCallFlow);
    }
  }

  getTransferOption( callFlow: CallFlow ) {
    if (callFlow != null) {
      this.transferOptionService.getTransferOptionByCallFlowId(callFlow.callFlowId)
        .subscribe(to => { this.transferOption = to; console.log(this.transferOption); });
    }
  }

  saveEditable(value) {
    console.log('messageText: ' + value);
  }


}
