import {CodeSetValueDisplay} from './codeset-value-display.model';

export class TransferHierarchy {
    dnisId: number;
    hierarchyCvid: number;
    sequenceNumber: number;
    transferTypeHierarchy: CodeSetValueDisplay;
}
