export class ManagementDnis {
    dnisId: number;
    useBusinessHoursIndicator: boolean;
    alwaysTransferOnStopMailIndicator: boolean;
    useExternalPinValidationIndicator: boolean;
    userAuthenticationMethodCvid: number;
    accountGroupMethodCvid: number;
}
