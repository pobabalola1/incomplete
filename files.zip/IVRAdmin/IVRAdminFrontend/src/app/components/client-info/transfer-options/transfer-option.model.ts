import {ManagementDnis} from './management-dnis.model';
import {TransferHierarchy} from './transfer-hierarchy.model';

export class TransferOption {
    managementDnis: ManagementDnis;
    dnisCallTransferHierarchies: Array<TransferHierarchy>;
}
