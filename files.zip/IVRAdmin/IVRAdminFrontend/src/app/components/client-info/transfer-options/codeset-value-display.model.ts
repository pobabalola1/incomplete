export class CodeSetValueDisplay {
    id: number;
    name: string;
    abbreviatedName: string;
    descriptionText: string;
    isExpired: boolean;
}
