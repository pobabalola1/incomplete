import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { ClientInfo } from './client-info.model';
import { CallFlow } from '../side-nav/call-flow.model';
import { CallFlowsClientService } from '../../services/call-flow-client.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-client-info',
  templateUrl: './client-info.component.html',
  styleUrls: ['./client-info.component.css']
})
export class ClientInfoComponent implements OnInit, OnDestroy {

  public selectedCallFlow: CallFlow;

  changedCallFlowSubscription: Subscription;

  constructor(private route: ActivatedRoute, private location: Location, private CallFlowClientService: CallFlowsClientService ) {
    this.changedCallFlowSubscription = CallFlowClientService.subscribedSelectedChange().subscribe( callFlow => {
       this.selectedCallFlow = callFlow; });
  }

  ngOnDestroy() {
  }


  ngOnInit() {
    this.selectedCallFlow = this.CallFlowClientService.getSelected();
    if (this.selectedCallFlow != null) {
      this.getCallFlowClient(this.selectedCallFlow);
    }
  }

  getCallFlowClient(callFlow: CallFlow) {
    this.CallFlowClientService.getSelected();
  }

}
