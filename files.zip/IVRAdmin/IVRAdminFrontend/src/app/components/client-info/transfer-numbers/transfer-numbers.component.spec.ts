import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferNumbersComponent } from './transfer-numbers.component';

describe('TransferNumbersComponent', () => {
  let component: TransferNumbersComponent;
  let fixture: ComponentFixture<TransferNumbersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferNumbersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferNumbersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
