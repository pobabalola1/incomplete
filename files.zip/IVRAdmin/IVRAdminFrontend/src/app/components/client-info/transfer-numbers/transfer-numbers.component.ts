import { Component, Input, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

import { CallFlow } from '../../side-nav/call-flow.model';
import { CallFlowsClientService } from '../../../services/call-flow-client.service';

import { TransferNumbersService } from '../../../services/transfer-numbers.service';
import { TransferNumbers } from '../transfer-numbers/transfer-numbers.model';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-transfer-numbers',
  templateUrl: './transfer-numbers.component.html',
  styleUrls: ['./transfer-numbers.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TransferNumbersComponent implements OnInit {

  selectedCallFlow: CallFlow;
  changedCallFlowSubscription: Subscription;

  closeResult: string;

  messageText = 'This is a sample of the message text. It may be (variable)' +
   'lines long or possibly even longer than that. This is probably a best practice as to message length';

  removeShift = false;

  addShiftHours = false;

  transferNumbersArray: TransferNumbers;

  constructor( private modalService: NgbModal, private callFlowClientService: CallFlowsClientService,
    private transferNumbersService: TransferNumbersService ) {

      this.changedCallFlowSubscription = callFlowClientService.subscribedSelectedChange()
      .subscribe( callFlow => {
        this.selectedCallFlow = callFlow;
        this.getAllTransferNumbersByDnis(this.selectedCallFlow.callFlowId);
      }
    );
  }

  ngOnInit() {
    this.selectedCallFlow = this.callFlowClientService.getSelected();
    if (this.selectedCallFlow != null) {
      this.getAllTransferNumbersByDnis(this.selectedCallFlow.callFlowId);
    }
  }


  getAllTransferNumbersByDnis(dnis: number) {
    this.transferNumbersService.getTransferNumbersByDnis(dnis)
        .subscribe(tfns => this.transferNumbersArray = tfns);
  }

  saveEditable(value) {
    console.log('messageText: ' + value);
  }

  onRemoveShift() {
    this.removeShift = !this.removeShift;

  }

}
