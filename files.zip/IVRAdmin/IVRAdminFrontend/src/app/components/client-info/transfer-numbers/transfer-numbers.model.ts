import {CallTransferNumberHours} from './transfer-numbers-displayHours.model';

export class TransferNumbers {
    name: string;
    phoneNumber: string;
    isDefaultInd: string;
    isUseIntTransInd: string;
    openTime: string;
    closedTime: string;
    codeSetValueAbbreviatedNm: string;
    assetManagementDnisCallTransferNumberId: string;
    dnisCallTransferNumberHours: Array<CallTransferNumberHours>;
 }
