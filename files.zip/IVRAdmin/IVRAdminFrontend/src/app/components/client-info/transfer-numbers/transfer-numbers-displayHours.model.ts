export class CallTransferNumberHours {
    dateStart: string;
    dateEnd: string;
    dateStartNum: string;
    dateEndNum: string;
    timeStart: string;
    timeEnd: string;
}

