export class ClosureOverrideRecTypeModel {
    id: number;
    name: string;
    abbreviatedName: string;
    descriptionText: string;
    expired: boolean;
}
