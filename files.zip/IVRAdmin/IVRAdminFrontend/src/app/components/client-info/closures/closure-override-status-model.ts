export class ClosureOverrideStatusModel {
    id: number;
    name: string;
    abbreviatedName: string;
    descriptionText: string;
    expired: boolean;
}
