export class ClosureResponseModel {
    codeRes: string;
    textRes: string;
    isSuccess: boolean;
}
