
import {ClosureOverrideRecTypeModel} from './closure-override-recType-model';
import {ClosureOverrideStatusModel} from './closure-override-status-model';
import {ClosureOverrideIvrLanguageModel} from './closure-override-ivr-language-model';

export class ClosureOverrideModel {
    ivrRecordingId: number;
    engScriptText: string;
    altScriptText: string;
    gender: string;
    recordingTypeCvid: number;
    closureOverrideRecTypeModel: Array<ClosureOverrideRecTypeModel>;
    statusCvid: number;
    closureOverrideStatusModel: Array<ClosureOverrideStatusModel>;
    ivrLangCvid: number;
    closureOverrideIvrLanguageModel: Array<ClosureOverrideIvrLanguageModel>;
    notesText: string;
}
