import {ClosureOverrideModel} from './closure-override-model';

export class ClosureModel {
    name: string;
    closeDate: string;
    startTime: string;
    closeTime: string;
    defaultCloseDate: boolean;
    overrideTransferClosedRecordId: number;
    closureOverrideModel: Array<ClosureOverrideModel>;
    closedAllDay: boolean;
    overridedHours: boolean;
    normalBusinessHours: boolean;
    useDefaultIvr: boolean;
}
