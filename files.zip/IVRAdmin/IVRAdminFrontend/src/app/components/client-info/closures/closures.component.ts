import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';

import { CallFlow } from '../../side-nav/call-flow.model';
import { CallFlowsClientService } from '../../../services/call-flow-client.service';

import { ClosuresService } from '../../../services/closures.service';
import { ClosureModel } from '../closures/closures-model';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-closures',
  templateUrl: './closures.component.html',
  styleUrls: ['./closures.component.css']
})
export class ClosuresComponent implements OnInit {

selectedCallFlow: CallFlow;

  showUseDef: boolean;
  overrideBHour: boolean;
  editOverrideBHour: boolean;
  showEditUseDefalt: boolean;

  irstName: string;

  closureModelArray: ClosureModel;

  constructor(private closuresService: ClosuresService) {
    this.showUseDef = false;
    this.overrideBHour = false;
    this.editOverrideBHour = false;
    this.showEditUseDefalt = false;
  }

  ngOnInit() {
    this.getAllClosureByCallFlowId(1);
  }

  getAllClosureByCallFlowId(callFlowId: number) {
    this.closuresService.getClosuresCardService(callFlowId)
        .subscribe(tfns => this.closureModelArray = tfns);
  }


  /**
   * Get the lastest form details from backend. Temporarily, I assigned values to the form   for sample data
   */
  /*
  getForm() {
    this.globalDetailsForm = this.fBuilder.group({
      dnisName: '877-848-7033',
      dnisDescription: 'This is a description of the DNIS. It can be some length yet to be determined. It is editable',
      dnisGender: 'Male',
      dnisAccountGrouping: 'Fund/Account'
    });
  }
  */

  /*
  saveGlobalDetails() {
      const formModel = this.globalDetailsForm.value;
  }

  revert() {
    this.getForm();
  }
  */

  saveAddNewClosures() {
    // this.getAllClosureByCallFlowId(1);
  }

  showOverrideMessage() {
    const addAlwaysOpenIdCheckBox = document.getElementById('addAlwaysOpenId') as HTMLInputElement;
    this.showUseDef = !(addAlwaysOpenIdCheckBox.checked);

  }

  editShowOverrideMessage() {
    const editAlwaysOpenIdCheckBox = document.getElementById('editAlwaysOpenId') as HTMLInputElement;
    this.showEditUseDefalt = !(editAlwaysOpenIdCheckBox.checked);
  }

  showShifts() {
    const addBusinessHourRadio2 = document.getElementById('addBusinessHourRadio2') as HTMLInputElement;
    if ( addBusinessHourRadio2.checked === true) {
      this.overrideBHour = true;
    } else {
      this.overrideBHour = false;
    }

  }

  editShowShifts() {
    const editBusinessHourRadio2 = document.getElementById('editBusinessHourRadio2') as HTMLInputElement;
    if ( editBusinessHourRadio2.checked === true) {
      this.editOverrideBHour = true;
    } else {
      this.editOverrideBHour = false;
    }


  }
}
