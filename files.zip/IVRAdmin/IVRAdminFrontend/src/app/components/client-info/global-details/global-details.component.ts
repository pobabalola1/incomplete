import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-global-details',
  templateUrl: './global-details.component.html',
  styleUrls: ['./global-details.component.css']
})
export class GlobalDetailsComponent implements OnInit {

  globalDetailsForm: FormGroup;
  constructor(private fBuilder: FormBuilder) {
    this.getForm();
    console.log(this.globalDetailsForm.value);
   }
  ngOnInit() {
  }
  /**
   * Get the lastest form details from backend. Temporarily, I assigned values to the form   for sample data
   */
  getForm() {
    this.globalDetailsForm = this.fBuilder.group({
      dnisDescription: 'This is a description of the DNIS. It can be some length yet to be determined. It is editable',
      dnisGender: 'Male',
      dnisAccountGrouping: 'Fund/Account'
    });
  }

  saveGlobalDetails() {
      const formModel = this.globalDetailsForm.value;
  }
  revert() {
    this.getForm();
  }
}
