export class GlobalDetails {
  dnis: '';
  description: '';
  gender: '';
  portfolioAccountGrouping: '';
}
