import { CallFlow } from './call-flow.model';

export class LineOfBusinessClient {
    ivrClientId: number;
    lineOfBusinessId: number;
    fundSponsorId: number;
    ivrClientName: string;
    systemId: string;
    callFlow: CallFlow[];
 }
