import { LineOfBusinessClient } from './line-of-business-client.model';

export class LineOfBusiness {
    lineOfBusinessId: number;
    lineOfBusinessName: string;
    lineOfBusinessClients: LineOfBusinessClient[];
}
