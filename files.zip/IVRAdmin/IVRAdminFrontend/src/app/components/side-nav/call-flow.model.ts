export class CallFlow {
    callFlowId: number;
    dnisNbr: number;
    ivrClientId: number;
    ivrClientName: string;
}
