import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { LineOfBusiness } from './line-of-business.model';
import { LineOfBusinessClient } from './line-of-business-client.model';
import { LineOfBusinessService } from '../../services/line-of-business.service';
import { CallFlowsClientService } from '../../services/call-flow-client.service';
import { CallFlow } from './call-flow.model';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit, OnDestroy  {

  lineOfBusinessClients: LineOfBusinessClient[];

  selectedClient: LineOfBusinessClient;

  selectedLineOfBusiness: LineOfBusiness;

  selectedCallFlow: CallFlow;

  changedLineOfBusinessSubscription: Subscription;

  constructor(private route: ActivatedRoute, private location: Location, private lineOfBusinessService: LineOfBusinessService,
    private callFlowClientService: CallFlowsClientService) {
    this.changedLineOfBusinessSubscription = this.lineOfBusinessService.subscribedSelectedChange().subscribe(lob => {
      this.selectedLineOfBusiness = lob;
      this.getLineOfBusinessClient(lob);

      // reset selected dnis after line of business change.
      // this.selectedDnis = null;
    });
  }

  ngOnDestroy() {
    this.changedLineOfBusinessSubscription.unsubscribe();
  }


  ngOnInit() {
    this.selectedLineOfBusiness = this.lineOfBusinessService.getSelected();
    if (this.selectedLineOfBusiness != null) {
      this.getLineOfBusinessClient(this.selectedLineOfBusiness);
    }
  }

  getLineOfBusinessClient(lineOfBusiness: LineOfBusiness) {
    this.lineOfBusinessService.getLineOfBusinessWithClientById(lineOfBusiness.lineOfBusinessId)
      .subscribe(lob => { this.lineOfBusinessClients = lob.lineOfBusinessClients; });
  }

  onLineOfBusinessChange(lineOfBusiness: LineOfBusiness) {
    this.getLineOfBusinessClient(lineOfBusiness);
    this.callFlowClientService.saveSelected(null);
  }

  onClientSelect(lineOfBusinessClient: LineOfBusinessClient) {
    this.selectedClient = lineOfBusinessClient;
    // Single DNIS expected.
    this.selectedCallFlow = lineOfBusinessClient.callFlow[0];
    this.selectedCallFlow.ivrClientName = this.selectedClient.ivrClientName;
    this.callFlowClientService.saveSelected(this.selectedCallFlow);
  }

  onDnisSelect(lineOfBusinessClient: LineOfBusinessClient, callFlow: CallFlow) {
    this.selectedClient = lineOfBusinessClient;
    this.selectedCallFlow = callFlow;
    this.selectedCallFlow.ivrClientName = this.selectedClient.ivrClientName;
    this.callFlowClientService.saveSelected(this.selectedCallFlow);
  }
}
