export class LoginResponse {

  constructor(public associate: { firstName: string, lastName: string, email: string, role: string },
   public errors: [{key: string, message: string}]) { }
}

export class Associate {
    constructor ( public firstName: string, public lastName: string, public email: string, public role: string ) { }
}

export class Errors {
    constructor ( public key: string, public message: string ) { }
}
