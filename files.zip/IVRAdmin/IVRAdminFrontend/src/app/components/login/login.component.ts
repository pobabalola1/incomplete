import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';
import { Http } from '@angular/http';
import { LoginRequest } from './loginRequest.model';
import { LoginResponse } from './loginResponse.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private loginService: LoginService, private http: Http ) { }

  username: string;
  password: string;
  isValid = true;
  public auth: LoginResponse;

  ngOnInit() {
  }

  loginUser(loginEvent) {
      loginEvent.preventDefault();
      this.username = loginEvent.target.elements[0].value;
      this.password = loginEvent.target.elements[1].value;
      const body: LoginRequest = { userName: this.username, password: this.password, domain: 'wss-master' };

      this.loginService.authenticateUser(body)
      .subscribe(
        (data) => {
          if (data.associate != null) {
            this.isValid = true;
            this.loginService.setUserLoggedIn(true);
            this.loginService.setCurrentUser(data.associate.firstName + ', ' + data.associate.lastName);
            this.router.navigate(['/client-info']);
          } else {
            this.isValid = false;
            console.log(data);
            this.loginService.setUserLoggedIn(false);
            this.router.navigate(['']);
          }
      });
   }

}
