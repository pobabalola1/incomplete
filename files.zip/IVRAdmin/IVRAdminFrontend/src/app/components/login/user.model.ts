export class User {
  public userId: string;
  public password: string;  /** temporary **/
  public first_name: string;
  public last_name: string;
  public email: string;

  constructor(userid: string, password: string, first_name: string, last_name: string, email: string) {
    this.userId = userid;
    this.password = password;
    this.first_name = first_name;
    this.last_name = last_name;
    this.email = email;
  }
}
