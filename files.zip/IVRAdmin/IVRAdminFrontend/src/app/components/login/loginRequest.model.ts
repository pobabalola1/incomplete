export class LoginRequest {
  constructor(public userName: string, public password: string, public domain: string) { }
}
