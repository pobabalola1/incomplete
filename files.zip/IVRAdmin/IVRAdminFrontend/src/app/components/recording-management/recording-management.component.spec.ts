import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecordingManagementComponent } from './recording-management.component';

describe('RecordingManagementComponent', () => {
  let component: RecordingManagementComponent;
  let fixture: ComponentFixture<RecordingManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecordingManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecordingManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
