import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recording-management',
  templateUrl: './recording-management.component.html',
  styleUrls: ['./recording-management.component.css']
})
export class RecordingManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
