import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { CallFlow } from '../side-nav/call-flow.model';
import { CallFlowsClientService } from '../../services/call-flow-client.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-call-flows',
  templateUrl: './call-flows.component.html',
  styleUrls: ['./call-flows.component.css']
})
export class CallFlowsComponent implements OnInit {

  selectedCallFlow: CallFlow;

  changedCallFlowSubscription: Subscription;

  constructor(private route: ActivatedRoute, private location: Location, private callFlowClientService: CallFlowsClientService ) {
    this.changedCallFlowSubscription = callFlowClientService.subscribedSelectedChange().subscribe( callFlow => {
      this.selectedCallFlow = callFlow; });
  }

  ngOnInit() {
    this.selectedCallFlow = this.callFlowClientService.getSelected();
    if (this.selectedCallFlow != null) {
      this.getCallFlowClient(this.selectedCallFlow);
    }
  }

  getCallFlowClient(callFlow: CallFlow) {
    this.callFlowClientService.getSelected();
  }

}
