export class TransferNumber {
    callFlowId: number;
    transferNumberId: number;
    transferNumberName: string;
    lastMaintenanceId: string;
}
