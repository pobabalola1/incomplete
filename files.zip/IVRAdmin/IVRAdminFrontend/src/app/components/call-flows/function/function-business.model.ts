export class FunctionBusiness {
    callFlowId: number;
    functionId: number;
    functionName: string;
    transferNumberNm: string;
    lastMaintenanceOperatorId: string;
    functionTransferAllowed: boolean;

    constructor(callFlowId: number, functionId: number, functionName: string, transferNumberNm: string, lastMaintenanceOperatorId: string) {
        this.callFlowId = callFlowId;
        this.functionId = functionId;
        this.functionName = functionName;
        this.transferNumberNm = transferNumberNm;
        this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
      }
}
