export class FunctionGroup {
    callFlowId: number;
    functionGrpId: number;
    functionGrpName: string;
    lastMaintenanceOperatorId: string;

    constructor(callFlowId: number, functionGrpId: number, functionGrpName: string, lastMaintenanceOperatorId: string) {
        this.callFlowId = callFlowId;
        this.functionGrpId = functionGrpId;
        this.functionGrpName = functionGrpName;
        this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
      }
}
