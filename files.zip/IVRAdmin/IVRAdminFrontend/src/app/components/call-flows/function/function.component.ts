import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { FunctionGroupService } from '../../../services/function-group.service';
import { FunctionGroup } from './function-group.model';
import { FunctionBusiness } from './function-business.model';
import { TransferNumber } from './transfer-number.model';
import { CallFlow } from '../../side-nav/call-flow.model';
import { UpdateResponse } from '../../../services/update-response.model';
import { CallFlowsClientService } from '../../../services/call-flow-client.service';
import { Subscription } from 'rxjs/Subscription';
import { forEach } from '@angular/router/src/utils/collection';


@Component({
  selector: 'app-function',
  templateUrl: './function.component.html',
  styleUrls: ['./function.component.css']
})
export class FunctionComponent implements OnInit, OnDestroy {

  functionGroupNames: FunctionGroup [];

  businessFunctions: FunctionBusiness [];

  transferNumbers: TransferNumber [];

  saveFunctionGroup: FunctionGroup;

  saveFunctionGroupName: String;

  saveBusinessFunction: FunctionBusiness;

  selectedCallFlow: CallFlow;

  displayFunctionSelection: boolean;

  isFunctionNull: boolean;

  displayFunctionSelectionError: boolean;

  changedDNISSubscription: Subscription;

  transferNumberUdtResp: UpdateResponse;

  selectedTransfer: TransferNumber;

  selectedTransferName: string;

  businessFunctionError: boolean;

  transferUpdateError: boolean;

  transferUpdateSQLError: boolean;

  transferUpdateErrorCode: string;

  transferUpdateErrorMessage: string;
  // Comment goes here
  constructor(private functionGroupService: FunctionGroupService, private route: ActivatedRoute,
    private location: Location, private callFlowClientService: CallFlowsClientService ) {
    this.changedDNISSubscription = callFlowClientService.subscribedSelectedChange().subscribe( dnis => { this.selectedCallFlow = dnis;
      this.getAllFunctionGroups(this.selectedCallFlow.callFlowId);
       this.businessFunctions = null;
       this.saveFunctionGroupName = 'Select a Function Group';
       this.businessFunctionError = false;
      });
  }

  ngOnDestroy() {
    this.changedDNISSubscription.unsubscribe();
  }

  ngOnInit() {
    this.selectedCallFlow = this.callFlowClientService.getSelected();
    if (this.selectedCallFlow != null) {
      this.getDNISClient(this.selectedCallFlow);
      this.getAllFunctionGroups(this.selectedCallFlow.callFlowId);
    }
    this.selectedTransferName = 'Select a new Transfer Number';
    this.saveFunctionGroupName = 'Select a Function Group';
    this.businessFunctionError = false;
  }

  getAllFunctionGroups(callFlowId: number) {
    this.functionGroupService.fetchAllFunctionGroups(callFlowId)
    .subscribe(fgns => { this.functionGroupNames = fgns;
      this.evaluateFunctioGroup(fgns); });
  }

  evaluateFunctioGroup(fgns: FunctionGroup[]) {
    this.isFunctionNull = false;
    this.displayFunctionSelection = false;
    this.displayFunctionSelectionError = false;

    if (fgns == null) {
      this.isFunctionNull = true;
    } else {
      if (fgns.length > 0) {
        this.displayFunctionSelection = true;
      } else {
        this.displayFunctionSelectionError = true;
      }
    }
  }

  onSelect(functionGroupName: FunctionGroup) {
    this.businessFunctionError = false;
    this.transferUpdateError = false;
    this.transferUpdateSQLError = false;
    this.functionGroupService.fetchBusinessFunctions(functionGroupName.callFlowId, functionGroupName.functionGrpId)
      .subscribe(bfs => { this.businessFunctions = bfs;
        if (bfs == null) {
          this.businessFunctionError = true;
        } else {
          if (bfs.length <= 0) {
            this.businessFunctionError = true;
          }
        }
     });
    this.saveFunctionGroup = functionGroupName;
    this.saveFunctionGroupName = functionGroupName.functionGrpName;
  }

  getTransferNumbers(businessFunction: FunctionBusiness) {
    this.selectedTransfer = null;
    this.functionGroupService.fetchTransferNumbers(businessFunction.callFlowId)
    .subscribe(tns => { this.transferNumbers = tns;
     });
     this.saveBusinessFunction = businessFunction;
     if (businessFunction.transferNumberNm > '') {
      this.selectedTransferName = businessFunction.transferNumberNm;
     } else {
      this.selectedTransferName = 'Select a new Transfer Number';
     }
  }

  onSelectTransferNumber(transferNumber: TransferNumber) {
     this.selectedTransfer = transferNumber;
     if (transferNumber.transferNumberName > '') {
      this.selectedTransferName = transferNumber.transferNumberName;
     } else {
      this.selectedTransferName = 'Select a new Transfer Number';
     }
  }

  onSelectSaveTransferNumber() {
    this.transferUpdateError = false;
    this.transferUpdateSQLError = false;
    if (this.selectedTransfer != null && this.selectedTransfer.transferNumberName !== this.saveBusinessFunction.transferNumberNm) {
      this.functionGroupService.updateCallFlowBusinessFunctionTransferNumber(this.selectedTransfer.callFlowId,
        this.saveBusinessFunction.functionId, this.selectedTransfer.transferNumberId )
        .subscribe(tnur => {this.transferNumberUdtResp  = {
          sqlSuccess: tnur['sqlSuccess'],
          updateCnt: tnur['updateCnt'],
          errorCode: tnur['errorCode'],
          errorMsg: tnur['errorMsg']};
          this.validateTransferUpdate(this.transferNumberUdtResp);
      });
    }
  }

  validateTransferUpdate (updateResponse: UpdateResponse) {
    if (updateResponse == null) {
      this.transferUpdateError = true;
    } else {
      if (!updateResponse.sqlSuccess) {
        this.transferUpdateSQLError = true;
        this.transferUpdateErrorCode = this.transferNumberUdtResp.errorCode;
        this.transferUpdateErrorMessage = this.transferNumberUdtResp.errorMsg;
      }
    }
    if (!this.transferUpdateError && !this.transferUpdateSQLError) {
      this.functionGroupService.fetchBusinessFunctions(this.saveFunctionGroup.callFlowId, this.saveFunctionGroup.functionGrpId)
      .subscribe(bfs => { this.businessFunctions = bfs;
      });
    }
  }

  getDNISClient(callFlow: CallFlow) {
    this.callFlowClientService.getSelected();
  }
}
