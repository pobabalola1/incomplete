import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { CallFlow } from '../../side-nav/call-flow.model';
import { CallFlowsClientService } from '../../../services/call-flow-client.service';
import { FundService } from '../../../services/fund.service';
import { FundDetail } from '../fund/fund-detail.model';

@Component({
  selector: 'app-fund',
  templateUrl: './fund.component.html',
  styleUrls: ['./fund.component.css']
})
export class FundComponent implements OnInit, OnDestroy {

  fundDetails: FundDetail[];
  dnisId: number;
  displayFunctionSelectionError: boolean;
  selectedCallFlow: CallFlow;
  changedDNISSubscription: Subscription;
  i: number;
  fundNotInCatError: boolean;

  constructor(private fundService: FundService, private route: ActivatedRoute,
    private location: Location, private callFlowClientService: CallFlowsClientService ) {
    this.changedDNISSubscription = callFlowClientService.subscribedSelectedChange().subscribe( dnis => { this.selectedCallFlow = dnis;
      this.getFunds(this.selectedCallFlow.callFlowId);
       });
  }

  ngOnDestroy() {
    this.changedDNISSubscription.unsubscribe();
  }
  ngOnInit() {
    this.selectedCallFlow = this.callFlowClientService.getSelected();
    if (this.selectedCallFlow != null) {
      this.getFunds(this.selectedCallFlow.callFlowId);
    }
  }

  getFunds(callFlow: number) {
    this.fundService.fetchDnisFundDetails(callFlow)
    .subscribe(fd => { this.fundDetails = fd;
      this.fundNotInCatError = false;
      if (fd.length > 0) {
        for (this.i = 0; this.i < fd.length; this.i ++) {
          if (fd[this.i].ivrFundCatNm == null) {
            this.fundNotInCatError = true;
          }
        }
      }
    });
  }

}
