export class FundDetail {
    callFlowId: number;
    ivrMutualFundCategoryId: number;
    ivrFundCatNm: string;
    ivrFundCd: number;
    ivrFundNm: string;
    activityCd: boolean;
    transferNumId: number;
    transferNumNm: string;
    lastMaintenanceOperatorId: string;

    constructor(callFlowId: number, ivrMutualFundCategoryId: number, ivrFundCatNm: string, ivrFundCd: number, ivrFundNm: string,
        activityCd: boolean, transferNumId: number, transferNumNm: string, lastMaintenanceOperatorId: string) {
        this.callFlowId = callFlowId;
        this.ivrMutualFundCategoryId = ivrMutualFundCategoryId;
        this.ivrFundCatNm = ivrFundCatNm;
        this.ivrFundCd = ivrFundCd;
        this.ivrFundNm = ivrFundNm;
        this.activityCd = activityCd;
        this.transferNumId = transferNumId;
        this.transferNumNm = transferNumNm;
        this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
      }
}
