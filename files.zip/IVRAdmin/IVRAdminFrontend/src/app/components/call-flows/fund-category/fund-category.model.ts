export class FundCategory {
    dnisId: number;
    ivrMutualFundCategoryId: number;
    ivrMutualFundCategoryNm: string;
    fundCnt: number;
    lastMaintOpId: string;

    constructor(dnisId: number, ivrMutualFundCategoryId: number, ivrMutualFundCategoryNm: string, fundCnt: number, lastMaintOpId: string) {
        this.dnisId = dnisId;
        this.ivrMutualFundCategoryId = ivrMutualFundCategoryId;
        this.ivrMutualFundCategoryNm = ivrMutualFundCategoryNm;
        this.fundCnt = fundCnt;
        this.lastMaintOpId = lastMaintOpId;
      }
}
