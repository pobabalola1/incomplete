import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { CallFlow } from '../../side-nav/call-flow.model';
import { CallFlowsClientService } from '../../../services/call-flow-client.service';
import { FundCategory } from './fund-category.model';
import { FundService } from '../../../services/fund.service';

@Component({
  selector: 'app-fund-category',
  templateUrl: './fund-category.component.html',
  styleUrls: ['./fund-category.component.css']
})
export class FundCategoryComponent implements OnInit, OnDestroy {

  fundCategories: FundCategory[];
  dnisId: number;
  displayFunctionSelectionError: boolean;
  selectedCallFlow: CallFlow;
  changedDNISSubscription: Subscription;

  constructor(private fundService: FundService, private route: ActivatedRoute,
    private location: Location, private callFlowClientService: CallFlowsClientService ) {
    this.changedDNISSubscription = callFlowClientService.subscribedSelectedChange().subscribe( dnis => { this.selectedCallFlow = dnis;
      this.getFundCategories(this.selectedCallFlow.callFlowId);
       });
  }

  ngOnDestroy() {
    this.changedDNISSubscription.unsubscribe();
  }
  ngOnInit() {
    this.selectedCallFlow = this.callFlowClientService.getSelected();
    if (this.selectedCallFlow != null) {
      this.getFundCategories(this.selectedCallFlow.callFlowId);
    }
  }

  getFundCategories(callFlowId: number) {
    this.fundService.fetchDnisFundCategories(callFlowId)
    .subscribe(fcat => { this.fundCategories = fcat; });
  }
}
