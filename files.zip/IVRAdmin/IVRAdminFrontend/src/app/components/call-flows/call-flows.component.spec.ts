import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CallFlowsComponent } from './call-flows.component';

describe('CallFlowsComponent', () => {
  let component: CallFlowsComponent;
  let fixture: ComponentFixture<CallFlowsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallFlowsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallFlowsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
