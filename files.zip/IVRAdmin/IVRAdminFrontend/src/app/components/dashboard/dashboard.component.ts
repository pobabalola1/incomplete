import { Component, Input, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';

import { LineOfBusinessService } from '../../services/line-of-business.service';
import { LineOfBusiness } from '../side-nav/line-of-business.model';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {

  lineOfBusinesses: LineOfBusiness[];

  selectedLineOfBusiness: LineOfBusiness;

  selectedLineOfBusinessMessage: string;

  changedLineOfBusinessSubscription: Subscription;

  constructor(private lineOfBusinessService: LineOfBusinessService) {
  }

  ngOnInit() {
    this.getAllLineOfBusiness();
    this.selectedLineOfBusiness = this.lineOfBusinessService.getSelected();
    if (this.selectedLineOfBusiness) {
      this.selectedLineOfBusinessMessage = this.selectedLineOfBusiness.lineOfBusinessName;
    } else {
      this.selectedLineOfBusinessMessage = 'Line Of Business';
    }
  }

  getAllLineOfBusiness() {
    this.lineOfBusinessService.fetchAllLineOFBusiness()
      .subscribe(lobs => this.lineOfBusinesses = lobs);
  }

  onSelect(lob: LineOfBusiness) {
    if (lob !== this.selectedLineOfBusiness) {
      this.lineOfBusinessService.saveSelected(lob);
      this.selectedLineOfBusiness = lob;
      this.selectedLineOfBusinessMessage = lob.lineOfBusinessName;
      // this.lineOfBusinessService.saveSelected(this.selectedLineOfBusiness);
    }
  }
}
