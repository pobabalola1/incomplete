import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';

import { RouterModule, Routes} from '@angular/router';

import { LoginService } from './services/login.service';
import { LineOfBusinessService } from './services/line-of-business.service';
import { CallFlowsClientService } from './services/call-flow-client.service';
import { FunctionGroupService } from './services/function-group.service';
import { TransferOptionService } from './services/transfer-option.service';
import { ClosuresService } from './services/closures.service';

import { HttpClientModule } from '@angular/common/http';
import { LoginAuthGuard} from './authguard/login-auth.guard';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { LoginComponent } from './components/login/login.component';
import { FooterComponent } from './components/footer/footer.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { ClientInfoComponent } from './components/client-info/client-info.component';
import { GlobalDetailsComponent } from './components/client-info/global-details/global-details.component';
import { TransferNumbersComponent } from './components/client-info/transfer-numbers/transfer-numbers.component';
import { TransferOptionsComponent } from './components/client-info/transfer-options/transfer-options.component';
import { ClosuresComponent } from './components/client-info/closures/closures.component';

import { CallFlowsComponent } from './components/call-flows/call-flows.component';
import { RecordingManagementComponent } from './components/recording-management/recording-management.component';
import { CustomTitleCasePipe } from './pipes/titlecase.pipe';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InlineEditorModule } from '@qontu/ngx-inline-editor';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { appRouting } from './app.routing';
import { TitleCasePipe } from '@angular/common';
import { FunctionComponent } from './components/call-flows/function/function.component';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { FundComponent } from './components/call-flows/fund/fund.component';
import { FundCategoryComponent } from './components/call-flows/fund-category/fund-category.component';
import { FundService } from './services/fund.service';
import { CustomDualListComponent } from './components/custom-dual-list/custom-dual-list.component';
import { TransferNumbersService } from './services/transfer-numbers.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    CustomDualListComponent,
    HeaderComponent,
    FooterComponent,
    ClientInfoComponent,
    GlobalDetailsComponent,
    TransferNumbersComponent,
    ClosuresComponent,
    TransferOptionsComponent,
    CallFlowsComponent,
    CustomTitleCasePipe,
    RecordingManagementComponent,
    FunctionComponent,
    SideNavComponent,
    FundComponent,
    FundCategoryComponent
  ],
  imports: [
    appRouting,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    HttpModule,
    HttpClientModule,
    NgbModule.forRoot(),
    InlineEditorModule,
    AngularDualListBoxModule
  ],
  providers: [LoginService, LoginAuthGuard, LineOfBusinessService, TitleCasePipe,
    TransferOptionService, CallFlowsClientService, FunctionGroupService, FundService, TransferNumbersService, ClosuresService],
  bootstrap: [AppComponent]
})
export class AppModule { }


