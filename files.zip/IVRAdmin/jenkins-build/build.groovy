import com.dstsystems.scm.AntUtils
import com.dstsystems.scm.jenkins.BuildUtils
import com.dstsystems.scm.jenkins.GitUtils
import com.dstsystems.scm.ZipUtils

import groovy.io.FileType
import groovy.xml.NamespaceBuilder
import java.text.SimpleDateFormat
import java.text.FieldPosition
import groovy.time.*

def env = System.getenv();
def ant = new AntBuilder();

AntUtils.setDefaultExcludes( ant )
BuildUtils.setAnt( ant )

BuildUtils.initOutputs()
    
// Commit the outputs
BuildUtils.archiveOutputs([ ant.zipfileset( dir: '.',
                                    prefix: 'dynamic/' )
                             {
                                exclude(name: '*')
                             }
                         ])
return
