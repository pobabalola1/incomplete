import com.dstsystems.scm.jenkins.BuilderFactory
import com.dstsystems.scm.jenkins.ConfigDefaults
import com.dstsystems.scm.jenkins.configUtils
import com.dstsystems.scm.jenkins.FreestyleJobConfig
import com.dstsystems.scm.jenkins.git.GitSCMInfo
import com.dstsystems.scm.jenkins.JobConfigProperties
import com.dstsystems.scm.jenkins.PublisherFactory
import com.dstsystems.scm.jenkins.ScmFactory
import com.dstsystems.scm.jenkins.TriggerFactory
import com.dstsystems.scm.jenkins.utils
import com.dstsystems.scm.jenkins.WrapperFactory
import com.dstsystems.scm.jenkins.artifactory.ArtifactoryFactory

// Initialize the job configuration properties
def cfgProps = new JobConfigProperties( this )

// Get downstream jobs
Set jobDefs = [[jobTag: 'IVRAdmin', hasOutputs: true, viewTypeId: 1]]
Map dependsOnJobs = [:]

List downstreamJobs = cfgProps.getDownstreamJobs( 'IVRAdmin' )

// Update Arthur if necessary
cfgProps.updateBranchJobDefs( jobDefs )
cfgProps.updateDependsOnDefs( dependsOnJobs )

// Configure the job
out.println 'Configuring ' + cfgProps.jobName

def jobConfig = new FreestyleJobConfig( cfgProps )

jobConfig.projectBasedSecurity( ['Job.Read':['anonymous'],
                                 'Job.Build':['authenticated'],
                                 'Job.Workspace':['authenticated']] )

jobConfig.disabled( false )
jobConfig.jdk('java_jdk1.8')
//jobConfig.restrictWhereThisProjectCanBeRun( '' )
jobConfig.blockBuildWhenUpstreamBuilding( true )
jobConfig.sourceCodeManagement( ScmFactory.createGitSCM( cfgProps.gitInfo ) )
jobConfig.buildTriggers( [ TriggerFactory.createSCMTrigger() ] )

jobConfig.buildSteps( [ BuilderFactory.createProxyBuilder( 'Init_Tool_Environment_Template' )
                      , BuilderFactory.createProxyBuilder( 'Update_Build_Config_Template' )
                      , BuilderFactory.createProxyBuilder( 'Init_Maven_Environment_Template' )
                      , BuilderFactory.createMavenBuilder( [ pomFile: cfgProps.gitInfo.getLocalSubdirectory() + '/pom.xml'
                                                               , targets: 'verify -Dcucumber.options="--tags @manual --tags ~@ignore --dry-run" deploy'
                                                               , properties: 'newVersion=${BUILD_NUMBER}-${GIT_COMMIT}'] )                                                               
                      , BuilderFactory.createGroovyFileScriptBuilder( groovyToolName: ConfigDefaults.LATEST_GROOVY2
                                                                    , scriptFile: cfgProps.gitInfo.getLocalSubdirectory() + '/jenkins-build/build.groovy' )
                      ] )

jobConfig.buildEnvironment( [ WrapperFactory.createToolEnvBuildWrapper( [  ConfigDefaults.LATEST_GIT_HOME
                                                                         , ConfigDefaults.ARTHUR_JDBC_CONNECTOR_TOOL
                                                                         , ConfigDefaults.LATEST_GROOVY2_HOME
                                                                         , ConfigDefaults.LATEST_MAVEN_HOME
                                                                         , 'JAVA_JDK1_8_HOME'
                                                                         ] )
                          ] )

jobConfig.postbuildActions( PublisherFactory.addDownstreamTriggers( [ PublisherFactory.createGitPublisher( cfgProps.gitInfo )
                                                                   // , PublisherFactory.createCucumberReportPublisher([jsonReportDirectory: cfgProps.gitInfo.getLocalSubdirectory()+ '/target/cucumber'])
                                                                    , PublisherFactory.createExtendedEmailPublisher()]
                                                                    , downstreamJobs ) )
jobConfig.setDefaults()
jobConfig.save()

// Handle any build updates that have been made
configUtils.handleUpdatedBuilds( cfgProps,
                                 jobConfig )
                                 
return
