/*
 * FILE : LdapConstants.java
 *
 * CLASS : LdapConstants
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.config;

/**
 * Helper class with the pre-defined expected values for testing configurations.
 * @author dt63314
 *
 */
public class LdapConfigurationTestConstants
{
    static final String EXPECTED_URL      = "ldap://127.0.0.1:389/";
    static final String EXPECTED_BASE_DN  = "dc=ad,dc=dstsystems,dc=com";
    static final String EXPECTED_USERNAME = "CN=testUser,DC=ad,DC=dstsystems,DC=com";
    static final String EXPECTED_PASSWORD = "ldap_test_password";
}
