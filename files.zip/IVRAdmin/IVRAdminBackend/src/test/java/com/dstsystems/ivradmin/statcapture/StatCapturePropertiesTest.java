package com.dstsystems.ivradmin.statcapture;


import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.statcapture.config.StatCaptureProperties;

/**
 * This test verifies that we are able to recognize StatCapture configurations.
 * @author DT63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles({ "test-statCapture-config" })
public class StatCapturePropertiesTest
{
    @Autowired
    private StatCaptureProperties properties;
    
    @Configuration
    @EnableConfigurationProperties({ StatCaptureProperties.class })
    public static class Config
    {}
    
    @Test
    public void testProperties()
    {
        assertTrue( properties.isUseStatCaptureServer() );
        assertEquals( "127.1.2.3", properties.getPrimaryServer() );
        assertEquals( 1234, properties.getServerPort() );
    }
    
}
