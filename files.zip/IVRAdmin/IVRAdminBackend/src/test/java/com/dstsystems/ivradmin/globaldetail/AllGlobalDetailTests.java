/*
 * FILE : AllGlobalDetailTests.java
 *
 * CLASS : AllGlobalDetailTests
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.globaldetail;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.dstsystems.ivradmin.globaldetail.controller.GlobalDetailsControllerGetCallFlowGlobalDetailTest;

/**
 * Execute all tests in this package.
 * 
 * @author dt63314
 *
 */
@RunWith(Suite.class)
@SuiteClasses({ GlobalDetailsControllerGetCallFlowGlobalDetailTest.class })
public class AllGlobalDetailTests
{
    
}
