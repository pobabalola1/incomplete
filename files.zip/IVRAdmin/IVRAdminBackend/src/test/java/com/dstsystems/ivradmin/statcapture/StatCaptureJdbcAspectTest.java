/*
 * FILE : StatCaptureJdbcAspect.java
 *
 * CLASS : StatCaptureJdbcAspect
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.statcapture;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;

import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.statcapture.aspect.StatCaptureJdbcAspect;
import com.dstsystems.ivradmin.statcapture.config.StatCaptureConfig;
import com.dstsystems.statcapture.web.SubRequestStatistic;
import com.dstsystems.statcapture.web.WebStatisticContextImpl;

/**
 * Unit testing the implementation in {@link StatCaptureJdbcAspect} to verify content of the EV4 record(s).
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class StatCaptureJdbcAspectTest
{
    @Rule
    public MockitoRule              mockitoRule = MockitoJUnit.rule();
    @Mock
    private ProceedingJoinPoint     proceedingJoinPoint;
    @Mock
    private WebStatisticContextImpl webStatisticContextImpl;
    @Mock
    private StatCaptureConfig       statCaptureConfig;
    @Mock
    private SubRequestStatistic     subRequestStatistic;
    
    private final String mockQuery = "select * from DNIS;" ;
    private final String expectedResult = String.format("ev4_type=jdbc.query ev4_id=%s", mockQuery );
    
    @Before
    public void initJdbcAspectDependencies() throws Throwable
    {
        // Intercept calls for the Statistic Capture context.
        Mockito.when( statCaptureConfig.getWebStatisticContext() ).thenReturn( webStatisticContextImpl );
        Mockito.when( webStatisticContextImpl.createSubRequestStatistic( Mockito.anyString() ) ).thenReturn( subRequestStatistic );
        
        // We don't care about activity on the statistic record, only that it happens.
        Mockito.doNothing().when( subRequestStatistic ).startTimer();
        Mockito.doNothing().when( subRequestStatistic ).endTimer();
        
        // Handle proceedingJoinPoint invocations.
        Mockito.when( proceedingJoinPoint.getArgs() ).thenReturn( new String[] { mockQuery } );
        Mockito.when( proceedingJoinPoint.proceed() ).thenReturn( expectedResult );
        
    }
    
    @Test
    public void testAspect() throws Throwable
    {
        StatCaptureJdbcAspect aspect = new StatCaptureJdbcAspect();
        aspect.setStatCaptureConfig( statCaptureConfig );
        Object response = aspect.aroundNamedParameterJdbcTemplateQueryExecution( proceedingJoinPoint );
        
        // Verify that the aspect "created" the subRequestStatistic and called things in the right order to produce the record.
        verify( statCaptureConfig ).getWebStatisticContext();
        
        // Verify we called for the query argument.
        verify( proceedingJoinPoint ).getArgs();
        
        // Verify we start the statistic time, perform the operation, and then end the timer in that order.
        InOrder inOrder = Mockito.inOrder( subRequestStatistic,
                                           proceedingJoinPoint,
                                           subRequestStatistic );
        
        inOrder.verify( subRequestStatistic ).startTimer();
        inOrder.verify( proceedingJoinPoint ).proceed();
        inOrder.verify( subRequestStatistic ).endTimer();
        
        assertEquals( expectedResult, response.toString());
        
    }
}
