/*
 * FILE : LdapConfigurationTest.java
 *
 * CLASS : LdapConfigurationTest
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.config;

import static com.dstsystems.ivradmin.auth.config.LdapConfigurationTestConstants.*;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class LdapConfigurationTest
{
    @Autowired
    private LdapConfiguration ldapConfiguration;
    
    @Test
    public void givenExpectedUrl_whenComparedToConfigured_thenAreEqual()
    {
        assertEquals( "Expected URL does not match configured spring.ldap.urls property.",
                      EXPECTED_URL,
                      ldapConfiguration.ldapUrl );
    }
    
    @Test
    public void givenExpectedBase_whenComparedToConfigured_thenAreEqual()
    {
        assertEquals( "Expected Base Distinguished Name (DN) does not match configured spring.ldap.base property.",
                      EXPECTED_BASE_DN,
                      ldapConfiguration.ldapBaseDN );
    }
    
    @Test
    public void givenExpectedUsername_whenComparedToConfigured_thenAreEqual()
    {
        assertEquals( "Expected Username (principle) does not match configured spring.ldap.username property.",
                      EXPECTED_USERNAME,
                      ldapConfiguration.ldapPrinciple );
    }
    
    @Test
    public void givenExpectedPassword_whenComparedToConfigured_thenAreEqual()
    {
        assertEquals( "Expected Password does not match configured spring.ldap.password property.",
                      EXPECTED_PASSWORD,
                      ldapConfiguration.ldapPassword );
    }
}
