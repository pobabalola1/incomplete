/*
 * FILE : DnisTouchToneNavigationDaoTestBuildDnisNavigationFromXmlSource.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestBuildDnisNavigationFromXmlSource
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.math.BigInteger;

import javax.validation.ConstraintViolationException;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.core.domain.DnisNavigationCache;

/**
 * Exercises {@link DnisTouchToneNavigationDao#buildDnisNavigationFromXmlSource(Integer, java.io.InputStream)}. 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class DnisTouchToneNavigationDaoTestBuildDnisNavigationFromXmlSource
{
    private static final String        TEST_DNIS     = "1234";
    
    private DnisTouchToneNavigationDao dnisTouchToneNavigationDao;
    
    private Source                     xml           = new StreamSource( new ByteArrayInputStream( XML_MODEL.getBytes() ) );
    private Source                     incompleteXml = new StreamSource( new ByteArrayInputStream( INCOMPLETE_XML_MODEL.getBytes() ) );
    
    @Autowired
    public void setDnisTouchToneNavigationDao( DnisTouchToneNavigationDao dnisTouchToneNavigationDao )
    {
        this.dnisTouchToneNavigationDao = dnisTouchToneNavigationDao;
    }
    
    @Test
    public void givenXmlSourceForDnis_WhenXmlRead_ThenElementsMatchedToDnisNavigation() throws XMLStreamException
    {
        DnisNavigationCache dnisNavigationCache = dnisTouchToneNavigationDao.buildDnisNavigationFromXmlSource( TEST_DNIS,
                                                                                                               xml );
        assertNotNull( dnisNavigationCache );
        assertEquals( TEST_DNIS, dnisNavigationCache.getDnis() );
        assertEquals( new BigInteger( "12354345345" ),
                      dnisNavigationCache.getCallFlowId() );
        assertEquals( "TT", dnisNavigationCache.getInputMode() );
        assertEquals( "en-US", dnisNavigationCache.getLanguage() );
        assertEquals( "F", dnisNavigationCache.getGender() );
    }
    
    @Test
    public void givenIncompleteXmlModel_WhenXmlRead_ThenSourceReadWithoutError() throws XMLStreamException
    {
        try
        {
            dnisTouchToneNavigationDao.buildDnisNavigationFromXmlSource( TEST_DNIS,
                                                                         incompleteXml );
        }
        catch( NullPointerException npe )
        {
            /*
             * Ignore the NPE, it will be thrown by DnisNavigationCache.DnisNavigationCacheBuilder#build()
             * when the object is constructed with invalid state (null properties). This is the expected behavior.
             * We're only verifying that an incomplete XML resource doesn't cause an error.
             */
        }
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullDnis_WhenCalled_ThenParameterValidationThrowsException() throws XMLStreamException
    {
        dnisTouchToneNavigationDao.buildDnisNavigationFromXmlSource( null,
                                                                     xml );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullXmlSource_WhenCalled_ThenParameterValidationThrowsException() throws XMLStreamException
    {
        dnisTouchToneNavigationDao.buildDnisNavigationFromXmlSource( TEST_DNIS,
                                                                     null );
    }
    
    /*
     * This Navigation model includes all elements of the Dnis Navigation cache object. The builder will produce 
     * a valid object when this XML is processed. 
     */
    private static final String XML_MODEL            = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                                                       + "<navigation xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n"
                                                       + "xsi:schemaLocation=\"http://www.dstsystems.com/2018/01/mf-statemachine ./DST-Nav-Schema.xsd\">\r\n"
                                                       + "    \r\n"
                                                       + "    <callFlowId>12354345345</callFlowId>\r\n"
                                                       + "    <inputMode>TT</inputMode>\r\n"
                                                       + "    <grammarLevel>standard</grammarLevel>\r\n"
                                                       + "    <language>en-US</language>\r\n"
                                                       + "    <gender>F</gender>\r\n"
                                                       + "    <flowType>standard</flowType>\r\n"
                                                       + "    <noMatchMax>3</noMatchMax>\r\n"
                                                       + "    <noInputMax>3</noInputMax>\r\n"
                                                       + "    <defaultTransferNumber>800-219-8795</defaultTransferNumber>\r\n"
                                                       + "    <!--This will be used to transfer calls if the Call Initiation API call fails-->        \r\n"
                                                       + "    <messages/> \r\n"
                                                       + "</navigation>";
    /*
     * While this XML would never get past the schema, directly calling the parsing method with this kind of
     * XML needs to be handled gracefully. The builder will not produce a valid object when this XML is processed.
     */
    private static final String INCOMPLETE_XML_MODEL = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                                                       + "<navigation xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n"
                                                       + "xsi:schemaLocation=\"http://www.dstsystems.com/2018/01/mf-statemachine ./DST-Nav-Schema.xsd\">\r\n"
                                                       + "     Something has happened!"
                                                       + "</navigation>";
}
