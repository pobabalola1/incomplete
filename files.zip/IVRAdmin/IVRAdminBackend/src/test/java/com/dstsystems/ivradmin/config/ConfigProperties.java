/*
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2017 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * Container for the application configurations, referenced by {@link ConfigPropertiesTest}.
 * @author DT63314
 *
 */
@Component
@ConfigurationProperties
@Data
public class ConfigProperties
{
    private String               address;
    private boolean              useStatCaptureServer;
    private final ActivePlatform activePlatform = new ActivePlatform();
    
    
    @Data
    public static class ActivePlatform
    {
        private List<String> names = new ArrayList<>();
    }
}
