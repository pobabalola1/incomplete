/*
 * FILE : DnisNavigationServiceImplTestGetDnisNavigation.java
 *
 * CLASS : DnisNavigationServiceImplTestGetDnisNavigation
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.service;

import static org.junit.Assert.*;

import java.math.BigInteger;

import javax.validation.ConstraintViolationException;

import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.core.dao.DnisTouchToneNavigationDao;
import com.dstsystems.ivradmin.core.domain.DnisNavigationCache;
import com.dstsystems.ivradmin.core.exception.DaoException;
import com.dstsystems.ivradmin.core.service.impl.DnisNavigationServiceImpl;

/**
 * Exercises {@link DnisNavigationServiceImpl#getDnisNavigation(String)} for expected behaviors.
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class DnisNavigationServiceImplTestGetDnisNavigation
{
    
    private static final String        TEST_EXISTING_DNIS = "1234";
    private static final String        TEST_MISSING_DNIS  = "4321";
    
    private static DnisNavigationCache existingResult;
    
    private DnisNavigationServiceImpl  dnisNavigationServiceImpl;
    
    
    @Rule
    public MockitoRule                 mockitoRule        = MockitoJUnit.rule();
    @Mock
    private DnisTouchToneNavigationDao dnisTouchToneNavigationDao;
    
    @Autowired
    public void setDnisNavigationServiceImpl( DnisNavigationServiceImpl dnisNavigationServiceImpl )
    {
        this.dnisNavigationServiceImpl = dnisNavigationServiceImpl;
    }
    
    @BeforeClass
    public static void setupMockedResources()
    {
        existingResult = DnisNavigationCache.builder()
                                            .dnis( TEST_EXISTING_DNIS )
                                            .callFlowId( new BigInteger( "987654321" ) )
                                            .inputMode( "TT" )
                                            .language( "en-us" )
                                            .gender( "F" )
                                            .build();
    }
    
    @Test
    public void givenExistingDnis_WhenGetDnisNavigationExecutes_ThenReturnsDnisNavigationCache() throws DaoException
    {
        Mockito.doReturn( existingResult )
               .when( dnisTouchToneNavigationDao )
               .getDnisNavigationCacheFor( TEST_EXISTING_DNIS );
        
        dnisNavigationServiceImpl.setDnisTouchToneNavigationDao( dnisTouchToneNavigationDao );
        
        DnisNavigationCache result = dnisNavigationServiceImpl.getDnisNavigation( TEST_EXISTING_DNIS );
        assertNotNull( result );
        assertEquals( existingResult, result );
    }
    
    @Test( expected = DaoException.class)
    public void givenMissingDnis_WhenGetDnisNavigationExecutes_ThenReturnsNull() throws DaoException
    {
        Mockito.doThrow( DaoException.class )
               .when( dnisTouchToneNavigationDao )
               .getDnisNavigationCacheFor( TEST_MISSING_DNIS );
        
        dnisNavigationServiceImpl.setDnisTouchToneNavigationDao( dnisTouchToneNavigationDao );
        
        dnisNavigationServiceImpl.getDnisNavigation( TEST_MISSING_DNIS );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullDnis_WhenGetDnisNavigationCacheForExecutes_ThenThrowsException() throws DaoException
    {
        dnisNavigationServiceImpl.getDnisNavigation( null );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenEmptyDnis_WhenGetDnisNavigationExecutes_ThenThrowsException() throws DaoException
    {
        dnisNavigationServiceImpl.getDnisNavigation( " " );
    }
    
}
