/*
 * FILE : DnisTouchToneNavigationDaoTestGetResourceParameterErrors.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestGetResourceParameterErrors
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import java.util.Arrays;
import java.util.Collection;

import javax.validation.ConstraintViolationException;

import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;

/**
 * Exercises {@link DnisTouchToneNavigationDaoTestEvaluateElement#getXmlResource(Integer, String)} for error scenarios.
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(Parameterized.class)
public class DnisTouchToneNavigationDaoTestGetResourceParameterErrors
{
    /*
     * The ClassRule, Rule, and @SpringBootTest annotations are what enables this class to execute using the application 
     * context (for autowiring) as well as RunWith Parameterized class. From what I've seen on SO, this is the current
     * most appropriate approach.
     */
    @ClassRule
    public static final SpringClassRule SPRING_CLASS_RULE = new SpringClassRule();
    
    @Rule
    public final SpringMethodRule       springMethodRule  = new SpringMethodRule();
    
    private static final String         RESOURCE_TYPE     = "classpath:";
    private static final String         XML_DIRECTORY     = "tt-nav/xml";
    private static final String         XML_FILE_NAME     = "MF-TT-Nav-1234.xml";
    
    private DnisTouchToneNavigationDao  touchToneNavigationDao;
    
    private String                      resourceType;
    private String                      xmlDirectory;
    private String                      xmlFileName;
    
    /**
     * @param resourceType
     * @param xmlDirectory
     * @param xmlFileName
     */
    public DnisTouchToneNavigationDaoTestGetResourceParameterErrors( String resourceType,
                                                                     String xmlDirectory,
                                                                     String xmlFileName )
    {
        super();
        this.resourceType = resourceType;
        this.xmlDirectory = xmlDirectory;
        this.xmlFileName = xmlFileName;
    }
    
    @Autowired
    public void setTouchToneNavigationDao( DnisTouchToneNavigationDao touchToneNavigationDao )
    {
        this.touchToneNavigationDao = touchToneNavigationDao;
    }
    
    /*
     * Beautiful data in all the places!
     */
    @Parameters()
    public static Collection<String[]> data()
    {
        return Arrays.asList( new String[][] {
                                               // Resource type cannot be null.
                                               { null, XML_DIRECTORY,
                                                 XML_FILE_NAME },
                                               // Directory cannot be null.
                                               { RESOURCE_TYPE, null,
                                                 XML_FILE_NAME },
                                               // Filename cannot be null.
                                               { RESOURCE_TYPE, XML_DIRECTORY,
                                                 null },
                                               // Resource type cannot be empty.
                                               { " ", XML_DIRECTORY,
                                                 XML_FILE_NAME },
                                               // Directory cannot be empty.
                                               { RESOURCE_TYPE, " ",
                                                 XML_FILE_NAME },
                                               // Filename cannot be empty.
                                               { RESOURCE_TYPE, XML_DIRECTORY,
                                                 " " } } );
        
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenInvalidArgument_WhenGetResourceExecutes_ThenThrowsException()
    {
        touchToneNavigationDao.getResource( resourceType,
                                            xmlDirectory,
                                            xmlFileName );
    }
    
}
