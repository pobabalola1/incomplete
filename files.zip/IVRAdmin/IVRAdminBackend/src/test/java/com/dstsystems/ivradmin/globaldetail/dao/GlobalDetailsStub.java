/*
 * FILE : GlobalDetailsStub.java
 *
 * CLASS : GlobalDetailsStub
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.globaldetail.dao;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.exception.DaoException;
import com.dstsystems.ivradmin.dao.GlobalDetailsDao;
import com.dstsystems.ivradmin.globaldetail.domain.CallFlowGlobalDetail;

/**
 * This is a stub implementation of a GlobalDetailsDao and is only used for testing.
 * 
 * @author dt63314
 *
 */
@Repository("GlobalDetailsStub")
public class GlobalDetailsStub implements GlobalDetailsDao
{
    public static final BigInteger                             KNOWN_CALL_FLOW_ID   = new BigInteger( "123" );
    public static final BigInteger                             UNKNOWN_CALL_FLOW_ID = new BigInteger( "321" );
    
    private static final Map<BigInteger, CallFlowGlobalDetail> DATA_MOCK            = new HashMap<>();
    {
        DATA_MOCK.put( KNOWN_CALL_FLOW_ID,
                       CallFlowGlobalDetail.builder()
                                           .dnis( "2020" )
                                           .callFlowStatusCvid( new BigInteger( "137" ) )
                                           .accountGroupMethodText( "Fund/Account" )
                                           .callFlowDescription( "I have a Description!" )
                                           .build() );
    }
    
    /* (non-Javadoc)
     * @see com.dstsystems.ivradmin.dao.GlobalDetailsDao#getGlobalDetails(java.math.BigInteger)
     */
    @Override
    public CallFlowGlobalDetail getGlobalDetails( BigInteger callFlowId ) throws DaoException
    {
        CallFlowGlobalDetail result = DATA_MOCK.get( callFlowId );
        
        if( result == null )
        {
            throw new DaoException( "The call flow id [" + callFlowId.toString()
                                    + "] was not found." );
        }
        
        return result;
    }
    
}
