/*
 * FILE : DnisTouchToneNavigationDaoTestEvaluateElementParameterErrors.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestEvaluateElementParameterErrors
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import java.util.Arrays;
import java.util.Collection;

import javax.validation.ConstraintViolationException;
import javax.xml.stream.XMLStreamException;

import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;

import com.dstsystems.ivradmin.core.domain.DnisNavigationCache;
import com.dstsystems.ivradmin.core.domain.DnisNavigationCache.DnisNavigationCacheBuilder;

/**
 * Exercises {@link DnisTouchToneNavigationDaoTestEvaluateElement#getXmlResource(Integer, String)} for error scenarios.
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(Parameterized.class)
public class DnisTouchToneNavigationDaoTestEvaluateElementParameterErrors
{
    @ClassRule
    public static final SpringClassRule             SPRING_CLASS_RULE = new SpringClassRule();
    @Rule
    public final SpringMethodRule                   springMethodRule  = new SpringMethodRule();
    
    private static final String                     TEST_DNIS         = "1234";
    private static final DnisNavigationCacheBuilder TEST_BUILDER      = DnisNavigationCache.builder().dnis( TEST_DNIS );
    private static final String                     NODE_NAME         = "Mister_Node";
    private static final String                     NODE_TEXT         = "Lovely Text";
    
    private DnisTouchToneNavigationDao              touchToneNavigationDao;
    
    private DnisNavigationCacheBuilder              builder;
    private String                                  nodeName;
    private String                                  nodeText;
    
    
    /**
     * @param nodeName
     * @param nodeText
     * @param xmlFileName
     */
    public DnisTouchToneNavigationDaoTestEvaluateElementParameterErrors( DnisNavigationCacheBuilder builder,
                                                                         String nodeName,
                                                                         String nodeText )
    {
        super();
        this.builder = builder;
        this.nodeName = nodeName;
        this.nodeText = nodeText;
    }
    
    @Autowired
    public void setTouchToneNavigationDao( DnisTouchToneNavigationDao touchToneNavigationDao )
    {
        this.touchToneNavigationDao = touchToneNavigationDao;
    }
    
    /*
     * Build that fantastic data!
     */
    @Parameters(name = "{index}: builder={0} node={1} text={2}.")
    public static Collection<Object[]> data()
    {
        return Arrays.asList( new Object[][] {
                                               // Builder type cannot be null.
                                               { null, NODE_NAME, NODE_TEXT },
                                               // Node Name cannot be null.
                                               { TEST_BUILDER, null,
                                                 NODE_TEXT },
                                               // Node Text cannot be null.
                                               { TEST_BUILDER, NODE_NAME,
                                                 null },
                                               // Node Name cannot be empty.
                                               { TEST_BUILDER, "", NODE_TEXT },
                                               // Node Text cannot be empty.
                                               { TEST_BUILDER, NODE_NAME,
                                                 "" } } );
        
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenInvalidResourceType_WhenGetXmlResourceExecutes_ThenThrowsException() throws XMLStreamException
    {
        touchToneNavigationDao.evaluateElement( builder, nodeName, nodeText );
    }
    
}
