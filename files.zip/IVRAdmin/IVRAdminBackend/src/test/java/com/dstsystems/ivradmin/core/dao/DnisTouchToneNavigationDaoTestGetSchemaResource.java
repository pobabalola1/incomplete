/*
 * FILE : DnisTouchToneNavigationDaoTestGetSchemaResource.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestGetSchemaResource
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.core.config.TouchToneNavigationConfig;

/**
 * Exercises {@link DnisTouchToneNavigationDao#getSchemaResource(String)}, using the test configuration data and
 * referencing the classpath files.
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class DnisTouchToneNavigationDaoTestGetSchemaResource
{
    private static final String        RESOURCE_TYPE = "classpath:";
    
    private DnisTouchToneNavigationDao dnisTouchToneNavigationDao;
    private TouchToneNavigationConfig  touchToneNavigationConfig;
    
    @Autowired
    public void setTouchToneNavigationConfig( TouchToneNavigationConfig touchToneNavigationConfig )
    {
        this.touchToneNavigationConfig = touchToneNavigationConfig;
    }
    
    @Autowired
    public void setDnisTouchtoneNavigationDao( DnisTouchToneNavigationDao dnisTouchToneNavigationDao )
    {
        this.dnisTouchToneNavigationDao = dnisTouchToneNavigationDao;
    }
    
    @Test
    public void givenValidConfigurationData_WhenGetSchemaResource_ThenFileIsReturned() throws IOException
    {
        dnisTouchToneNavigationDao.setTouchToneNavigationConfig( touchToneNavigationConfig );
        File file = dnisTouchToneNavigationDao.getSchemaResource( RESOURCE_TYPE );
        assertNotNull( file );
        assertTrue( file.exists() );
        assertTrue( file.isFile() );
        assertEquals( touchToneNavigationConfig.getXsdFileName(),
                      file.getName() );
    }
    
    @Test(expected = IOException.class)
    public void givenInvalidConfigurationData_WhenGetSchemaResource_ThenIOExceptionIsThrown() throws IOException
    {
        TouchToneNavigationConfig touchToneNavigationConfig = new TouchToneNavigationConfig();
        touchToneNavigationConfig.setXsdDirectory( "tt-nav/xsd" );
        touchToneNavigationConfig.setXsdFileName( "invalid.xsd" );
        dnisTouchToneNavigationDao.setTouchToneNavigationConfig( touchToneNavigationConfig );
        
        dnisTouchToneNavigationDao.getSchemaResource( RESOURCE_TYPE );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullResourceType_WhenGetSchemaResourceExecutes_ThenThrowsException() throws IOException
    {
        dnisTouchToneNavigationDao.getSchemaResource( null );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenEmptyStringResourceType_WhenGetSchemaResourceExecutes_ThenThrowsException() throws IOException
    {
        dnisTouchToneNavigationDao.getSchemaResource( " " );
    }
}
