/*
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2017 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.config;


import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Test verifies that given an active profile in the application.yml (see spring.profiles.include:), we correctly pick up the specified 
 * properties in the include file. This test only runs when the ActiveProfiles is set to "test-config".
 * 
 * @author DT63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles({ "test-config" })
public class ConfigPropertiesTest
{
    
    @Configuration
    @EnableConfigurationProperties({ ConfigProperties.class })
    public static class Config
    {}
    
    @Autowired
    private ConfigProperties configProperties;
    
    @Test
    public void testGetConfigData()
    {
        assertFalse( configProperties.isUseStatCaptureServer() );
        assertEquals( "127.0.0.1", configProperties.getAddress() );
    }
    
    @Test
    public void testGetName()
    {
        List<String> names = configProperties.getActivePlatform().getNames();
        assertEquals( 3, names.size() );
        assertEquals( "DEV", names.get( 0 ) );
        assertEquals( "INT", names.get( 1 ) );
        assertEquals( "QAT", names.get( 2 ) );
    }
}
