/*
 * FILE : DnisTouchToneNavigationDaoTestGetXmlResourceParameterErrors.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestGetXmlResourceParameterErrors
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;

import javax.validation.ConstraintViolationException;

import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;

/**
 * Exercises {@link DnisTouchToneNavigationDaoTestEvaluateElement#getXmlResource(Integer, String)} for validating method argument
 * validation. This method is able to fetch any resource the application has permission to read.
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(Parameterized.class)
public class DnisTouchToneNavigationDaoTestGetXmlResourceParameterErrors
{
    @ClassRule
    public static final SpringClassRule SPRING_CLASS_RULE = new SpringClassRule();
    @Rule
    public final SpringMethodRule       springMethodRule  = new SpringMethodRule();
    
    private static final String         RESOURCE_TYPE     = "classpath:";
    private static final String         TEST_DNIS         = "1234";
    
    private DnisTouchToneNavigationDao  dnisTouchToneNavigationDao;
    
    private String                      resourceType;
    private String                      dnis;
    
    @Autowired
    public void setDnisTouchtoneNavigationDao( DnisTouchToneNavigationDao dnisTouchToneNavigationDao )
    {
        this.dnisTouchToneNavigationDao = dnisTouchToneNavigationDao;
    }
    
    /**
     * @param resourceType
     * @param xmlDirectory
     * @param xmlFileName
     */
    public DnisTouchToneNavigationDaoTestGetXmlResourceParameterErrors( String dnis,
                                                                        String resourceType )
    {
        super();
        this.resourceType = resourceType;
        this.dnis = dnis;
    }
    
    /*
     * I can see the code...
     */
    @Parameters()
    public static Collection<String[]> data()
    {
        return Arrays.asList( new String[][] {
                                               // Resource type cannot be null.
                                               { TEST_DNIS, null },
                                               // Dnis cannot be null.
                                               { null, RESOURCE_TYPE },
                                               // Resource type cannot be empty.
                                               { TEST_DNIS, " " },
                                               // Dnis cannot be empty.
                                               { " ", RESOURCE_TYPE } } );
        
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenInvalidArgument_WhenGetXmlResourceExecutes_ThenThrowsException() throws IOException
    {
        dnisTouchToneNavigationDao.getXmlResource( dnis, resourceType );
    }
    
    
}
