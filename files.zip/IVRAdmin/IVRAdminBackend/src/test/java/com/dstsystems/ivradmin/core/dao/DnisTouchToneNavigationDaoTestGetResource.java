/*
 * FILE : DnisTouchToneNavigationDaoTestGetResource.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestGetResource
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Exercises {@link DnisTouchToneNavigationDao#getResource(String, String, String)} for expected behaviors. This
 * method is able to fetch any resource the application has permission to read.
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class DnisTouchToneNavigationDaoTestGetResource
{
    private static final String        RESOURCE_TYPE = "classpath:";
    private static final String        XML_DIRECTORY = "tt-nav/xml";
    private static final String        XML_FILE_NAME = "MF-TT-Nav-1234.xml";
    
    private DnisTouchToneNavigationDao touchToneNavigationDao;
    
    @Autowired
    public void setTouchToneNavigationDao( DnisTouchToneNavigationDao touchToneNavigationDao )
    {
        this.touchToneNavigationDao = touchToneNavigationDao;
    }
    
    @Test
    public void givenValidDnis_WhenGetXmlResourceExecutes_ThenNamedResourceReturns()
    {
        Resource resource = touchToneNavigationDao.getResource( RESOURCE_TYPE,
                                                                XML_DIRECTORY,
                                                                XML_FILE_NAME );
        assertNotNull( resource );
        assertTrue( resource.exists() );
        assertEquals( resource.getFilename(), XML_FILE_NAME );
        
        try
        {
            File file = resource.getFile();
            assertNotNull( file );
            assertEquals( file.getName(), XML_FILE_NAME );
        }
        catch( Exception ex )
        {
            fail( "resource.getFile() threw the following exception: "
                  + ex.getMessage() );
        }
    }
    
}
