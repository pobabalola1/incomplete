package com.dstsystems.ivradmin.statcapture;

import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

import com.dstsystems.ivradmin.statcapture.config.StatCaptureInterceptorConfigurer;
import com.dstsystems.ivradmin.statcapture.interceptor.StatCaptureInterceptor;

/**
 * This test verifies that our StatCaptureInterceptor is configured and properly registered with the Spring interceptor registery.
 * @author DT63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class StatCaptureInterceptorConfigurerTest
{
    private StatCaptureInterceptorConfigurer configurer;
    
    @Mock
    private StatCaptureInterceptor           mockInterceptor;
    @Spy
    private InterceptorRegistry              registry;
    
    @Before
    public void setUp() throws Exception
    {
        configurer = new StatCaptureInterceptorConfigurer();
        configurer.statCaptureInterceptor( mockInterceptor );
    }
    
    @Test
    public void testAddInterceptorsInterceptorRegistry()
    {
        configurer.addInterceptors( registry );
        verify( registry ).addInterceptor( mockInterceptor );
    }
    
}
