/*
 * FILE : DnisTouchToneNavigationDaoTestValidateXmlSource.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestValidateXmlSource
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.validation.ConstraintViolationException;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.xml.sax.SAXException;

/**
 * Exercises {@link DnisTouchToneNavigationDao#buildDnisNavigationFromXmlSource(Integer, java.io.InputStream)}. 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class DnisTouchToneNavigationDaoTestValidateXmlSource
{
    private DnisTouchToneNavigationDao dnisTouchToneNavigationDao;
    
    private Source                     validXml;
    private Source                     invalidXml;
    private Source                     schema;
    
    public DnisTouchToneNavigationDaoTestValidateXmlSource()
    {
        schema = new StreamSource( new ByteArrayInputStream( SCHEMA.getBytes() ) );
        validXml = new StreamSource( new ByteArrayInputStream( XML_VALID_MODEL.getBytes() ) );
        invalidXml = new StreamSource( new ByteArrayInputStream( XML_INVALID_MODEL.getBytes() ) );
    }
    
    @Autowired
    public void setDnisTouchToneNavigationDao( DnisTouchToneNavigationDao dnisTouchToneNavigationDao )
    {
        this.dnisTouchToneNavigationDao = dnisTouchToneNavigationDao;
    }
    
    @Test
    public void givenValidXmlModel_WhenValidated_ThenValidationIsSuccessful() throws SAXException,
                                                                              IOException
    {
        dnisTouchToneNavigationDao.validateXmlSource( validXml, schema );
    }
    
    @Test(expected = SAXException.class)
    public void givenInvalidXmlModel_WhenValidated_ThenSAXExceptionIsThrown() throws SAXException,
                                                                              IOException
    {
        dnisTouchToneNavigationDao.validateXmlSource( invalidXml, schema );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullXmlSource_WhenCalled_ThenParameterValidationThrowsException() throws SAXException,
                                                                                       IOException
    {
        dnisTouchToneNavigationDao.validateXmlSource( null, schema );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullSchemaSource_WhenCalled_ThenParameterValidationThrowsException() throws SAXException,
                                                                                          IOException
    {
        dnisTouchToneNavigationDao.validateXmlSource( validXml, null );
    }
    
    /*
     * This is a portion of the larger schema.
     */
    private static final String SCHEMA            = "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n"
                                                    + "    xsi:noNamespaceSchemaLocation=\"DST-Nav-Schema.xsd\">\r\n"
                                                    + "\r\n"
                                                    + "    <xs:element name=\"navigation\">\r\n"
                                                    + "        <xs:complexType>\r\n"
                                                    + "            <xs:sequence>\r\n"
                                                    + "                <xs:element name=\"callFlowId\" type=\"xs:string\"/>\r\n"
                                                    + "                <xs:element name=\"inputMode\">\r\n"
                                                    + "                    <xs:simpleType>\r\n"
                                                    + "                        <xs:restriction base=\"xs:string\">\r\n"
                                                    + "                            <xs:pattern value=\"TT|SR\"/>\r\n"
                                                    + "                        </xs:restriction>\r\n"
                                                    + "                    </xs:simpleType>\r\n"
                                                    + "                </xs:element>\r\n"
                                                    + "                <xs:element name=\"language\" type=\"xs:string\" fixed=\"en-US\"/>\r\n"
                                                    + "                <xs:element name=\"gender\">\r\n"
                                                    + "                    <xs:simpleType>\r\n"
                                                    + "                        <xs:restriction base=\"xs:string\">\r\n"
                                                    + "                            <xs:pattern value=\"M|F\"/>\r\n"
                                                    + "                        </xs:restriction>\r\n"
                                                    + "                    </xs:simpleType>\r\n"
                                                    + "                </xs:element>\r\n"
                                                    + "                <xs:element name=\"defaultTransferNumber\" type=\"xs:string\"/>\r\n"
                                                    + "           </xs:sequence>\r\n"
                                                    + "      </xs:complexType>\r\n"
                                                    + "   </xs:element>\r\n"
                                                    + "</xs:schema>";
    /*
     * This Navigation model is consistent with the test schema.
     */
    private static final String XML_VALID_MODEL   = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                                                    + "<navigation xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n"
                                                    + "xsi:schemaLocation=\"http://www.dstsystems.com/2018/01/mf-statemachine ./DST-Nav-Schema.xsd\">\r\n"
                                                    + "    \r\n"
                                                    + "    <callFlowId>12354345345</callFlowId>\r\n"
                                                    + "    <inputMode>TT</inputMode>\r\n"
                                                    + "    <language>en-US</language>\r\n"
                                                    + "    <gender>F</gender>\r\n"
                                                    + "    <defaultTransferNumber>800-219-8795</defaultTransferNumber>\r\n"
                                                    + "    <!--This will be used to transfer calls if the Call Initiation API call fails-->\r\n"
                                                    + "</navigation>";
    
    /*
     * This Navigation model is not consistent with the test schema, and should throw a SAX exception.
     */
    private static final String XML_INVALID_MODEL = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
                                                    + "<navigation xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n"
                                                    + "xsi:schemaLocation=\"http://www.dstsystems.com/2018/01/mf-statemachine ./DST-Nav-Schema.xsd\">\r\n"
                                                    + "    \r\n"
                                                    //+ "    <callFlowId>12354345345</callFlowId>\r\n" << This must be in XML to be valid.
                                                    + "    <inputMode>TT</inputMode>\r\n"
                                                    + "    <language>en-US</language>\r\n"
                                                    + "    <gender>F</gender>\r\n"
                                                    + "    <defaultTransferNumber>800-219-8795</defaultTransferNumber>\r\n"
                                                    + "    <!--This will be used to transfer calls if the Call Initiation API call fails-->\r\n"
                                                    + "</navigation>";
}
