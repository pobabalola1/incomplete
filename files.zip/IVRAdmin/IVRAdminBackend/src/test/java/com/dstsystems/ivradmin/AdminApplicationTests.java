/*
 * FILE : AdminApplicationTests.java
 *
 * CLASS : AdminApplicationTests
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.dstsystems.ivradmin.auth.config.AllAuthTests;
import com.dstsystems.ivradmin.config.AllConfigTests;
import com.dstsystems.ivradmin.core.AllCoreTests;
import com.dstsystems.ivradmin.globaldetail.AllGlobalDetailTests;
import com.dstsystems.ivradmin.statcapture.AllStatCaptureTests;

@RunWith(Suite.class)
@SuiteClasses({ AllCoreTests.class, AllGlobalDetailTests.class,
                AllAuthTests.class, AllConfigTests.class,
                AllStatCaptureTests.class })
public class AdminApplicationTests
{
    
    
}
