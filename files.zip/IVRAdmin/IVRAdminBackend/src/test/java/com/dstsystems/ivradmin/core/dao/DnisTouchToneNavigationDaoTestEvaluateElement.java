/*
 * FILE : DnisTouchToneNavigationDaoTestEvaluateElement.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestEvaluateElement
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import static org.mockito.Mockito.*;

import java.math.BigInteger;

import javax.xml.stream.XMLStreamException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.core.domain.DnisNavigationCache.DnisNavigationCacheBuilder;

/**
 * Exercising the switch cases of {@link DnisTouchToneNavigationDao#evaluateElement(DnisNavigationCacheBuilder, String, String)}. 
 * Because the method only routes the request to the {@link DnisNavigationCacheBuilder} method for that property,
 * we validate functionality by ensuring that when a given Element name is passed in that the expected
 * builder method was invoked and no other method (which may suggest a missing break statement).
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class DnisTouchToneNavigationDaoTestEvaluateElement
{
    @Mock
    private DnisNavigationCacheBuilder callFlowTouchToneBuilder;
    
    @Rule
    public MockitoRule                 mockitoRule            = MockitoJUnit.rule();
    
    private DnisTouchToneNavigationDao touchToneNavigationDao = new DnisTouchToneNavigationDao();
    
    private static final String        TEST_CALL_FLOW_ID_TEXT = "12345641";
    private static final BigInteger    TEST_CALL_FLOW_ID      = new BigInteger( TEST_CALL_FLOW_ID_TEXT );
    private static final String        TEST_INPUT_MODE        = "TT";
    private static final String        TEST_LANGUAGE          = "en-US";
    private static final String        TEST_GENDER            = "F";
    
    @Before
    public void beforeTest()
    {
        // Intercept calls to builder methods to verify they were called or not called.
        Mockito.doReturn( callFlowTouchToneBuilder )
               .when( callFlowTouchToneBuilder )
               .callFlowId( TEST_CALL_FLOW_ID );
        Mockito.doReturn( callFlowTouchToneBuilder )
               .when( callFlowTouchToneBuilder )
               .inputMode( TEST_INPUT_MODE );
        Mockito.doReturn( callFlowTouchToneBuilder )
               .when( callFlowTouchToneBuilder )
               .language( TEST_LANGUAGE );
        Mockito.doReturn( callFlowTouchToneBuilder )
               .when( callFlowTouchToneBuilder )
               .gender( TEST_GENDER );
    }
    
    @Test
    public void givenCallFlowIdElement_WhenEvaluated_ThenBuilderSavesCallFlowId() throws XMLStreamException
    {
        touchToneNavigationDao.evaluateElement( callFlowTouchToneBuilder,
                                                DnisTouchToneNavigationDao.CALL_FLOW_ID_ELEMENT,
                                                TEST_CALL_FLOW_ID_TEXT );
        verify( callFlowTouchToneBuilder ).callFlowId( TEST_CALL_FLOW_ID );
        
        // Did not call...
        verify( callFlowTouchToneBuilder,
                never() ).inputMode( Mockito.anyString() );
        verify( callFlowTouchToneBuilder,
                never() ).language( Mockito.anyString() );
        verify( callFlowTouchToneBuilder,
                never() ).gender( Mockito.anyString() );
        verify( callFlowTouchToneBuilder, never() ).build();
    }
    
    @Test
    public void givenInputMode_WhenEvaluated_ThenBuilderSavesInputMode() throws XMLStreamException
    {
        touchToneNavigationDao.evaluateElement( callFlowTouchToneBuilder,
                                                DnisTouchToneNavigationDao.INPUT_MODE_ELEMENT,
                                                TEST_INPUT_MODE );
        verify( callFlowTouchToneBuilder ).inputMode( TEST_INPUT_MODE );
        
        // Did not call...
        verify( callFlowTouchToneBuilder,
                never() ).callFlowId( Mockito.any( BigInteger.class ) );
        verify( callFlowTouchToneBuilder,
                never() ).language( Mockito.anyString() );
        verify( callFlowTouchToneBuilder,
                never() ).gender( Mockito.anyString() );
        verify( callFlowTouchToneBuilder, never() ).build();
    }
    
    @Test
    public void givenLanguage_WhenEvaluated_ThenBuilderSavesLanguage() throws XMLStreamException
    {
        touchToneNavigationDao.evaluateElement( callFlowTouchToneBuilder,
                                                DnisTouchToneNavigationDao.LANGUAGE_ELEMENT,
                                                TEST_LANGUAGE );
        verify( callFlowTouchToneBuilder ).language( TEST_LANGUAGE );
        
        // Did not call...
        verify( callFlowTouchToneBuilder,
                never() ).callFlowId( Mockito.any( BigInteger.class ) );
        verify( callFlowTouchToneBuilder,
                never() ).inputMode( Mockito.anyString() );
        verify( callFlowTouchToneBuilder,
                never() ).gender( Mockito.anyString() );
        verify( callFlowTouchToneBuilder, never() ).build();
    }
    
    @Test
    public void givenGender_WhenEvaluated_ThenBuilderSavesGender() throws XMLStreamException
    {
        touchToneNavigationDao.evaluateElement( callFlowTouchToneBuilder,
                                                DnisTouchToneNavigationDao.GENDER_ELEMENT,
                                                TEST_GENDER );
        verify( callFlowTouchToneBuilder ).gender( TEST_GENDER );
        
        // Did not call...
        verify( callFlowTouchToneBuilder,
                never() ).callFlowId( Mockito.any( BigInteger.class ) );
        verify( callFlowTouchToneBuilder,
                never() ).inputMode( Mockito.anyString() );
        verify( callFlowTouchToneBuilder,
                never() ).language( Mockito.anyString() );
        verify( callFlowTouchToneBuilder, never() ).build();
    }
    
    @Test
    public void givenUnknownElement_WhenEvaluated_ThenBuilderIsNotInvoked() throws XMLStreamException
    {
        touchToneNavigationDao.evaluateElement( callFlowTouchToneBuilder,
                                                DnisTouchToneNavigationDao.FINAL_READ_ELEMENT,
                                                "bogus" );
        
        Mockito.verifyZeroInteractions( callFlowTouchToneBuilder );
    }
    
    @Test(expected = XMLStreamException.class)
    public void givenNonNumericCallFlowId_WhenEvaluated_ThenExceptionIsThrown() throws XMLStreamException
    {
        touchToneNavigationDao.evaluateElement( callFlowTouchToneBuilder,
                                                DnisTouchToneNavigationDao.CALL_FLOW_ID_ELEMENT,
                                                "123.4" );
    }
}
