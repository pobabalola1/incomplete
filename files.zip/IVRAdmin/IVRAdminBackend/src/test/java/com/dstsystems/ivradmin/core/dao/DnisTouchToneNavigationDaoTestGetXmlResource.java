/*
 * FILE : DnisTouchToneNavigationDaoTestGetXmlResource.java
 *
 * CLASS : DnisTouchToneNavigationDaoTestGetXmlResource
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.core.config.TouchToneNavigationConfig;

/**
 * Exercises {@link DnisTouchToneNavigationDaoTestEvaluateElement#getXmlResource(Integer, String)} for expected behaviors. This
 * method is able to fetch any resource the application has permission to read.
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class DnisTouchToneNavigationDaoTestGetXmlResource
{
    
    private static final String        RESOURCE_TYPE     = "classpath:";
    private static final String        TEST_DNIS_VALID   = "1234";
    private static final String        TEST_DNIS_INVALID = "ABC1234";
    
    private DnisTouchToneNavigationDao dnisTouchToneNavigationDao;
    private TouchToneNavigationConfig  touchToneNavigationConfig;
    
    @Autowired
    public void setTouchToneNavigationConfig( TouchToneNavigationConfig touchToneNavigationConfig )
    {
        this.touchToneNavigationConfig = touchToneNavigationConfig;
    }
    
    @Autowired
    public void setDnisTouchtoneNavigationDao( DnisTouchToneNavigationDao dnisTouchToneNavigationDao )
    {
        this.dnisTouchToneNavigationDao = dnisTouchToneNavigationDao;
    }
    
    @Test
    public void givenValidConfigurationData_WhenGetXmlResource_ThenFileIsReturned() throws IOException
    {
        dnisTouchToneNavigationDao.setTouchToneNavigationConfig( touchToneNavigationConfig );
        File file = dnisTouchToneNavigationDao.getXmlResource( TEST_DNIS_VALID,
                                                               RESOURCE_TYPE );
        assertNotNull( file );
        assertTrue( file.exists() );
        assertTrue( file.isFile() );
        assertEquals( touchToneNavigationConfig.getFileFor( TEST_DNIS_VALID ),
                      file.getName() );
    }
    
    @Test(expected = IOException.class)
    public void givenInvalidConfigurationData_WhenGetXmlResource_ThenIOExceptionIsThrown() throws IOException
    {
        TouchToneNavigationConfig touchToneNavigationConfig = new TouchToneNavigationConfig();
        touchToneNavigationConfig.setXmlDirectory( "tt-nav/xml" );
        touchToneNavigationConfig.setXmlFilePattern( "invalid-%DNIS%.xml" );
        dnisTouchToneNavigationDao.setTouchToneNavigationConfig( touchToneNavigationConfig );
        
        dnisTouchToneNavigationDao.getXmlResource( TEST_DNIS_VALID,
                                                   RESOURCE_TYPE );
    }
    
    @Test(expected = IOException.class)
    public void givenInvalidDnis_WhenGetXmlResource_ThenIOExceptionIsThrown() throws IOException
    {
        dnisTouchToneNavigationDao.setTouchToneNavigationConfig( touchToneNavigationConfig );
        dnisTouchToneNavigationDao.getXmlResource( TEST_DNIS_INVALID,
                                                   RESOURCE_TYPE );
    }
    
    
}
