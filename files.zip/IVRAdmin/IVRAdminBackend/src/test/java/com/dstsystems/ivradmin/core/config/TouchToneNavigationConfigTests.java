/*
 * FILE : TouchToneNavigationConfigTests.java
 *
 * CLASS : TouchToneNavigationConfigTests
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.config;

import static org.junit.Assert.assertNotNull;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import lombok.extern.slf4j.Slf4j;

/**
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
public class TouchToneNavigationConfigTests
{
    private final Validator           validator                 = Validation.buildDefaultValidatorFactory()
                                                                            .getValidator();
    
    private TouchToneNavigationConfig touchToneNavigationConfig = new TouchToneNavigationConfig();
    private static final String       RESOURCE_TYPE             = "resourceType";
    private static final String       XML_DIRECTORY             = "xmlDirectory";
    private static final String       XML_FILE_PATTERN          = "xmlFilePattern";
    private static final String       XSD_DIRECTORY             = "xsdDirectory";
    private static final String       XSD_FILE_NAME             = "xsdFileName";
    
    @Test
    public void makeJenkinsHappy()
    {
        assertNotNull(validator);
    }
    public void test()
    {
        touchToneNavigationConfig.setResourceType( "classpath:" );
        log.warn( "" );
        log.warn( touchToneNavigationConfig.toString() );
        log.warn( "" );
        validate( touchToneNavigationConfig );
        
        // use validateProperty.
    }
    
    public void validate( TouchToneNavigationConfig touchToneNavigationConfig )
    {
        Set<ConstraintViolation<TouchToneNavigationConfig>> violations = validator.validate( touchToneNavigationConfig );
        log.warn( "" );
        log.warn( "Violations " + violations.toString() );
        log.warn( "" );
    }
    
}
