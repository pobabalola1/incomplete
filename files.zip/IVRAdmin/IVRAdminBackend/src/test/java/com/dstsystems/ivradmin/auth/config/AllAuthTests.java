/*
 * FILE     :  AllAuthTests.java
 *
 * CLASS    :  AllAuthTests
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and
 * maintained by DST Systems, Inc., are proprietary in nature and as such
 * are confidential.  Any unauthorized use or disclosure of such information
 * may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc.
 * All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.config;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * Runs all tests in this package.
 * 
 * @author dt63314
 *
 */
@RunWith(Suite.class)
@SuiteClasses({ LdapConfigurationTest.class })
public class AllAuthTests
{
    
}
