/*
 * FILE : GlobalDetailsControllerGetCallFlowGlobalDetailTest.java
 *
 * CLASS : GlobalDetailsControllerGetCallFlowGlobalDetailTest
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.globaldetail.controller;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintViolationException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dstsystems.ivradmin.core.domain.ErrorBean;
import com.dstsystems.ivradmin.dao.GlobalDetailsDao;
import com.dstsystems.ivradmin.globaldetail.dao.GlobalDetailsStub;
import com.dstsystems.ivradmin.globaldetail.domain.CallFlowGlobalDetail;

/**
 * Exercises {@link GlobalDetailsController#getCallFlowGlobalDetail(java.math.BigInteger, List)} for expected behaviors.
 * 
 * @author dt63314
 *
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class GlobalDetailsControllerGetCallFlowGlobalDetailTest
{
    private GlobalDetailsController globalDetailsController;
    private GlobalDetailsDao        globalDetailsDao;
    private final List<ErrorBean>   errors = new ArrayList<>();
    
    @Autowired
    public void setGlobalDetailsController( GlobalDetailsController globalDetailsController )
    {
        this.globalDetailsController = globalDetailsController;
    }
    
    @Autowired
    @Qualifier("GlobalDetailsStub")
    public void setMockGlobalDetailsDao( GlobalDetailsDao globalDetailsDao )
    {
        this.globalDetailsDao = globalDetailsDao;
    }
    
    @Before
    public void clearErrors()
    {
        errors.clear();
    }
    
    @Test
    public void givenKnownCallFlowId_WhenGetCallFlowGlobalDetailExecutes_ThenClientInformationIsReturned()
    {
        globalDetailsController.setGlobalDetails( globalDetailsDao );
        
        CallFlowGlobalDetail result = globalDetailsController.getCallFlowGlobalDetail( GlobalDetailsStub.KNOWN_CALL_FLOW_ID,
                                                                                       errors );
        
        assertNotNull( result );
        assertTrue( errors.isEmpty() );
    }
    
    @Test
    public void givenUnknownCallFlowId_WhenGetCallFlowGlobalDetailExecutes_ThenErrorsIsNotEmpty()
    {
        globalDetailsController.setGlobalDetails( globalDetailsDao );
        
        CallFlowGlobalDetail result = globalDetailsController.getCallFlowGlobalDetail( GlobalDetailsStub.UNKNOWN_CALL_FLOW_ID,
                                                                                       errors );
        
        assertNull( result );
        assertFalse( errors.isEmpty() );
        assertEquals( 1, errors.size() );
        assertEquals( GlobalDetailsController.DAO_ERROR_1,
                      errors.get( 0 )
                            .getKey() );
        assertFalse( errors.get( 0 )
                           .getMessage()
                           .isEmpty() );
        
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullCallFlowId_WhenGetCallFlowGlobalDetailExecutes_ThenThrowsException()
    {
        globalDetailsController.getCallFlowGlobalDetail( null, errors );
    }
    
    @Test(expected = ConstraintViolationException.class)
    public void givenNullErrors_WhenGetCallFlowGlobalDetailExecutes_ThenThrowsException()
    {
        globalDetailsController.getCallFlowGlobalDetail( GlobalDetailsStub.KNOWN_CALL_FLOW_ID,
                                                         null );
    }
    
}
