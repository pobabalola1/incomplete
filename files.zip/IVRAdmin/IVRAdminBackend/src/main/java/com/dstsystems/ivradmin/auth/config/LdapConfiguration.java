/*
 * FILE : LdapConfiguration.java
 *
 * CLASS : LdapConfiguration
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.DirContextSource;

import lombok.extern.slf4j.Slf4j;


@Configuration
@Slf4j
public class LdapConfiguration
{
    
    @Value("${spring.ldap.urls}")
    String ldapUrl;
    @Value("${spring.ldap.base}")
    String ldapBaseDN;
    @Value("${spring.ldap.username}")
    String ldapPrinciple;
    @Value("${spring.ldap.password}")
    String ldapPassword;
    
    /**
     * Builds an LDAP context that may be used for authenticating and/or
     * authorizing individuals.
     * 
     * @return
     */
    @Bean
    public ContextSource buildContext()
    {
        
        DirContextSource context = new DirContextSource();
        
        context.setUrl( ldapUrl );
        context.setBase( ldapBaseDN );
        context.setUserDn( ldapPrinciple );
        context.setPassword( ldapPassword );
        context.afterPropertiesSet();
        
        log.debug( "Building the DirContextSource." );
        return context;
    }
    
    /**
     * Returns an LdapTemplate for the wss-master domain.
     * 
     * @return
     * @throws Exception
     */
    @Bean(name = "wss-master")
    public LdapTemplate getLdapTemplate() throws Exception
    {
        
        LdapTemplate ldapTemplate = new LdapTemplate( buildContext() );
        
        ldapTemplate.setIgnorePartialResultException( true );
        ldapTemplate.afterPropertiesSet();
        
        log.debug( "Building the LdapTemplate and Context." );
        return ldapTemplate;
    }
    
    /**
     * Returns the distinguished name for the given domain. Returns an empty
     * string if the domain is not recognized.
     * 
     * @param domain
     * @return
     */
    public static String getBaseDNFor( String domain )
    {
        
        switch( domain )
        {
            case "wss-master":
                return "@ad.dstsystems.com";
            default:
                break;
        }
        return "";
    }
	
}
