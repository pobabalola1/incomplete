package com.dstsystems.ivradmin.transferoption.domain;

import com.dstsystems.ivradmin.core.domain.CodeSetValueDisplay;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TransferHierarchy 
{
	private Integer                callFlowId;
	private Integer                hierarchyCvid;
	private Integer                sequenceNumber;
	private CodeSetValueDisplay    transferTypeHierarchy;
		
}
