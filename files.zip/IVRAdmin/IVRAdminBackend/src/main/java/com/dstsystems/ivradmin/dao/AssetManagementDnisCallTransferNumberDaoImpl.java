package com.dstsystems.ivradmin.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.AssetManagementDnisCallTransferNumber;
import com.dstsystems.ivradmin.domain.mapper.AssetManagementDnisCallTransferNumberRowMapper;

@Repository
public class AssetManagementDnisCallTransferNumberDaoImpl extends BaseJdbcDAO {

	private static final String DNIS_ID = "DNIS_ID";//PK FK
	private static final String CODE_SET_ID = "CODE_SET_ID";//PK FK
	
	private static final StringBuilder GET_ALL = new StringBuilder()
			.append(" select     AMDCTN.DNIS_ID, AMDCTN.ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_NUMBER_ID, AMDCTN.LAST_MAINTENANCE_TIMESTAMP, "
					          + "AMDCTN.LAST_MAINTENANCE_ID, AMDCTN.PHONE_NUMBER, AMDCTN.DESCRIPTION_TEXT, AMDCTN.DEFAULT_INDICATOR ")
			.append(" from       ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_NUMBER AMDCTN ");
	
	private final static Logger     LOG = LoggerFactory.getLogger( AssetManagementDnisCallTransferNumberDaoImpl.class );
	
	public List< AssetManagementDnisCallTransferNumber > getAll()
    {
    	List< AssetManagementDnisCallTransferNumber > assetManagementDnisCallTransferNumber = null; 
    	try 
    	{
    		assetManagementDnisCallTransferNumber = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new AssetManagementDnisCallTransferNumberRowMapper() );
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return assetManagementDnisCallTransferNumber;
    }
	
}
