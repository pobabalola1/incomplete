/*
 * FILE : LoginResponse.java
 *
 * CLASS : LoginResponse
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.domain;

import java.util.List;

import com.dstsystems.ivradmin.core.domain.ErrorBean;

public class LoginResponse
{
    private Associate       associate;
    private List<ErrorBean> errors;
    
    public LoginResponse()
    {}
    
    /**
     * @return the associate
     */
    public Associate getAssociate()
    {
        
        return associate;
    }
    
    /**
     * @param associate
     *            the associate to set
     */
    public void setAssociate( Associate associate )
    {
        
        this.associate = associate;
    }
    
    /**
     * @return the errors
     */
    public List<ErrorBean> getErrors()
    {
        
        return errors;
    }
    
    /**
     * @param errors
     *            the errors to set
     */
    public void setErrors( List<ErrorBean> errors )
    {
        
        this.errors = errors;
    }
    
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        
        return "LoginResponse [associate=" + associate + ", errors=" + errors
               + "]";
    }
}
