package com.dstsystems.ivradmin.callflowfunction.domain;

public class CallFlowTransferNumber
{
    private Integer callFlowId;
    private Integer transferNumberId;
    private String  transferNumberName;
    private String  lastMaintenanceId;
    
    /**
     * @return the callFlowId
     */
    public Integer getCallFlowId()
    {
        return callFlowId;
    }
    
    /**
     * @param callFlowId the callFlowId to set
     */
    public void setCallFlowId( Integer callFlowId )
    {
        this.callFlowId = callFlowId;
    }
    
    /**
     * @return the transferNumberId
     */
    public Integer getTransferNumberId()
    {
        return transferNumberId;
    }
    
    /**
     * @param transferNumberId the transferNumberId to set
     */
    public void setTransferNumberId( Integer transferNumberId )
    {
        this.transferNumberId = transferNumberId;
    }
    
    /**
     * @return the transferNumberName
     */
    public String getTransferNumberName()
    {
        return transferNumberName;
    }
    
    /**
     * @param transferNumberName the transferNumberName to set
     */
    public void setTransferNumberName( String transferNumberName )
    {
        this.transferNumberName = transferNumberName;
    }
    
    /**
     * @return the lastMaintenanceId
     */
    public String getLastMaintenanceId()
    {
        return lastMaintenanceId;
    }
    
    /**
     * @param lastMaintenanceId the lastMaintenanceId to set
     */
    public void setLastMaintenanceId( String lastMaintenanceId )
    {
        this.lastMaintenanceId = lastMaintenanceId;
    }
    
}
