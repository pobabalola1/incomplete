package com.dstsystems.ivradmin.callflowfunction.dao;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowBusinessFunction;
import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowFunctionGroup;
import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowTransferNumber;
import com.dstsystems.ivradmin.callflowfunction.domain.mapper.CallFlowBusinessFunctionRowMapper;
import com.dstsystems.ivradmin.callflowfunction.domain.mapper.CallFlowFunctionGroupRowMapper;
import com.dstsystems.ivradmin.callflowfunction.domain.mapper.CallFlowTransferNumbersRowMapper;
import com.dstsystems.ivradmin.core.config.GlobalConfig;
import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.UpdateResponse;
import com.dstsystems.ivradmin.session.domain.AdminSessionAttributes;
import com.dstsystems.ivradmin.session.service.AdminSessionService;

@Repository
public class CallFlowFunctionDaoImpl extends BaseJdbcDAO
{
    private GlobalConfig               globalConfig;
    private AdminSessionAttributes     sessionAttributes;
    private static final String        CALL_FLOW_ID                                          = "CALL_FLOW_ID";                                                                                                                                                                                         // Primary Key
    private static final String        FUNCTION_GROUP_ID                                     = "FUNCTION_GROUP_ID";
    private static final String        FUNCTION_LVL_STATUS                                   = "FUNCTION_LVL_STATUS";
    private static final String        CALL_FLOW_STATUS_PILOT                                = "CALL_FLOW_STATUS_PILOT";                                                                                                                                                                               // Primary Key
    private static final String        CALL_FLOW_TRANSFER_NUMBER_ID                          = "CALL_FLOW_TRANSFER_NUMBER_ID";
    private static final String        FUNCTION_ID                                           = "FUNCTION_ID";
    private static final String        LAST_MAINTENANCE_ID                                   = "LAST_MAINTENANCE_ID";
    private static final String        DEFAULT_IND                                           = "DEFAULT_IND";
    private static final String        DEFAULT_TRUE                                          = "Y";
    
    private static final StringBuilder GET_ALL                                               = new StringBuilder().append( " select     CFBF.CALL_FLOW_ID, CFBF.FUNCTION_ID, CFBF.LAST_MAINTENANCE_OPERATOR_ID " )
                                                                                                                  .append( " from       CALL_FLOW_BUSINESS_FUNCTION CFBF " );
    
    //private static final StringBuilder GET_BUSINESS_FUNCTION__BY_CALL_FLOW_ID                = new StringBuilder().append(  " sle " )
    
    private static final StringBuilder GET_BUSINESS_FUNCTION_GROUP_BY_CALL_FLOW_ID           = new StringBuilder().append( " select CFFG.CALL_FLOW_ID, CFFG.FUNCTION_GROUP_ID, FG.FUNCTION_GROUP_NM, CFFG.LAST_MAINTENANCE_ID " )
                                                                                                                  .append( " from CALL_FLOW_FUNCTION_GROUP CFFG " )
                                                                                                                  .append( " inner join FUNCTION_GROUP FG " )
                                                                                                                  .append( " on CFFG.FUNCTION_GROUP_ID = FG.FUNCTION_GROUP_ID " )
                                                                                                                  .append( " where CFFG.CALL_FLOW_ID = :CALL_FLOW_ID " );
    
    private static final StringBuilder GET_BUSINESS_FUNCTION_BY_CALL_FLOW_ID_FUNCTION_GRP_ID = new StringBuilder().append( " select CFBF.CALL_FLOW_ID, CFBF.FUNCTION_ID, BF.FUNCTION_NM " )
                                                                                                                  .append( " ,COALESCE(CFTN.TRANSFER_NUMBER_NM,  " )
                                                                                                                  .append( " (SELECT CFTNB.TRANSFER_NUMBER_NM " )
                                                                                                                  .append( " from CALL_FLOW_TRANSFER_NUMBER CFTNB " )
                                                                                                                  .append( " where CFTNB.CALL_FLOW_ID = :CALL_FLOW_ID " )
                                                                                                                  .append( " and DEFAULT_IND = :DEFAULT_IND)" )
                                                                                                                  .append( " , 'No Default Transfer Number') as TRANSFER_NUMBER_NM, CFBF.LAST_MAINTENANCE_ID " )
                                                                                                                  .append( " ,COALESCE((select 1 " )
                                                                                                                  .append( " from CALL_FLOW_TRANSFER_HIERARCHY CFTH" )
                                                                                                                  .append( " where CFTH.CALL_FLOW_ID = CFBF.CALL_FLOW_ID" )
                                                                                                                  .append( " and CFTH.TRANSFER_TYPE_HIERARCHY_CVID = :FUNCTION_LVL_STATUS), 0 ) as TRANSFER_INDICATOR" )
                                                                                                                  .append( " from CALL_FLOW_BUSINESS_FUNCTION CFBF" )
                                                                                                                  .append( " inner join BUSINESS_FUNCTION BF" )
                                                                                                                  .append( " on BF.FUNCTION_ID = CFBF.FUNCTION_ID" )
                                                                                                                  .append( " inner join FUNCTION_GROUP FG" )
                                                                                                                  .append( " on FG.FUNCTION_GROUP_ID = BF.FUNCTION_GROUP_ID" )
                                                                                                                  .append( " left outer join CALL_FLOW_TRANSFER_NUMBER CFTN" )
                                                                                                                  .append( " on CFTN.CALL_FLOW_ID = CFBF.CALL_FLOW_ID" )
                                                                                                                  .append( " and CFTN.CALL_FLOW_TRANSFER_NUMBER_ID = CFBF.CALL_FLOW_TRANSFER_NUMBER_ID" )
                                                                                                                  .append( " where BF.FUNCTION_GROUP_ID = :FUNCTION_GROUP_ID" )
                                                                                                                  .append( " and CFBF.CALL_FLOW_ID = :CALL_FLOW_ID" );
    
    private static final StringBuilder GET_TRANSFER_NUMBERS                                  = new StringBuilder().append( " select CFTN.CALL_FLOW_ID, CFTN.CALL_FLOW_TRANSFER_NUMBER_ID, CFTN.TRANSFER_NUMBER_NM, CFTN.LAST_MAINTENANCE_ID " )
                                                                                                                  .append( " from CALL_FLOW_TRANSFER_NUMBER CFTN " )
                                                                                                                  .append( " where CFTN.CALL_FLOW_ID = :CALL_FLOW_ID " )
                                                                                                                  .append( " and 1 = ( Select 1" )
                                                                                                                  .append( " from CALL_FLOW_TRANSFER_HIERARCHY CFTH " )
                                                                                                                  .append( " where CFTH.CALL_FLOW_ID = :CALL_FLOW_ID " )
                                                                                                                  .append( " and CFTH.TRANSFER_TYPE_HIERARCHY_CVID = :FUNCTION_LVL_STATUS)" );
    
    private static final StringBuilder GET_DEFAULT_TRANSFER_NUMBERS                          = new StringBuilder().append( " select CFTN.CALL_FLOW_ID, CFTN.CALL_FLOW_TRANSFER_NUMBER_ID, CFTN.TRANSFER_NUMBER_NM, CFTN.LAST_MAINTENANCE_ID " )
                                                                                                                  .append( " from CALL_FLOW_TRANSFER_NUMBER CFTN " )
                                                                                                                  .append( " where CFTN.CALL_FLOW_ID = :CALL_FLOW_ID " )
                                                                                                                  .append( " and DEFAULT_IND = :DEFAULT_IND" )
                                                                                                                  .append( " and 1 = ( Select 1" )
                                                                                                                  .append( " from CALL_FLOW_TRANSFER_HIERARCHY CFTH " )
                                                                                                                  .append( " where CFTH.CALL_FLOW_ID = :CALL_FLOW_ID " )
                                                                                                                  .append( " and CFTH.TRANSFER_TYPE_HIERARCHY_CVID = :FUNCTION_LVL_STATUS)" );
    
    private static final StringBuilder PUT_CALL_FLOW_BUSINESS_FUNCTION_TRANSFER_NUMBER       = new StringBuilder().append( " UPDATE CALL_FLOW_BUSINESS_FUNCTION CFBF" )
                                                                                                                  .append( " SET CFBF.LAST_MAINTENANCE_TS = CURRENT_TIMESTAMP(), CFBF.LAST_MAINTENANCE_ID = :LAST_MAINTENANCE_ID, CFBF.CALL_FLOW_TRANSFER_NUMBER_ID = :CALL_FLOW_TRANSFER_NUMBER_ID " )
                                                                                                                  .append( " WHERE CFBF.CALL_FLOW_ID = :CALL_FLOW_ID " )
                                                                                                                  .append( " and FUNCTION_ID = :FUNCTION_ID " )
                                                                                                                  .append( " and 1 = ( Select 1" )
                                                                                                                  .append( " from CALL_FLOW CF" )
                                                                                                                  .append( " where CF.CALL_FLOW_ID = :CALL_FLOW_ID" )
                                                                                                                  .append( " and CF.CALL_FLOW_STATUS_CVID = :CALL_FLOW_STATUS_PILOT)" )
                                                                                                                  .append( " and 1 = ( Select 1" )
                                                                                                                  .append( " from CALL_FLOW_TRANSFER_HIERARCHY CFTH " )
                                                                                                                  .append( " where CFTH.CALL_FLOW_ID = :CALL_FLOW_ID " )
                                                                                                                  .append( " and CFTH.TRANSFER_TYPE_HIERARCHY_CVID = :FUNCTION_LVL_STATUS)" );
    
    private final static Logger        LOG                                                   = LoggerFactory.getLogger( CallFlowFunctionDaoImpl.class );
    
    
    public List<CallFlowFunctionGroup> getAll()
    {
        List<CallFlowFunctionGroup> dnisBusinessFunctionList = null;
        try
        {
            dnisBusinessFunctionList = getNamedParameterJdbcOperations().query( GET_ALL.toString(),
                                                                                new CallFlowFunctionGroupRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return dnisBusinessFunctionList;
    }
    
    /**
     * This method returns all the Function Groups for a certain Call Flow Id
     * @param callFlowId
     * @return List<CallFlowFunctionGroup>
     */
    public List< CallFlowFunctionGroup > getBusinessFunctionByCallFlow( int callFlowId )
    {
        List<CallFlowFunctionGroup> dnisBusinessFunctionList = null;
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                              callFlowId );
        try
        {
            dnisBusinessFunctionList = getNamedParameterJdbcOperations().query( GET_BUSINESS_FUNCTION_GROUP_BY_CALL_FLOW_ID.toString(),
                                                                                parameters,
                                                                                new CallFlowFunctionGroupRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return dnisBusinessFunctionList;
    }
    
    /**
     * This returns all the Business Functions for a Call Flow Id and Function Group
     * @param callFlowId
     * @param functionGrpId
     * @return List<CallFlowBusinessFunction>
     */
    public List<CallFlowBusinessFunction> getBusinessFunctionByCallFlowFunctionGrpId( int callFlowId,
                                                                                      int functionGrpId )
    {
        List<CallFlowBusinessFunction> callFlowBusinessFunctionList = null;
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( FUNCTION_GROUP_ID,
                                                                              functionGrpId )
                                                                   .addValue( CALL_FLOW_ID,
                                                                              callFlowId )
                                                                   .addValue( FUNCTION_LVL_STATUS,
                                                                              globalConfig.getFunctionTransferHeirarchy() )
                                                                   .addValue( DEFAULT_IND,
                                                                              DEFAULT_TRUE );
        
        try
        {
            callFlowBusinessFunctionList = getNamedParameterJdbcOperations().query( GET_BUSINESS_FUNCTION_BY_CALL_FLOW_ID_FUNCTION_GRP_ID.toString(),
                                                                                    parameters,
                                                                                    new CallFlowBusinessFunctionRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callFlowBusinessFunctionList;
    }
    
    /**
     * This returns all available Transfer Numbers that can be used for Business Function Overrides
     * @param callFlowId
     * @return List<CallFlowTransferNumber>
     */
    public List<CallFlowTransferNumber> getTransferNumbersByCallFlow( int callFlowId )
    {
        List<CallFlowTransferNumber> transferNumberList = null;
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                              callFlowId )
                                                                   .addValue( FUNCTION_LVL_STATUS,
                                                                              globalConfig.getFunctionTransferHeirarchy() );
        try
        {
            transferNumberList = getNamedParameterJdbcOperations().query( GET_TRANSFER_NUMBERS.toString(),
                                                                          parameters,
                                                                          new CallFlowTransferNumbersRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return transferNumberList;
    }
    
    /**
     * This updates the Call Flow Business Function Table with an override Transfer Number
     * @param callFlowId
     * @param functionId
     * @param transferNumberId
     * @return UpdateResponse
     */
    public UpdateResponse setBusinessFunctionTransferNumbersByCallFlow( int callFlowId,
                                                                        int functionId,
                                                                        int transferNumberId )
    {
        int queryResults = 0;
        UpdateResponse response = new UpdateResponse();
        response.setSqlSuccess( true );
        SqlParameterSource parameters = null;
        try
        {
            parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                               callFlowId )
                                                    .addValue( FUNCTION_ID,
                                                               functionId )
                                                    .addValue( CALL_FLOW_TRANSFER_NUMBER_ID,
                                                               transferNumberId )
                                                    .addValue( CALL_FLOW_STATUS_PILOT,
                                                               globalConfig.getCallFlowStatusPilot() )
                                                    .addValue( FUNCTION_LVL_STATUS,
                                                               globalConfig.getFunctionTransferHeirarchy() )
                                                    .addValue( LAST_MAINTENANCE_ID,
                                                               sessionAttributes.getAssociate()
                                                                                .getId() );
        }
        catch( Exception e )
        {
            LOG.error( "Parameters for Business Call Flow Transfer errored out. Message: "
                       + e.getMessage() );
            response.setSqlSuccess( false );
            return response;
        }
        try
        {
            queryResults = getNamedParameterJdbcOperations().update( PUT_CALL_FLOW_BUSINESS_FUNCTION_TRANSFER_NUMBER.toString(),
                                                                     parameters );
        }
        catch( DataAccessException a )
        {
            LOG.error( a.getCause().getMessage() );
            SQLException sqle = ( SQLException ) a.getCause();
            LOG.error( "Error Code: " + sqle.getErrorCode() + " SQL STATE: "
                       + sqle.getSQLState() );
            response.setSqlSuccess( false );
            response.setErrorCode( "BFTNU1" ); // unique id to find the place in the code
            response.setErrorMsg( "Your update failed with an SQL error." );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
            response.setSqlSuccess( false );
        }
        if( queryResults == 0 )
        {
            LOG.error( "The PUT_CALL_FLOW_BUSINESS_FUNCTION_TRANSFER_NUMBER SQL failed to update. CALL_FLOW_ID: "
                       + callFlowId + " FUNCTION_ID: " + functionId
                       + " CALL_FLOW_TRANSFER_NUMBER_ID: " + transferNumberId
                       + " LAST_MAINTENANCE_ID: "
                       + sessionAttributes.getAssociate().getId() );
            response.setSqlSuccess( false );
        }
        response.setUpdateCnt( queryResults );
        return response;
    }
    
    /**
     * This method get the global configuration options that are needed to process the queries in this class
     * @param globalConfig
     */
    @Autowired
    public void setConfigurations( GlobalConfig globalConfig )
    {
        this.globalConfig = globalConfig;
    }
    
    
    /**
     * Retrieves the current session so the users id can be added to the last maint operator id
     * @param adminSessionService
     */
    @Autowired
    public void setSessionAttributes( AdminSessionService adminSessionService )
    {
        this.sessionAttributes = adminSessionService.getAttributes();
    }
}// end class
