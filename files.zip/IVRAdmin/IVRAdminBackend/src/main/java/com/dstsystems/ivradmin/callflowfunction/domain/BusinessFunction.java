package com.dstsystems.ivradmin.callflowfunction.domain;

public class BusinessFunction {

	private Integer functionId;
	// private String lastMaintenanceDateTime;
	private String lastMaintenanceOperatorId;
	private String functionNm;
	private Integer lineOfBusinessId;
	private Integer securedInd;

	/**
	 * @return the functionId
	 */
	public Integer getFunctionId() {
		return functionId;
	}

	/**
	 * @param functionId
	 *            the functionId to set
	 */
	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	/**
	 * @return the lastMaintenanceOperatorId
	 */
	public String getLastMaintenanceOperatorId() {
		return lastMaintenanceOperatorId;
	}

	/**
	 * @param lastMaintenanceOperatorId
	 *            the lastMaintenanceOperatorId to set
	 */
	public void setLastMaintenanceOperatorId(String lastMaintenanceOperatorId) {
		this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
	}

	/**
	 * @return the functionNm
	 */
	public String getFunctionNm() {
		return functionNm;
	}

	/**
	 * @param functionNm
	 *            the functionNm to set
	 */
	public void setFunctionNm(String functionNm) {
		this.functionNm = functionNm;
	}

	/**
	 * @return the lineOfBusinessId
	 */
	public Integer getLineOfBusinessId() {
		return lineOfBusinessId;
	}

	/**
	 * @param lineOfBusinessId
	 *            the lineOfBusinessId to set
	 */
	public void setLineOfBusinessId(Integer lineOfBusinessId) {
		this.lineOfBusinessId = lineOfBusinessId;
	}

	/**
	 * @return the securedInd
	 */
	public Integer getSecuredInd() {
		return securedInd;
	}

	/**
	 * @param securedInd
	 *            the securedInd to set
	 */
	public void setSecuredInd(Integer securedInd) {
		this.securedInd = securedInd;
	}

}
