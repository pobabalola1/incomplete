package com.dstsystems.ivradmin.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.AssetManagementDnisBusinessFunction;
import com.dstsystems.ivradmin.domain.mapper.AssetManagementDnisBusinessFunctionRowMapper;

@Repository
public class AssetManagementDnisBusinessFunctionDaoImpl extends BaseJdbcDAO {
	private static final String DNIS_ID = "DNIS_ID";//PK FK
	private static final String CODE_SET_ID = "CODE_SET_ID";//PK FK
	private static final String CODE_SET_VALUE_ID = "CODE_SET_VALUE_ID";//FK
	
	private static final StringBuilder GET_ALL = new StringBuilder()
			.append(" select     AMDBF.DNIS_ID, AMDBF.BUSINESS_FUNCTION_ID, AMDBF.LAST_MAINTENANCE_TIMESTAMP, "
					          + "AMDBF.LAST_MAINTENANCE_ID, AMDBF.ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_NUMBER_ID ")
			.append(" from       ASSET_MANAGEMENT_DNIS_BUSINESS_FUNCTION AMDBF ");
	
	private final static Logger     LOG = LoggerFactory.getLogger( AssetManagementDnisBusinessFunctionDaoImpl.class );
	
	public List< AssetManagementDnisBusinessFunction > getAll()
    {
    	List< AssetManagementDnisBusinessFunction > assetManagementDnisBusinessFunction = null; 
    	try 
    	{
    		assetManagementDnisBusinessFunction = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new AssetManagementDnisBusinessFunctionRowMapper() );
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return assetManagementDnisBusinessFunction;
    }
}





















