/**
 * 
 */
package com.dstsystems.ivradmin.closure.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.dstsystems.ivradmin.closure.domain.Closure;
import com.dstsystems.ivradmin.core.domain.IndicatorType;

/**
 * @author dt86783
 *
 */
@Component
public class OverrideClosureRowMapper implements RowMapper< Closure >
{
   private static final String CALL_FLOW_TRANSFER_OVERRIDE_DT = "CALL_FLOW_TRANSFER_OVERRIDE_DT";
   private static final String OPEN_IND = "OPEN_IND";
   private static final String USE_NORMAL_BUSINESS_HOURS_IND = "USE_NORMAL_BUSINESS_HOURS_IND";
   private static final String OPEN_TM = "OPEN_TM";
   private static final String CLOSED_TM = "CLOSED_TM";
   
   private static final SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
   
   @Override
   public Closure mapRow( ResultSet rs, int rowNum ) throws SQLException
   {
      IndicatorType openInd = IndicatorType.asIndType( rs.getString( OPEN_IND ) );
      IndicatorType useNormalBusinessHrs = IndicatorType.asIndType( rs.getString( USE_NORMAL_BUSINESS_HOURS_IND ) );
      
      Closure closure = Closure.builder()
            .closeDate( rs.getDate( CALL_FLOW_TRANSFER_OVERRIDE_DT ) )
            .startTime( sdf.format( Time.valueOf( rs.getString( OPEN_TM ) ) ) )
            .closeTime( sdf.format( Time.valueOf( rs.getString( CLOSED_TM ) ) ) )
            .defaultCloseDate( false )
            .closedAllDay( openInd == IndicatorType.NO )
            .overridedHours( openInd == IndicatorType.YES && useNormalBusinessHrs == IndicatorType.NO )
            .normalBusinessHours( openInd == IndicatorType.YES &&  useNormalBusinessHrs == IndicatorType.YES )
            .name( "MOCK DATE " + rs.getDate( CALL_FLOW_TRANSFER_OVERRIDE_DT ) ) //Define later.
            //.useDefaultIvr( IndicatorType.YES ) // To be defined.
            .build();
      return closure;

   }
   
}
