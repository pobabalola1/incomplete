package com.dstsystems.ivradmin.core.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.dstsystems.ivradmin.core.domain.CallFlow;

@Component
public class CallFlowRowMapper implements RowMapper<CallFlow>
{
   private final String CALL_FLOW_ID    = "CALL_FLOW_ID";
   private final String DNIS_NBR        = "DNIS_NBR";
   private final String IVR_CLIENT_ID   = "IVR_CLIENT_ID";
   
   @Override
   public CallFlow mapRow( ResultSet rs, int rowNum ) throws SQLException
   {
	  CallFlow callFlow = CallFlow.builder()
	        .callFlowId( rs.getInt(CALL_FLOW_ID) )
	        .dnisNbr( rs.getString( DNIS_NBR ) )
	        .ivrClientId( rs.getInt( IVR_CLIENT_ID ) )
	        .build();
	  
      return callFlow;
   }
}
