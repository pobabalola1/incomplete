/*
 * FILE : CallFlowTouchToneNavigation.java
 *
 * CLASS : CallFlowTouchToneNavigation
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.domain;

import java.math.BigInteger;

import org.hibernate.validator.constraints.NotEmpty;

import lombok.*;

/**
 * An instance of this class will contain a small portion of the touch tone navigation XML configuration for a given DNIS 
 * and call flow id. These elements are the few to which the Admin Tool will make reference.
 * 
 * @author dt63314
 *
 */
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class DnisNavigationCache
{
    /**
     * Each call flow has one speaker per language. This enumeration defines
     * the text literals that appear on the Global Information screen that identifies
     * this call flow's voice talent gender.
     * 
     * @author dt63314
     *
     */
    enum Gender
    {
     MALE( "M" )
     {
         @Override
         public String toString()
         {
             return "Male";
         }
     },
     FEMALE( "F" )
     {
         @Override
         public String toString()
         {
             return "Female";
         }
     };
        
        private final String code;
        
        private Gender( String code )
        {
            this.code = code;
        }
    }
    
    @NotEmpty
    private String     dnis;
    @NonNull
    private BigInteger callFlowId;
    @NotEmpty
    private String     inputMode;
    @NotEmpty
    private String     language;
    @NotEmpty
    private String     gender;
    
    /**
     * Returns the gender description for this call flow.
     * 
     * @return
     */
    public String getGenderDescription()
    {
        return Gender.FEMALE.code.equals( gender ) ? Gender.FEMALE.toString()
                                                   : Gender.MALE.toString();
    }
}
