package com.dstsystems.ivradmin.core.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CallFlowExt
{
   private Integer                      callFlowId;
   private Integer                      ivrClientId;
   private String                       dnisNbr;
   private Integer                      callFlowStatusCvid;
   private CodeSetValueDisplay          callFlowStatus;
   private IndicatorType                alwaysTransferIndicator;
   private IndicatorType                alwaysTransferOnStopMailIndicator;
   private IndicatorType                useExternalPinValidationIndicator;
   private Integer                      userAuthenticationMethodCvid;
   private CodeSetValueDisplay          userAuthenticationMethod;
   private Integer                      accountGroupMethodCvid;
   private CodeSetValueDisplay          accountGroupMethod;
   private Integer                      transferClosedRecordingId;
   private IVRRecording                 transferClosedRecording;
}
