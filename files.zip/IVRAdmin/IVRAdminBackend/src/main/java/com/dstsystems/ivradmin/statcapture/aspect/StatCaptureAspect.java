/*
 * FILE : StatCaptureAspect.java
 *
 * CLASS : StatCaptureAspect
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.statcapture.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.beans.factory.annotation.Autowired;

import com.dstsystems.ivradmin.statcapture.config.StatCaptureConfig;
import com.dstsystems.statcapture.web.SubRequestStatistic;
import com.dstsystems.statcapture.web.WebStatisticContext;

import lombok.extern.slf4j.Slf4j;

/**
 * The StatCaptureAspect super class defines methods that may be reusable to any Spring Aspect. Make sure that your @Pointcut annotations
 * are linked to a Spring-managed Bean, which includes @autowired beans in our classes.
 * @author DT63314
 *
 */
@Slf4j
public abstract class StatCaptureAspect
{
    StatCaptureConfig statCaptureConfig;
    
    @Autowired
    public void setStatCaptureConfig( StatCaptureConfig statCaptureConfig )
    {
        this.statCaptureConfig = statCaptureConfig;
    }
    
    /**
     * <p>A reusable method for executing the EV4 timer to capture execution timing for a given request. Subclasses of this class should define the Pointcut and 
     * activities to perform (i.e. around, before, etc.), then pass the request to this method for logging execution.</p>
     * <p>Exceptions thrown by the method(s) executed for this Pointcut are not captured by the Aspect.</p>
     * @param joinPoint - the originating event.
     * @param webStatisticContext - the request statistic handler.
     * @param ev4Message - the message to log with this request.
     * @return The object that comes back from {@link ProceedingJoinPoint#proceed()}.
     * @throws Throwable any exception thrown in the join point code.
     */
    protected Object logAroundProceed( ProceedingJoinPoint joinPoint,
                                       WebStatisticContext webStatisticContext,
                                       String ev4Message ) throws Throwable
    {
        SubRequestStatistic connectSubRequestStatistic = webStatisticContext.createSubRequestStatistic( ev4Message );
        connectSubRequestStatistic.startTimer();
        
        Object result;
        try
        {
            log.debug( "Before {}", joinPoint );
            result = joinPoint.proceed();
            log.debug( "After {}", joinPoint );
            
            return result;
        }
        finally
        {
            connectSubRequestStatistic.endTimer();
        }
    }
}
