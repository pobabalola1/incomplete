package com.dstsystems.ivradmin.closure.controller;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import com.dstsystems.ivradmin.closure.dao.ClosureDaoImpl;
import com.dstsystems.ivradmin.closure.domain.Closure;
import com.dstsystems.ivradmin.closure.domain.ClosureResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ClosureController {	

	@Autowired
	private ClosureDaoImpl closureDaoImpl;
	
	@RequestMapping(path = "/api/data/closures/{callFlowId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List< Closure > getClosuresByCallFlowId( @PathVariable Integer callFlowId )
    {
	   
	   List< Closure > defaultClosureList = closureDaoImpl.getDefaultCloseDatesByCallFlowId( callFlowId );
	   
	   List< Closure > overrideClosureList = closureDaoImpl.getOverrideCloseDatesByCallFlowId( callFlowId ); 
	   
	   List< Date > overrideClosureDateList = overrideClosureList.stream().map( e -> e.getCloseDate() ).collect( Collectors.toList() ); 
	   
	   // Remove default closure which duplicate in override closure.
	   for( Iterator< Closure > it = defaultClosureList.iterator(); it.hasNext(); )
       {
         Closure closure = ( Closure ) it.next();
         
         if ( overrideClosureDateList.contains( closure.getCloseDate() ) ) 
         {
            defaultClosureList.remove( closure );
         } 
      }
	   
	  // Combine default and override closures.
	  defaultClosureList.addAll( overrideClosureList );
	  
	  // Sort by date.
	  defaultClosureList = defaultClosureList.stream().sorted( ( o1, o2 ) -> o1.getCloseDate()
	                                      .compareTo( o2.getCloseDate() ) )
	                                      .collect( Collectors.toList() );
	  return defaultClosureList;
    }	

	//http://localhost:8081/ivradmin/api/data/closures/add/lineId/3/transDT/2018-12-01/maintId/DT77649/transNM/Tum BD/closeAllDay/N/oBusinessHRS/Y/nBusinessHRS/N/openTM/07:00:00/closeTM/16:00:00/useDef/N/recID/154/callFlowID/1
	   
	//@RequestMapping(path = "/api/data/closures/add/lineId/{lineId}/transDT/{transDT}/maintId/{maintId}/transNM/{transNM}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@RequestMapping(path = "/api/data/closures/add/lineId/{lineId}/transDT/{transDT}/maintId/{maintId}/transNM/{transNM}/closeAllDay/{closeAllDay}/oBusinessHRS/{oBusinessHRS}/nBusinessHRS/{nBusinessHRS}/openTM/{openTM}/closeTM/{closeTM}/useDef/{useDef}/recID/{recID}/callFlowID/{callFlowID}"
			, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List< ClosureResponse > addNewClosures( @PathVariable String lineId, @PathVariable String transDT, @PathVariable String maintId, @PathVariable String transNM,
    		@PathVariable String closeAllDay, @PathVariable String oBusinessHRS, @PathVariable String nBusinessHRS,
    		@PathVariable String openTM, @PathVariable String closeTM,
    		@PathVariable String useDef, @PathVariable String recID, @PathVariable String callFlowID)
    {

		/*
		System.out.println("----- closuresAdd3 -----"+lineId+":"+transDT+":"+maintId+":"+transNM+":");
		
		System.out.println("----- closuresAdd5 -----"+closeAllDay+":"+oBusinessHRS+":"+nBusinessHRS+":"
		+openTM+":"+closeTM+":"+useDef+":"+recID+":"+callFlowID);
		*/
		List< ClosureResponse > resList = null;
		resList = closureDaoImpl.addNewClosures(lineId, transDT, maintId, transNM, closeAllDay, oBusinessHRS, nBusinessHRS, openTM, closeTM, useDef, recID, callFlowID);

		return resList;
    }
	
	
	@RequestMapping(path = "/api/data/closures/update/lineId/{lineId}/transDT/{transDT}/maintId/{maintId}/transNM/{transNM}/closeAllDay/{closeAllDay}/oBusinessHRS/{oBusinessHRS}/nBusinessHRS/{nBusinessHRS}/openTM/{openTM}/closeTM/{closeTM}/useDef/{useDef}/recID/{recID}/callFlowID/{callFlowID}/oldTransDT/{oldTransDT}"
			, method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List< ClosureResponse > updateClosures( @PathVariable String lineId, @PathVariable String transDT, @PathVariable String maintId, @PathVariable String transNM,
    		@PathVariable String closeAllDay, @PathVariable String oBusinessHRS, @PathVariable String nBusinessHRS,
    		@PathVariable String openTM, @PathVariable String closeTM,
    		@PathVariable String useDef, @PathVariable String recID, @PathVariable String callFlowID, @PathVariable String oldTransDT)
    {

		/*
		System.out.println("----- closuresAdd3 -----"+lineId+":"+transDT+":"+maintId+":"+transNM+":");
		
		System.out.println("----- closuresAdd5 -----"+closeAllDay+":"+oBusinessHRS+":"+nBusinessHRS+":"
		+openTM+":"+closeTM+":"+useDef+":"+recID+":"+callFlowID+":"+ oldTransDT);
		*/
		List< ClosureResponse > resList = null;
		resList = closureDaoImpl.updateClosures(lineId, transDT, maintId, transNM, closeAllDay, oBusinessHRS, nBusinessHRS, openTM, closeTM, useDef, recID, callFlowID, oldTransDT);

		return resList;
    }
	
	

	
	
	
	
	
	
}
