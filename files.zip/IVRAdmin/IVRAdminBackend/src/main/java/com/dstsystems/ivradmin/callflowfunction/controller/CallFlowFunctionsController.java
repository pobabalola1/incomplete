package com.dstsystems.ivradmin.callflowfunction.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.callflowfunction.dao.CallFlowFunctionDaoImpl;
import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowBusinessFunction;
import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowFunctionGroup;
import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowTransferNumber;
import com.dstsystems.ivradmin.core.controller.BaseController;
import com.dstsystems.ivradmin.domain.UpdateResponse;

@RestController
public class CallFlowFunctionsController extends BaseController
{
    
    @Autowired
    private CallFlowFunctionDaoImpl callFlowFunctionDaoImpl;
    
    @RequestMapping(path = "/business-functions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List<CallFlowFunctionGroup> getAll()
    {
        return callFlowFunctionDaoImpl.getAll();
    }
    
    /**
     * This services provides all the Function Groups for a Call Flow Id
     * @param callFlowId
     * @return List<CallFlowFunctionGroup>
     */
    @RequestMapping(path = "/call-flow-function-group/{callFlowId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List<CallFlowFunctionGroup> getCallFlowBusinessFunction( @PathVariable int callFlowId )
    {
        return callFlowFunctionDaoImpl.getBusinessFunctionByCallFlow( callFlowId );
    }
    
    /**
     * This service will return all the Business Functions by Call Flow Id and Function Group
     * @param callFlowId
     * @param functionGrpId
     * @return List<CallFlowBusinessFunction>
     */
    @RequestMapping(path = "/call-flow-business-functions/{callFlowId}/{functionGrpId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List<CallFlowBusinessFunction> getDnisBusinessFunction( @PathVariable int callFlowId,
                                                                   @PathVariable int functionGrpId )
    {
        return callFlowFunctionDaoImpl.getBusinessFunctionByCallFlowFunctionGrpId( callFlowId,
                                                                                   functionGrpId );
    }
    
    /**
     * This Service bring back all the available Transfer Number for a Call Flow Id if the Transfer Hierarchy allows for Functions
     * @param callFlowId
     * @return List<CallFlowTransferNumber>
     */
    @RequestMapping(path = "/call-flow-transfer-numbers/{callFlowId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List<CallFlowTransferNumber> getTransferNumber( @PathVariable int callFlowId )
    {
        return callFlowFunctionDaoImpl.getTransferNumbersByCallFlow( callFlowId );
    }
    
    /**
     * This service allows the the Transfer Number Id to be updated for a Business Function in a Call Flow
     * @param callFlowId
     * @param functionId
     * @param transferNumId
     * @return UpdateResponse
     */
    @RequestMapping(path = "/call-flow-business-function-transfer-number/{callFlowId}/{functionId}/{transferNumId}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public UpdateResponse putBusinessFunctionTransferNumber( @PathVariable int callFlowId,
                                                             @PathVariable int functionId,
                                                             @PathVariable int transferNumId )
    {
        return callFlowFunctionDaoImpl.setBusinessFunctionTransferNumbersByCallFlow( callFlowId,
                                                                                     functionId,
                                                                                     transferNumId );
    }
    
}
