package com.dstsystems.ivradmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.core.config.GlobalConfig;
import com.dstsystems.ivradmin.dao.LineOfBusinessDaoImpl;
import com.dstsystems.ivradmin.domain.LineOfBusiness;;

@RestController
public class LineOfBusinessController
{
    
    @Autowired
    private LineOfBusinessDaoImpl  lobDaoImpl;
    
    private GlobalConfig globalConfig;
    
    @RequestMapping(path = "/api/data/line-of-businesses", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List<LineOfBusiness> getAll()
    {
        return lobDaoImpl.getAll();
    }
    
    
    @RequestMapping(path = "/api/data/line-of-business/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public LineOfBusiness getById( @PathVariable int id )
    {
        int callFlowStatus = globalConfig.getCallFlowStatusPilot();
        return lobDaoImpl.getAllLineOfBusinessById( id, callFlowStatus );
    }
    
    @Autowired
    public void setConfigurations( GlobalConfig globalConfig )
    {
        this.globalConfig = globalConfig;
    }
    
    
}
