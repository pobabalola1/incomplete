package com.dstsystems.ivradmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.dao.LineOfBusinessClientDaoImpl;
import com.dstsystems.ivradmin.domain.LineOfBusinessClient;

@RestController
public class LineOfBusinessClientController {


   @Autowired
   private LineOfBusinessClientDaoImpl lineOfBusinessClientDaoImpl;

   @RequestMapping(path = "/api/data/line-of-business-clients" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
   @ResponseBody
   public List< LineOfBusinessClient > getAll() 
   {
      return lineOfBusinessClientDaoImpl.getAll();
   }
}
