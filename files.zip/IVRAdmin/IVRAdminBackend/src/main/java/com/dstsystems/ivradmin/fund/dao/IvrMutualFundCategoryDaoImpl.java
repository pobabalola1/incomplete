package com.dstsystems.ivradmin.fund.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.mapper.IvrMutualFundCategoryRowMapper;
import com.dstsystems.ivradmin.fund.domain.IvrMutualFundCategory;

@Repository
public class IvrMutualFundCategoryDaoImpl extends BaseJdbcDAO {

	private static final String IVR_MUTUAL_FUND_CATEGORY_ID = "IVR_MUTUAL_FUND_CATEGORY_ID";//Primary Key
	
	private static final StringBuilder GET_ALL = new StringBuilder()
			.append(" select     IMFC.IVR_MUTUAL_FUND_CATEGORY_ID, IMFC.LAST_MAINTENANCE_OPERATOR_ID, IMFC.IVR_MUTUAL_FUND_CATEGORY_NM, IMFC.DNIS_ID ")
			.append(" from       IVR_MUTUAL_FUND_CATEGORY IMFC ");
	
	private final static Logger     LOG = LoggerFactory.getLogger( IvrMutualFundCategoryDaoImpl.class );
			
	public List< IvrMutualFundCategory > getAll()
    {
      List< IvrMutualFundCategory > ivrMutualFundCategoryList = null;
      try 
      {
    	  ivrMutualFundCategoryList = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new IvrMutualFundCategoryRowMapper() );
      }
	  catch( Exception e )
	  {
		  LOG.error( e.getMessage() );
	  }       
      return ivrMutualFundCategoryList;
    }
	
}
