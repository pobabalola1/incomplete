/*
 * FILE : GlobalDetailsController.java
 *
 * CLASS : GlobalDetailsController
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.globaldetail.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.dstsystems.ivradmin.core.config.GlobalConfig;
import com.dstsystems.ivradmin.core.controller.BaseController;
import com.dstsystems.ivradmin.core.domain.DnisNavigationCache;
import com.dstsystems.ivradmin.core.domain.ErrorBean;
import com.dstsystems.ivradmin.core.exception.DaoException;
import com.dstsystems.ivradmin.core.service.impl.DnisNavigationServiceImpl;
import com.dstsystems.ivradmin.dao.GlobalDetailsDao;
import com.dstsystems.ivradmin.globaldetail.domain.CallFlowGlobalDetail;
import com.dstsystems.ivradmin.globaldetail.domain.GlobalDetailResponse;

/**
 * Controller for managing the call flow Global Details in the Client Information module.
 * 
 * @author dt63314
 *
 */
@RestController
@Validated
public class GlobalDetailsController extends BaseController
{
    static final String       DAO_ERROR_1 = "DAO_1";
    
    private DnisNavigationServiceImpl dnisNavigationServiceImpl;
    
    private GlobalDetailsDao          globalDetailsDao;
    
    private GlobalConfig              globalConfig;
    
    @Autowired
    public void setDnisNavigationService( DnisNavigationServiceImpl dnisNavigationServiceImpl )
    {
        this.dnisNavigationServiceImpl = dnisNavigationServiceImpl;
    }
    
    @Autowired
    public void setGlobalDetails( GlobalDetailsDao globalDetailsDao )
    {
        this.globalDetailsDao = globalDetailsDao;
    }
    
    @Autowired
    public void setGlobalConfig( GlobalConfig globalConfig )
    {
        this.globalConfig = globalConfig;
    }
    
    /**
     * Returns the call flow / DNIS global details for a given call flow id. These details are split between
     * the call flow's configuration file (see classpath:resources/config/xml-files.yml) and the database. Call flow
     * configurations are named based on the DNIS, and so any call flow id must point to an active DNIS having a
     * call flow configuration file.
     * 
     * @param callFlowId the id pointing to a particular call flow.
     * @return the response containing global detail information.
     */
    @RequestMapping(path = "/global-details/{callFlowId}", method = RequestMethod.GET)
    public @ResponseBody GlobalDetailResponse getGlobalDetailsFor( @PathVariable @NotNull BigInteger callFlowId )
    {
        // FIXME Test
        GlobalDetailResponse response = null;
        List<ErrorBean> errors = new ArrayList<>();
        
        CallFlowGlobalDetail callFlowGlobalDetail = getCallFlowGlobalDetail( callFlowId,
                                                                             errors );
        if( errors.isEmpty() )
        {
            response = getDnisConfigurationDetails( response,
                                                    callFlowGlobalDetail,
                                                    errors );
        }
        return response;
    }
    
    /**
     * @param response
     * @param callFlowGlobalDetail
     * @param errors TODO
     * @return
     */
    GlobalDetailResponse getDnisConfigurationDetails( @NotNull GlobalDetailResponse response,
                                                      @NotNull CallFlowGlobalDetail callFlowGlobalDetail,
                                                      @NotNull  List<ErrorBean> errors )
    {
        // FIXME Test
        DnisNavigationCache dnisNavigationCache;
        try
        {
            dnisNavigationCache = dnisNavigationServiceImpl.getDnisNavigation( callFlowGlobalDetail.getDnis() );
            boolean isEditable = callFlowGlobalDetail.getCallFlowStatusCvid()
                                                     .equals( globalConfig.getCallFlowStatusPilotAsBigInteger() );
            
            response = GlobalDetailResponse.builder()
                                           .callFlowDescription( callFlowGlobalDetail.getCallFlowDescription() )
                                           .gender( dnisNavigationCache.getGenderDescription() )
                                           .accountGroupMethodText( callFlowGlobalDetail.getAccountGroupMethodText() )
                                           .isDescriptionEditable( isEditable )
                                           .build();
        }
        catch( DaoException ex )
        {
            // FIXME Implement
            ex.printStackTrace();
        }
        
        return response;
    }
    
    /**
     * Requests the Global Details that exist outside of the configuration files. Any resource
     * errors encountered in this process will be added to the error collection.
     * 
     * @param callFlowId the id on which to search.
     * @param errors the collection to which errors are added if an exception is thrown.
     * @return
     */
    CallFlowGlobalDetail getCallFlowGlobalDetail( @NotNull BigInteger callFlowId,
                                                  @NotNull List<ErrorBean> errors )
    {
        CallFlowGlobalDetail callFlowGlobalDetail = null;
        try
        {
            callFlowGlobalDetail = globalDetailsDao.getGlobalDetails( callFlowId );
        }
        catch( DaoException ex )
        {
            errors.add( new ErrorBean( DAO_ERROR_1, ex.getMessage() ) );
        }
        
        return callFlowGlobalDetail;
    }
}
