package com.dstsystems.ivradmin.core.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CallFlow
{
     private Integer callFlowId;
	 private String  dnisNbr;
	 private Integer ivrClientId;
}
