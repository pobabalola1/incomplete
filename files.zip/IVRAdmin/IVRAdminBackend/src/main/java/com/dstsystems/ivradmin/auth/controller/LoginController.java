/*
 * FILE : LoginController.java
 *
 * CLASS : LoginController
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.MediaType;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.dstsystems.ivradmin.auth.dao.LoginDao;
import com.dstsystems.ivradmin.auth.domain.Associate;
import com.dstsystems.ivradmin.auth.domain.LoginRequest;
import com.dstsystems.ivradmin.auth.domain.LoginResponse;
import com.dstsystems.ivradmin.core.domain.ErrorBean;
import com.dstsystems.ivradmin.session.service.AdminSessionService;
import com.dstsystems.ivradmin.statcapture.interceptor.StatCaptureInterceptor;

/**
 * Handles authentication requests for the IVR Admin Tool.
 * 
 * @author DT63314
 */
@RestController
public class LoginController
{
    private LoginDao            loginDao;
    private AdminSessionService adminSessionService;
    
    /**
     * Default constructor accepts a LoginDao and AdminSessionService.
     * @param loginDao
     * @param adminSessionService
     */
    public LoginController( LoginDao loginDao,
                            AdminSessionService adminSessionService )
    {
        this.loginDao = loginDao;
        this.adminSessionService = adminSessionService;
    }
    
    /**
     * Login entry point.
     *  
     * @param session - the user's session injected by Spring.
     * @param loginRequest - request containing the user credentials to authenticate.
     * @param result - binding results for the loginRequest, automatically generated.
     * @return LoginResponse
     */
    @RequestMapping(value = "/api/login", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public @ResponseBody LoginResponse login( HttpServletRequest request, HttpSession session,
                                              @RequestBody @Validated LoginRequest loginRequest,
                                              BindingResult result )
    {
        
        LoginResponse loginResponse = null;

        // Add the login id so we can capture it in the StatCapture postHandle processing.
        request.setAttribute( StatCaptureInterceptor.LOGIN_USER_NAME, loginRequest.getUserName() );
        
        if( !result.hasErrors() )
        {
            loginResponse = loginDao.authenticate( loginRequest );
            handleAssociateSession( session, loginResponse );
        }
        else
        {
            loginResponse = handleFormError( session, result );
        }
        
        return loginResponse;
    }
    
    /**
     * When the form contains errors, format the error bean entries and return a loginResponse without an Associate. The user's 
     * session will also be invalidated for this attempt.
     * @param session
     * @param result
     * @return
     */
    private LoginResponse handleFormError( HttpSession session,
                                           BindingResult result )
    {
        LoginResponse loginResponse;
        loginResponse = new LoginResponse();
        List<ErrorBean> errors = new ArrayList<>();
        for( FieldError error : result.getFieldErrors() )
        {
            errors.add( new ErrorBean( error.getField(),
                                       error.getDefaultMessage() ) );
        }
        loginResponse.setAssociate( null );
        loginResponse.setErrors( errors );
        adminSessionService.destroySession( session );
        return loginResponse;
    }
    
    /**
     * Sets up session for this request when the associate has successfully authenticated and has sufficient authority to use the application. 
     * Otherwise invalidates the session if the associate does not sufficient authorities.
     * @param session
     * @param loginResponse
     */
    private void handleAssociateSession( HttpSession session,
                                         LoginResponse loginResponse )
    {
        Associate associate = loginResponse.getAssociate();
        
        if( associate != null && associate.hasRole() )
        {
            adminSessionService.createSession( session, associate );
        }
        else
        {
            adminSessionService.destroySession( session );
        }
    }
    
}
