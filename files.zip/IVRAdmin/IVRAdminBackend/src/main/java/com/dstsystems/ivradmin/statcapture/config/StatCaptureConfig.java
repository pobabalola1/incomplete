/*
 * FILE : StatCaptureConfig.java
 *
 * CLASS : StatCaptureConfig
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.statcapture.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.dstsystems.ivradmin.session.service.AdminSessionService;
import com.dstsystems.ivradmin.statcapture.interceptor.StatCaptureInterceptor;
import com.dstsystems.statcapture.StatisticContextFactory;
import com.dstsystems.statcapture.web.WebStatisticContext;
import com.dstsystems.statcapture.web.servlet.listener.StatCaptureSessionListener;

/**
 * Configuration class to externalize the wiring up of beans for StatsCapture.
 * 
 * @author DT19643, dt63314
 *
 */
@Configuration
public class StatCaptureConfig
{
    private StatCaptureProperties statCaptureProperties;
    private AdminSessionService   sessionService;
    
    @Autowired
    public void injectConfiguration( StatCaptureProperties statCaptureProperties )
    {
        this.statCaptureProperties = statCaptureProperties;
    }
    
    @Autowired
    public void setSessionService( AdminSessionService sessionService )
    {
        this.sessionService = sessionService;
    }
    
    @Bean
    public StatCaptureInterceptor getStatCaptureInterceptor()
    {
        return new StatCaptureInterceptor( statCaptureProperties,
                                           sessionService );
    }
    
    @Bean
    public StatCaptureSessionListener getStatCaptureSessionListener()
    {
        return new StatCaptureSessionListener();
    }
    
    /**
     * Returns a web statistic context for the thread.
     * @return
     */
    public WebStatisticContext getWebStatisticContext()
    {
        /*
         * This method wraps a static factory implementation so that we can mock objects for testing purposes.
         */
        return StatisticContextFactory.getWebStatisticContext();
    }
}
