package com.dstsystems.ivradmin.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.AssetManagementDnisCallTransferOverrideDate;
import com.dstsystems.ivradmin.domain.mapper.AssetManagementDnisCallTransferOverrideDateRowMapper;

@Repository
public class AssetManagementDnisCallTransferOverrideDateDaoImpl  extends BaseJdbcDAO {

	private static final String DNIS_ID = "DNIS_ID";//PK FK
	private static final String ASSET_MANAGEMENT_DNIS_TRANSFER_OVERRIDE_DATE = "ASSET_MANAGEMENT_DNIS_TRANSFER_OVERRIDE_DATE";//PK
	
	private static final StringBuilder GET_ALL = new StringBuilder()
			.append(" select     AMDCTOD.DNIS_ID, AMDCTOD.ASSET_MANAGEMENT_DNIS_TRANSFER_OVERRIDE_DATE, AMDCTOD.LAST_MAINTENANCE_TIMESTAMP, "
					          + "AMDCTOD.LAST_MAINTENANCE_ID, AMDCTOD.OPEN_INDICATOR, AMDCTOD.USE_NORMAL_BUSINESS_HOURS_INDICATOR, "
					          + "AMDCTOD.OPEN_TIME, AMDCTOD.CLOSED_TIME " )
			.append(" from       ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_OVERRIDE_DATE_AMDCTOD ");
	
	
	private final static Logger     LOG = LoggerFactory.getLogger( AssetManagementDnisCallTransferBusinessHoursDaoImpl.class );
	
    public List< AssetManagementDnisCallTransferOverrideDate > getAll()
    {
    	List< AssetManagementDnisCallTransferOverrideDate > assetManagementDnisCallTransferOverrideDateList = null; 
    	try 
    	{
    		assetManagementDnisCallTransferOverrideDateList = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new AssetManagementDnisCallTransferOverrideDateRowMapper() );
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return assetManagementDnisCallTransferOverrideDateList;
    }
	
}
