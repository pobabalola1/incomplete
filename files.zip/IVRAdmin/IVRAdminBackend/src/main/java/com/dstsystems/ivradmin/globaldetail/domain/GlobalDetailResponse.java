/*
 * FILE : GlobalDetailResponse.java
 *
 * CLASS : GlobalDetailResponse
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.globaldetail.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.dstsystems.ivradmin.core.domain.ErrorBean;

import lombok.Builder;
import lombok.Getter;

/**
 * The Global Detail Response contains information about a particular DNIS at a point in time, as described by the call flow's current status. Of
 * the fields here, only the call flow description can be changed when the call flow is in an editable state. The errors list will contain errors
 * encountered while processing this request. An empty list denotes no errors, while a list containing one or more errors will provide some detail
 * for logging and reporting limited information in the UI.
 * 
 * @author dt63314
 *
 */
@Getter
public class GlobalDetailResponse
{
    private boolean               isDescriptionEditable;
    private String                callFlowDescription;
    private String                gender;
    private String                accountGroupMethodText;
    
    private final List<ErrorBean> errors = new ArrayList<>();
    
    @Builder
    private GlobalDetailResponse( boolean isDescriptionEditable, String callFlowDescription, String gender, String accountGroupMethodText)
    {
        this.isDescriptionEditable = isDescriptionEditable;
        this.callFlowDescription = callFlowDescription;
        this.gender = gender;
        this.accountGroupMethodText = accountGroupMethodText;
    }
    
    /**
     * Adds the given error bean to the response's error list.
     * 
     * @param error the error to add to this request.
     * @return true as documented by {@link Collection#add(Object)}
     */
    boolean addError( ErrorBean error )
    {
        return errors.add( error );
    }
}
