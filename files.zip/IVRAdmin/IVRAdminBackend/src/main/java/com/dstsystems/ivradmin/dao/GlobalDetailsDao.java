/*
 * FILE : GlobalDetailsDao.java
 *
 * CLASS : GlobalDetailsDao
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.dao;

import java.math.BigInteger;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Repository;
import org.springframework.validation.annotation.Validated;

import com.dstsystems.ivradmin.core.exception.DaoException;
import com.dstsystems.ivradmin.globaldetail.domain.CallFlowGlobalDetail;

/**
 * Exposes the API for selecting and updating a call flow's global information.
 * 
 * @author dt63314
 *
 */
@Repository
@Validated
public interface GlobalDetailsDao
{
    /**
     * Returns an immutable view of the global details for the given call flow id.
     * 
     * @param callFlowId
     * @throws DaoException thrown if the call flow id is not found.
     */
    CallFlowGlobalDetail getGlobalDetails( @NotNull BigInteger callFlowId ) throws DaoException;
    
}
