package com.dstsystems.ivradmin.transferNumber.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.transferNumber.bean.CallTransferNumber;

/**
 * Mapping data to show all cards for Call transfer NUmber  
 * 
 * @author DT77649
 */
public class CallTransferNumberDistinctRowMapper implements RowMapper<CallTransferNumber>{
	private final String name = "TRANSFER_NUMBER_NM";
	private final String phoneNumber = "TRANSFER_UNFORMATTED_PHONE_NBR";
	private final String useIntelligentTransferIndicator = "USE_INTELLIGENT_TRANSFER_IND";
	private final String defaultIndicator = "DEFAULT_IND";
	private final String assetManagementDnisCallTransferNumberId = "CALL_FLOW_TRANSFER_NUMBER_ID";
	
	/**
     * getting Call Transfer Number data.
     *  
     * @param rs - ResultSet from DB
     * @param rowNum - index to get row data
     * @return CallTransferNumber list
     */
	@Override
	public CallTransferNumber mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		CallTransferNumber assetManagementDnisCallTransferNumber = new CallTransferNumber();
		assetManagementDnisCallTransferNumber.setName( rs.getString( name ) );
		assetManagementDnisCallTransferNumber.setPhoneNumber( rs.getString( phoneNumber ) );
		assetManagementDnisCallTransferNumber.setIsUseIntTransInd( rs.getString( useIntelligentTransferIndicator ) );
		assetManagementDnisCallTransferNumber.setIsDefaultInd(rs.getString( defaultIndicator ));
		assetManagementDnisCallTransferNumber.setAssetManagementDnisCallTransferNumberId( rs.getInt(assetManagementDnisCallTransferNumberId) );
		return assetManagementDnisCallTransferNumber;
	}
}
