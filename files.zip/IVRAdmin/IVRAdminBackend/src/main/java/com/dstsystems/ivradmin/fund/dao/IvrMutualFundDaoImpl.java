package com.dstsystems.ivradmin.fund.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.mapper.IvrMutualFundCategoryRowMapper;
import com.dstsystems.ivradmin.domain.mapper.IvrMutualFundRowMapper;
import com.dstsystems.ivradmin.fund.domain.IvrMutualFund;
import com.dstsystems.ivradmin.fund.domain.IvrMutualFundCategory;

@Repository
public class IvrMutualFundDaoImpl extends BaseJdbcDAO
{
    
    private static final String        CALL_FLOW_ID            = "CALL_FLOW_ID";                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               //Primary Key
    private static final String        IVR_MUTUAL_FUND_ID      = "IVR_MUTUAL_FUND_ID";                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         //Primary Key
    
    private static final StringBuilder GET_ALL                 = new StringBuilder().append( " select IMF.DNIS_ID, IMF.IVR_MUTUAL_FUND_ID, IMF.LAST_MAINTENANCE_OPERATOR_ID, IMF.IVR_MUTUAL_FUND_CATEGORY_ID, IMF.IVR_FUND_NM, IMF.FUND_CODE " ).append( " from IVR_MUTUAL_FUND IMF " );
    
    private static final StringBuilder GET_IVR_FUND_CATEGORIES = new StringBuilder().append( " select IMFC.CALL_FLOW_ID, IMFC.IVR_MUTUAL_FUND_CATEGORY_ID, IMFC.IVR_CATEGORY_NM, IMFC.LAST_MAINTENANCE_ID" ).append( " ,(select count(*)" ).append( " from IVR_MUTUAL_FUND IMF" ).append( " where IMF.CALL_FLOW_ID = IMFC.CALL_FLOW_ID" ).append( "     and IMF.IVR_MUTUAL_FUND_CATEGORY_ID = IMFC.IVR_MUTUAL_FUND_CATEGORY_ID) as FUND_CNT" ).append( " from IVR_MUTUAL_FUND_CATEGORY IMFC" ).append( " where CALL_FLOW_ID = :CALL_FLOW_ID" );
    
    private static final StringBuilder GET_IVR_FUND_DETAILS    = new StringBuilder().append( " select IMF.CALL_FLOW_ID, IMF.IVR_MUTUAL_FUND_ID, IMF.IVR_MUTUAL_FUND_CATEGORY_ID, IMFC.IVR_CATEGORY_NM, IMF.FUND_CODE, IR.ENGLISH_SCRIPT_TXT, IMF.IVR_MUTUAL_FUND_ACTIVE_IND, IMF.CALL_FLOW_TRANSFER_NUMBER_ID, CFTN.TRANSFER_NUMBER_NM, IMF.LAST_MAINTENANCE_ID" ).append( " from IVR_MUTUAL_FUND IMF" ).append( " left outer join  IVR_MUTUAL_FUND_CATEGORY IMFC" ).append( " on IMFC.CALL_FLOW_ID = IMF.CALL_FLOW_ID" ).append( " and IMFC.IVR_MUTUAL_FUND_CATEGORY_ID = IMF.IVR_MUTUAL_FUND_CATEGORY_ID" ).append( " left outer join CALL_FLOW_TRANSFER_NUMBER CFTN" ).append( " on CFTN.CALL_FLOW_ID = IMF.CALL_FLOW_ID" ).append( " and CFTN.CALL_FLOW_TRANSFER_NUMBER_ID = IMF.CALL_FLOW_TRANSFER_NUMBER_ID" ).append( " left outer join IVR_RECORDING IR" ).append( " on IR.RECORDING_ID = IMF.NAME_RECORDING_ID" ).append( " where IMF.CALL_FLOW_ID = :CALL_FLOW_ID" );
    
    private final static Logger        LOG                     = LoggerFactory.getLogger( IvrMutualFundDaoImpl.class );
    
    public List<IvrMutualFund> getAll()
    {
        List<IvrMutualFund> ivrMutualFundList = null;
        try
        {
            ivrMutualFundList = getNamedParameterJdbcOperations().query( GET_ALL.toString(),
                                                                         new IvrMutualFundRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return ivrMutualFundList;
    }
    
    public List<IvrMutualFundCategory> getFundCategories( int callFlowId )
    {
        List<IvrMutualFundCategory> ivrMutualFundCategory = null;
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                              callFlowId );
        try
        {
            ivrMutualFundCategory = getNamedParameterJdbcOperations().query( GET_IVR_FUND_CATEGORIES.toString(),
                                                                             parameters,
                                                                             new IvrMutualFundCategoryRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return ivrMutualFundCategory;
    }
    
    public List<IvrMutualFund> getFundDetails( int callFlowId )
    {
        List<IvrMutualFund> ivrMutualFundList = null;
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                              callFlowId );
        try
        {
            ivrMutualFundList = getNamedParameterJdbcOperations().query( GET_IVR_FUND_DETAILS.toString(),
                                                                         parameters,
                                                                         new IvrMutualFundRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return ivrMutualFundList;
    }
    
}
