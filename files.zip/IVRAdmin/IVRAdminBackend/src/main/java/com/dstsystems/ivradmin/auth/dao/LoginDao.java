/*
 * FILE : LoginDao.java
 *
 * CLASS : LoginDao
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.naming.directory.DirContext;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.ldap.NamingException;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.AbstractContextMapper;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.stereotype.Component;

import com.dstsystems.ivradmin.auth.config.LdapConfiguration;
import com.dstsystems.ivradmin.auth.constants.LdapAttribute;
import com.dstsystems.ivradmin.auth.domain.Associate;
import com.dstsystems.ivradmin.auth.domain.LoginRequest;
import com.dstsystems.ivradmin.auth.domain.LoginResponse;
import com.dstsystems.ivradmin.auth.domain.Permissions;
import com.dstsystems.ivradmin.core.domain.ErrorBean;

import lombok.extern.slf4j.Slf4j;

/**
 * The LoginDao handles authenticating the Associate in the given
 * {@link LoginRequest}. It returns a {@link LoginResponse} containing the
 * authenticated user's information. If an error is encountered during this
 * process, one or more {@link ErrorBean}s are added to the response describing
 * the issue.
 * 
 * @author DT63314
 */
@Component
@Slf4j
public class LoginDao
{
    /**
     * Private helper with a set of messages for errors encountered in
     * this class.
     */
    private enum LoginError
    {
     LOGIN1( "domain", "Domain is not recognized, please try again." ),
     LOGIN2( "credentials",
             "Login failed! Your user name or password was not recognized." ),
     LOGIN3( "exception", "A severe error occurred during login attempt." );
        
        final String key;
        final String message;
        
        private LoginError( String key, String message )
        {
            this.key = key;
            this.message = message;
        }
    }
    
    private ApplicationContext applicationContext;
    
    /**
     * Constructs the LoginDao with an autowired applicationContext. 
     * @param applicationContext
     */
    public LoginDao( ApplicationContext applicationContext )
    {
        this.applicationContext = applicationContext;
    }
    
    /**
     * Authenticates the user against the user's selected domain. Returns an
     * Associate if login is successful, otherwise adds one or more error
     * messages to the response if authentication fails.
     * 
     * @param loginRequest
     *            - the request containing the user's credentials and the login
     *            domain.
     * @return the LoginRepsonse.
     */
    public LoginResponse authenticate( LoginRequest loginRequest )
    {
        
        LoginResponse loginResponse = new LoginResponse();
        Permissions associatePermissions = new Permissions();
        List<ErrorBean> errors = new ArrayList<>();
        DirContext context = null;
        ArrayList<String> permList = new ArrayList<String>();
        
        try
        {
            LdapTemplate ldapTemplate = applicationContext.getBean( loginRequest.getDomain(),
                                                                    LdapTemplate.class );
            
            String baseDN = LdapConfiguration.getBaseDNFor( loginRequest.getDomain() );
            
            // Use credentials to authenticate with AD
            // Throws NamingException for invalid credentials
            context = ldapTemplate.getContextSource().getContext( loginRequest.getUserName().concat( baseDN ),
                                                                  loginRequest.getPassword() );
            
            AndFilter andFilter = new AndFilter();
            andFilter.and( new EqualsFilter( LdapAttribute.SAM_ACCOUNT_NAME.value,
                                             loginRequest.getUserName() ) );
            
            // Get the properties associated with this user.
            Associate associate = ldapTemplate.searchForObject( "",
                                                                andFilter.encode(),
                                                                new AssociateContextMapper() );
            associate.setId( loginRequest.getUserName() );
            
            //Get the Permissions for the groups that the user belongs to.
            AndFilter andFilterPermGrp = new AndFilter();
            for (int i =0; i < associate.getDN().length; i++)
            {
            	andFilterPermGrp.and( new EqualsFilter( LdapAttribute.DISTINGUISHED_NAME.value,
            			associate.getDN()[i]) );
            	try {
            		associatePermissions = ldapTemplate.searchForObject( "",
                         andFilterPermGrp.encode(),
                         new PermissionsContextMapper() );
            		permList.addAll(convertList(associatePermissions.getPermissionList()));
            	}catch (Exception e) {
					//if there is an error, don't load anything to the permission list for this particular role
				}           	
            }
            associate.setPermissions( permList.toArray(new String[0]) );
            
            loginResponse.setAssociate( associate );
            
        }
        catch( BeansException ex )
        {
            log.warn( "Error fetching bean for {}.", loginRequest.getDomain() );
            errors.add( new ErrorBean( LoginError.LOGIN1.key,
                                       LoginError.LOGIN1.message ) );
        }
        catch( NamingException | IncorrectResultSizeDataAccessException ex )
        {
            log.warn( "Error with credentials: {}", ex.getMessage() );
            errors.add( new ErrorBean( LoginError.LOGIN2.key,
                                       LoginError.LOGIN2.message ) );
        }
        catch( Exception ex )
        {
            log.warn( "Severe exception: {}", ex.getMessage() );
            errors.add( new ErrorBean( LoginError.LOGIN3.key,
                                       LoginError.LOGIN3.message ) );
        }
        finally
        {
            // closeContext ignores exceptions.
            LdapUtils.closeContext( context );
        }
        
        loginResponse.setErrors( errors );
        
        return loginResponse;
    }


	/**
     * Maps the data that comes back from LDAP to the Associate bean.
     * 
     */
    private static class AssociateContextMapper extends AbstractContextMapper<Associate>
    {
        @Override
        protected Associate doMapFromContext( DirContextOperations ctx )
        {
            
            Associate associate = new Associate();
            ArrayList<String> roleList = new ArrayList<String>();
            associate.setFirstName( ctx.getStringAttribute( LdapAttribute.GIVEN_NAME.value ) );
            associate.setLastName( ctx.getStringAttribute( LdapAttribute.SURNAME.value ) );
            associate.setEmail( ctx.getStringAttribute( LdapAttribute.EMAIL.value ) );
            associate.setDN( filterIVRRoles((ctx.getStringAttributes( LdapAttribute.MEMBER_OF.value ))));
            for(int i=0;i<associate.getDN().length;i++)
            {
            	roleList.add( associate.getDN()[i].substring(associate.getDN()[i].indexOf("CN=")+3, associate.getDN()[i].indexOf(",")));
            }
            associate.setRole(roleList);
            
            return associate;
        }
    }
    
    /**
     * Maps the data that comes back from LDAP to the Permissions bean.
     * 
     */
    private static class PermissionsContextMapper extends AbstractContextMapper<Permissions>
    {
        @Override
        protected Permissions doMapFromContext( DirContextOperations ctx )
        {
            
            Permissions permission = new Permissions();
            String[] permList = ctx.getStringAttributes( LdapAttribute.MEMBER_OF.value );
            for(int i=0; i<permList.length;i++)
            {
            	permList[i] = permList[i].substring(permList[i].indexOf("CN=")+3, permList[i].indexOf(","));
            }
            permission.setPermissionList( permList );
            permission.setRole(ctx.getStringAttribute( LdapAttribute.SAM_ACCOUNT_NAME.value ));
            return permission;
        }
        
    }

	/**
	 * This method will filter out non-IVR roles.
	 * @param role
	 * @return String Array
	 */
	public static String[] filterIVRRoles(String[] role) {
		ArrayList<String> ivrRole = new ArrayList<String>();

		for(int i = 0; i < role.length; i++)
		{
			if(role[i].contains("G-IVR"))
			{
				ivrRole.add(role[i]);

			}
		}
		return (String[]) ivrRole.toArray(new String[0]);
	}
	
    

    /**
     * Converts the String array into an ArrayList. This can be reused.
     * @param inputStringArray
     * @return ArrayList
     */
    private Collection<? extends String> convertList(String[] inputStringArray) {
    	ArrayList<String> list = new ArrayList<String>();
    	
    	for(int i=0; i < inputStringArray.length; i++)
    	{
    		list.add(inputStringArray[i]);
    	}
    	
		return list;
	}
    
}
