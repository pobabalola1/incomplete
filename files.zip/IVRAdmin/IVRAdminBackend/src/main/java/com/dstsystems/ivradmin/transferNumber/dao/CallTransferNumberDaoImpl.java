package com.dstsystems.ivradmin.transferNumber.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.transferNumber.bean.CallTransferNumber;
import com.dstsystems.ivradmin.transferNumber.bean.CallTransferNumberShowHours;
import com.dstsystems.ivradmin.transferNumber.mapper.CallTransferNumberDistinctRowMapper;
import com.dstsystems.ivradmin.transferNumber.mapper.OpenCloseDateRowMapper;

/**
 * The CallTransferNumberDaoImpl handles all getting data list from DB
 * 
 * @author DT77649
 */
@Repository
public class CallTransferNumberDaoImpl extends BaseJdbcDAO {

	private static final String CALL_FLOW_ID = "CALL_FLOW_ID";
	private static final String CALL_FLOW_TRANSFER_NUMBER_ID = "CALL_FLOW_TRANSFER_NUMBER_ID";	
	List< CallTransferNumberShowHours > callTransferNumberShowHours = null;

	private final static Logger     LOG = LoggerFactory.getLogger( CallTransferNumberDaoImpl.class );

	private static final StringBuilder GET_ALL_BY_CALL_FLOW = new StringBuilder()
	
			.append(" select  DISTINCT DCTN.TRANSFER_NUMBER_NM, DCTN.TRANSFER_UNFORMATTED_PHONE_NBR, DCTN.USE_INTELLIGENT_TRANSFER_IND, DCTN.DEFAULT_IND, DCTN.CALL_FLOW_TRANSFER_NUMBER_ID ")
			.append(" from    CALL_FLOW CF "
					          + " INNER JOIN CALL_FLOW_TRANSFER_NUMBER DCTN ON CF.CALL_FLOW_ID = DCTN.CALL_FLOW_ID "
					          + " INNER JOIN CALL_FLOW_TRANSFER_BUSINESS_HOURS DCTB ON DCTN.CALL_FLOW_ID = DCTB.CALL_FLOW_ID "
					          + " INNER JOIN CODE_SET_VALUE CSV ON DCTB.DAY_OF_WEEK_CVID = CSV.CODE_SET_VALUE_ID "
					          + " INNER JOIN CODE_SET CS ON CS.CODE_SET_ID = CSV.CODE_SET_ID ")
	        .append(" where  (( CURDATE() BETWEEN CSV.EFFECTIVE_DT AND CSV.EXPIRATION_DT ) OR (CSV.EFFECTIVE_DT <= CURDATE() and CSV.EXPIRATION_DT is null)) "
	        		          + " and (( CURDATE() BETWEEN CS.EFFECTIVE_DT AND CS.EXPIRATION_DT ) OR (CS.EFFECTIVE_DT <= CURDATE() and CS.EXPIRATION_DT is null) ) "
	                          + " and CF.CALL_FLOW_ID = :CALL_FLOW_ID; ");
	
	private static final StringBuilder GET_OPEN_CLOSE_CODESET_ID_2 = new StringBuilder()
			.append(" select  DATE_FORMAT(DCTB.OPEN_TM, '%H:%i %p') as OPEN_TM, DATE_FORMAT(DCTB.CLOSED_TM, '%H:%i %p') as CLOSED_TM, CSV.CODE_SET_VALUE_ABBREVIATED_NM ")
			.append(" from	CALL_FLOW CF "
					          + " INNER JOIN CALL_FLOW_TRANSFER_NUMBER DCTN ON CF.CALL_FLOW_ID = DCTN.CALL_FLOW_ID "
					          + " INNER JOIN CALL_FLOW_TRANSFER_BUSINESS_HOURS DCTB ON DCTN.CALL_FLOW_ID = DCTB.CALL_FLOW_ID "
					          + " INNER JOIN CODE_SET_VALUE CSV ON DCTB.DAY_OF_WEEK_CVID = CSV.CODE_SET_VALUE_ID "
					          + " INNER JOIN CODE_SET CS ON CS.CODE_SET_ID = CSV.CODE_SET_ID ")
	        .append(" where  (( CURDATE() BETWEEN CSV.EFFECTIVE_DT AND CSV.EXPIRATION_DT ) OR (CSV.EFFECTIVE_DT <= CURDATE() and CSV.EXPIRATION_DT is null) ) "
	        		          + " and (( CURDATE() BETWEEN CS.EFFECTIVE_DT AND CS.EXPIRATION_DT ) OR (CS.EFFECTIVE_DT <= CURDATE() and CS.EXPIRATION_DT is null) ) "
	        		          + " and CF.CALL_FLOW_ID = :CALL_FLOW_ID " );
	
	private static final StringBuilder GET_OPEN_CLOSE_CODESET_ID_OVERRIDE = new StringBuilder()
			.append(" select DATE_FORMAT(CFTNH.OPEN_TM, '%H:%i %p') as OPEN_TM, DATE_FORMAT(CFTNH.CLOSED_TM, '%H:%i %p') as CLOSED_TM, CSV.CODE_SET_VALUE_ABBREVIATED_NM ")
			.append(" from	CALL_FLOW CF "
					          + " INNER JOIN CALL_FLOW_TRANSFER_NUMBER DCTN ON CF.CALL_FLOW_ID = DCTN.CALL_FLOW_ID "
					          + " INNER JOIN CALL_FLOW_TRANSFER_NUMBER_HOURS CFTNH ON DCTN.CALL_FLOW_ID = CFTNH.CALL_FLOW_ID and DCTN.CALL_FLOW_TRANSFER_NUMBER_ID = CFTNH.CALL_FLOW_TRANSFER_NUMBER_ID "
					          + " INNER JOIN CODE_SET_VALUE CSV ON CFTNH.DAY_OF_WEEK_CVID = CSV.CODE_SET_VALUE_ID "
					          + " INNER JOIN CODE_SET CS ON CS.CODE_SET_ID = CSV.CODE_SET_ID ")
	        .append(" where  (( CURDATE() BETWEEN CSV.EFFECTIVE_DT AND CSV.EXPIRATION_DT ) OR (CSV.EFFECTIVE_DT <= CURDATE() and CSV.EXPIRATION_DT is null) ) "
	        		          + " and (( CURDATE() BETWEEN CS.EFFECTIVE_DT AND CS.EXPIRATION_DT ) OR (CS.EFFECTIVE_DT <= CURDATE() and CS.EXPIRATION_DT is null) ) "
	        		          + " and CF.CALL_FLOW_ID = :CALL_FLOW_ID "
	        		          + " and CFTNH.CALL_FLOW_TRANSFER_NUMBER_ID = :CALL_FLOW_TRANSFER_NUMBER_ID" );

    /**
     * Getting CallTransferNumber data list by using Call Flow Id
     * @param callFlowId
     */
	public List< CallTransferNumber > getByCallFlowIdDistinct( int callFlowId )
    {
		SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID, callFlowId );
    	List< CallTransferNumber > assetManagementDnisCallTransferNumber = null; 
    	try 
    	{
    		assetManagementDnisCallTransferNumber = getNamedParameterJdbcOperations().query( GET_ALL_BY_CALL_FLOW.toString(), 
    				parameters, 
    				new CallTransferNumberDistinctRowMapper() );
    		assetManagementDnisCallTransferNumber = makeList ( assetManagementDnisCallTransferNumber, callFlowId );
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return assetManagementDnisCallTransferNumber;
    }
	
    /**
     * Getting Date Time shift data by using Code Set Id key
     * @param callFlowId
     */
	public List< CallTransferNumberShowHours > getDateTimeShift ( int callFlowId )
    {
		SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID, callFlowId );
		List< CallTransferNumberShowHours > results = new ArrayList<>();
		try 
    	{
    		callTransferNumberShowHours = getNamedParameterJdbcOperations().query( GET_OPEN_CLOSE_CODESET_ID_2.toString(), 
    				parameters, 
    				new OpenCloseDateRowMapper() );
    		
    		int resultSize = 0;
    		CallTransferNumberShowHours resultTemp = null;
    		
    		for (int i = 0;i<callTransferNumberShowHours.size();i++) {
    			CallTransferNumberShowHours fromDb = callTransferNumberShowHours.get(i);
    			if( i == 0 ) {
    				//first round
    				results.add(fromDb);
    			}
    			else {
    				resultSize = results.size();
    				resultTemp = results.get(resultSize-1);//get last item
    				if( resultTemp.getTimeStart().equals(fromDb.getTimeStart()) 
    						&& resultTemp.getTimeEnd().equals(fromDb.getTimeEnd()) ) {
    					//case: same open close time. So, need to group time
    					//setting next DateEnd into this row
    					results.get(resultSize-1).setDateEnd(fromDb.getDateEnd());
    				}
    				else {
    					//case: new open close time
    					results.add(fromDb);
    				}
    			}
    		}	
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return results;
    }
	
	/**
     * Getting Date Time shift data when user override it by using Code Set Id key
     * @param callFlowId
     */
	public List< CallTransferNumberShowHours > getDateTimeShiftOverride ( int callFlowId, int callFlowTransferNumberId )
    {
		SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID, callFlowId ).addValue(CALL_FLOW_TRANSFER_NUMBER_ID, callFlowTransferNumberId);
		List< CallTransferNumberShowHours > results = new ArrayList<>();
		try 
    	{
    		callTransferNumberShowHours = getNamedParameterJdbcOperations().query( GET_OPEN_CLOSE_CODESET_ID_OVERRIDE.toString(), 
    				parameters, 
    				new OpenCloseDateRowMapper() );
    		
    		int resultSize = 0;
    		CallTransferNumberShowHours resultTemp = null;
    		
    		for (int i = 0;i<callTransferNumberShowHours.size();i++) {
    			CallTransferNumberShowHours fromDb = callTransferNumberShowHours.get(i);
    			if( i == 0 ) {
    				//first round
    				results.add(fromDb);
    			}
    			else {
    				resultSize = results.size();
    				resultTemp = results.get(resultSize-1);//get last item
    				if( resultTemp.getTimeStart().equals(fromDb.getTimeStart()) 
    						&& resultTemp.getTimeEnd().equals(fromDb.getTimeEnd()) ) {
    					//case: same open close time. So, need to group time
    					//setting next DateEnd into this row
    					results.get(resultSize-1).setDateEnd(fromDb.getDateEnd());
    				}
    				else {
    					//case: new open close time
    					results.add(fromDb);
    				}
    			}
    		}	
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return results;
    }
	
    /**
     * Making open-close time list to display for any cards 
     * @param showCallTransNumList
     * @param callFlowId
     */
	public List< CallTransferNumber > makeList ( List< CallTransferNumber > showCallTransNumList, int callFlowId )
    {
		try 
    	{
			if ( null != showCallTransNumList && showCallTransNumList.size() > 0 ) {
			
				for(int i=0; i<showCallTransNumList.size(); i++) {
					if( showCallTransNumList.get(i).getIsDefaultInd().equalsIgnoreCase("Y") )
					{	//use default Open-Close time set up.
						List< CallTransferNumberShowHours > dnisCallTransferNumberHours = this.getDateTimeShift(callFlowId);
						showCallTransNumList.get(i).setDnisCallTransferNumberHours(dnisCallTransferNumberHours);
					}
					else 
					{
						//Some card edited Open-Close time
						List< CallTransferNumberShowHours > dnisCallTransferNumberHours = this.getDateTimeShiftOverride(callFlowId, showCallTransNumList.get(i).getAssetManagementDnisCallTransferNumberId());
						showCallTransNumList.get(i).setDnisCallTransferNumberHours(dnisCallTransferNumberHours);
					}
				}
			}	
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return showCallTransNumList;
    }
	
}
