/*
 * FILE : BaseController.java
 *
 * CLASS : BaseController
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * This is the BaseController Class that is going to be extended in all controllers. 
 * This sets the /api path in the JSON Request.
 * @author dt76669
 * 
 */
@RequestMapping(path = "/api" ,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public abstract class BaseController {
	
}
