/*
 * FILE : AdminSessionAttributes.java
 *
 * CLASS : AdminSessionAttributes
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.session.domain;

import java.io.Serializable;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import com.dstsystems.ivradmin.auth.domain.Associate;

import lombok.Data;

/**
 * Domain class responsible for acting as the session data placeholder. Data added to this class must be Serializable themselves.
 * 
 * @author dt63314
 *
 */
@Component
@SessionScope
@Data
public class AdminSessionAttributes implements Serializable
{
    private static final long serialVersionUID = -152404208589075790L;
    
    private Associate         associate;
    
}
