package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.domain.LineOfBusinessClient;

public class LineOfBusinessClientRowMapper implements RowMapper<LineOfBusinessClient>
{
   
   private final String IVR_CLIENT_ID        = "IVR_CLIENT_ID";
   private final String LINE_OF_BUSINESS_ID  = "LINE_OF_BUSINESS_ID"; 
   private final String FUND_SPONSOR_ID      = "FUND_SPONSOR_ID";  
   private final String IVR_CLIENT_NM        = "IVR_CLIENT_NM";
   private final String SYSTEM_ID            = "SYSTEM_ID"; 
   
   private final String CLIENT_NAME_STR      = "CLIENT NAME";

   
   @Override
   public LineOfBusinessClient mapRow( ResultSet rs, int rowNum ) throws SQLException
   {
      LineOfBusinessClient lineOfBusinessClient = new LineOfBusinessClient();
      lineOfBusinessClient.setIvrClientId( rs.getInt( IVR_CLIENT_ID ) );
      lineOfBusinessClient.setLineOfBusinessId( rs.getInt( LINE_OF_BUSINESS_ID ) );
      lineOfBusinessClient.setFundSponsorId( rs.getInt( FUND_SPONSOR_ID ) );
      lineOfBusinessClient.setIvrClientName( rs.getString( IVR_CLIENT_NM ) );
      lineOfBusinessClient.setSystemId( rs.getString( SYSTEM_ID ) );
      return lineOfBusinessClient;
   }
   
   
}
