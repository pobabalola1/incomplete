package com.dstsystems.ivradmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.dao.AssetManagementDnisCallTransferNumberDaoImpl;
import com.dstsystems.ivradmin.domain.AssetManagementDnisCallTransferNumber;

@RestController
public class AssetManagementDnisCallTransferNumberController {
	
	@Autowired
	private AssetManagementDnisCallTransferNumberDaoImpl assetManagementDnisCallTransferNumberDaoImpl;
	
	@RequestMapping(path = "/api/data/asset-management-dnises-call-transfer-numbers" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List< AssetManagementDnisCallTransferNumber > getAll()
    {
		return assetManagementDnisCallTransferNumberDaoImpl.getAll();
    }
}
