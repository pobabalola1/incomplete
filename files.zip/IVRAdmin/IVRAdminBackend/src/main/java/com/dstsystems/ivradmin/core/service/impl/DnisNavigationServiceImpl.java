/*
 * FILE : TouchToneNavigationService.java
 *
 * CLASS : TouchToneNavigationService
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dstsystems.ivradmin.core.dao.DnisTouchToneNavigationDao;
import com.dstsystems.ivradmin.core.domain.DnisNavigationCache;
import com.dstsystems.ivradmin.core.exception.DaoException;
import com.dstsystems.ivradmin.core.service.GlobalDetailsDnisService;

/**
 * The Navigation Service is designed to provide access to data contained in the MF-TT-Nav-[DNIS].xml files. This class 
 * handles the relationships between the XML document and provides methods for locating, storing, and updating cached 
 * information derived from these XML documents.
 * 
 * @author dt63314
 *
 */
@Service
public class DnisNavigationServiceImpl implements GlobalDetailsDnisService
{
    
    private DnisTouchToneNavigationDao dnisTouchToneNavigationDao;
    
    @Autowired
    public void setDnisTouchToneNavigationDao( DnisTouchToneNavigationDao dnisTouchToneNavigationDao )
    {
        this.dnisTouchToneNavigationDao = dnisTouchToneNavigationDao;
    }
    
    @Override
    public DnisNavigationCache getDnisNavigation( String dnis ) throws DaoException
    {
        return dnisTouchToneNavigationDao.getDnisNavigationCacheFor( dnis );
    }
}
