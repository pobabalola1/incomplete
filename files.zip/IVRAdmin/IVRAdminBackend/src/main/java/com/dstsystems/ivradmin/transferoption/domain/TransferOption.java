/**
 * 
 */
package com.dstsystems.ivradmin.transferoption.domain;

import java.util.List;

import com.dstsystems.ivradmin.core.domain.CallFlowExt;

import lombok.Builder;
import lombok.Data;

/**
 * @author dt86783
 *
 */
@Data
@Builder
public class TransferOption
{
   private CallFlowExt callFlow;
   private List< TransferHierarchy > transferHierarchies;
}
