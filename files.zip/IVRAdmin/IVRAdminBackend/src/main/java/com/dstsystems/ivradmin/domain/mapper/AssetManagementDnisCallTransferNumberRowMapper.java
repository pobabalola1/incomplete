package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.domain.AssetManagementDnisCallTransferNumber;

public class AssetManagementDnisCallTransferNumberRowMapper implements RowMapper<AssetManagementDnisCallTransferNumber> {
	
	private final String DNIS_Id = "DNIS_Id";
	private final String Asset_Management_DNIS_Call_Transfer_Number_Id = "Asset_Management_DNIS_Call_Transfer_Number_Id";
	private final String Last_Maintenance_Timestamp = "Last_Maintenance_Timestamp";
	private final String Last_Maintenance_Id = "Last_Maintenance_Id";
	private final String Phone_Number = "Phone_Number";
	private final String Description_Text = "Description_Text";
	private final String Default_Indicator = "Default_Indicator";
	
	@Override
	public AssetManagementDnisCallTransferNumber mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		AssetManagementDnisCallTransferNumber assetManagementDnisCallTransferNumber = new AssetManagementDnisCallTransferNumber();
		assetManagementDnisCallTransferNumber.setDnisId( rs.getInt( DNIS_Id ) );
		assetManagementDnisCallTransferNumber.setAssetManagementDNISTransferNumberId( rs.getInt( Asset_Management_DNIS_Call_Transfer_Number_Id ) );
		assetManagementDnisCallTransferNumber.setLastMaintenanceTimestamp( rs.getDate( Last_Maintenance_Timestamp ) );
		assetManagementDnisCallTransferNumber.setLastMaintenanceId( rs.getString( Last_Maintenance_Id ) );
		assetManagementDnisCallTransferNumber.setPhoneNumber( rs.getString( Phone_Number ) );
		assetManagementDnisCallTransferNumber.setDescriptionText( rs.getString( Description_Text ) );
		assetManagementDnisCallTransferNumber.setDefaultIndicator( rs.getString( Default_Indicator ) );
		return assetManagementDnisCallTransferNumber;
	}
}
