package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.fund.domain.IvrMutualFund;

public class IvrMutualFundRowMapper implements RowMapper<IvrMutualFund>
{
    
    private final String CALL_FLOW_ID                 = "CALL_FLOW_ID";
    private final String IVR_MUTUAL_FUND_ID           = "IVR_MUTUAL_FUND_ID";
    private final String IVR_MUTUAL_FUND_CATEGORY_ID  = "IVR_MUTUAL_FUND_CATEGORY_ID";
    private final String IVR_CATEGORY_NM              = "IVR_CATEGORY_NM";
    private final String FUND_CODE                    = "FUND_CODE";
    private final String ENGLISH_SCRIPT_TXT           = "ENGLISH_SCRIPT_TXT";
    private final String IVR_MUTUAL_FUND_ACTIVE_IND   = "IVR_MUTUAL_FUND_ACTIVE_IND";
    private final String CALL_FLOW_TRANSFER_NUMBER_ID = "CALL_FLOW_TRANSFER_NUMBER_ID";
    private final String TRANSFER_NUMBER_NM           = "TRANSFER_NUMBER_NM";
    private final String LAST_MAINTENANCE_ID          = "LAST_MAINTENANCE_ID";
    
    
    @Override
    public IvrMutualFund mapRow( ResultSet rs, int rowNum ) throws SQLException
    {
        IvrMutualFund ivrMutualFund = new IvrMutualFund();
        ivrMutualFund.setCallFlowId( rs.getInt( CALL_FLOW_ID ) );
        ivrMutualFund.setIvrMutualFundId( rs.getInt( IVR_MUTUAL_FUND_ID ) );
        ivrMutualFund.setLastMaintenanceOperatorId( rs.getString( LAST_MAINTENANCE_ID ) );
        ivrMutualFund.setIvrMutualFundCategoryId( rs.getInt( IVR_MUTUAL_FUND_CATEGORY_ID ) );
        ivrMutualFund.setIvrFundCatNm( rs.getString( IVR_CATEGORY_NM ) );
        ivrMutualFund.setActivityCd( rs.getString( IVR_MUTUAL_FUND_ACTIVE_IND ).equalsIgnoreCase( "Y" ) );
        ivrMutualFund.setTransferNumId( rs.getInt( CALL_FLOW_TRANSFER_NUMBER_ID ) );
        ivrMutualFund.setTransferNumNm( rs.getString( TRANSFER_NUMBER_NM ) );
        ivrMutualFund.setIvrFundCd( rs.getInt( FUND_CODE ) );
        ivrMutualFund.setIvrFundNm( rs.getString( ENGLISH_SCRIPT_TXT ) );
        
        return ivrMutualFund;
    }
    
}
