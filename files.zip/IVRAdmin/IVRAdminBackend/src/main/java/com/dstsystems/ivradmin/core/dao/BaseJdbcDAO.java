package com.dstsystems.ivradmin.core.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;


public abstract class BaseJdbcDAO
{
    private NamedParameterJdbcOperations namedParameterJdbcOperations;
    /*
     * Ordinarily I would not suppress an "unused" warning, but in this case we need to retain a reference to the Spring-managed 
     * DataSource in order for {@link StatCaptureJdbcAspect} to capture method executions.
     */
    @SuppressWarnings("unused")
    private DataSource                   dataSource;
    
    @Autowired
    public void init( DataSource dataSource )
    {
        this.dataSource = dataSource;
    }
    
    @Autowired
    public void setNamedParameterJdbcOperations( NamedParameterJdbcOperations namedParameterJdbcOperations )
    {
        this.namedParameterJdbcOperations = namedParameterJdbcOperations;
    }
    
    public NamedParameterJdbcOperations getNamedParameterJdbcOperations()
    {
        return namedParameterJdbcOperations;
    }
}
