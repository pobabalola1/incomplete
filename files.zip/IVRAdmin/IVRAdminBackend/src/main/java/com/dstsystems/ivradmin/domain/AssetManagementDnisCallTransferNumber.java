package com.dstsystems.ivradmin.domain;

import java.util.Date;

public class AssetManagementDnisCallTransferNumber {

	private Integer dnisId;
	private Integer assetManagementDNISTransferNumberId;
	private Date lastMaintenanceTimestamp;
	private String lastMaintenanceId;
	private String phoneNumber;
	private String descriptionText;
	private String defaultIndicator;
	
	/**
	 * @return the dnisId
	 */
	public Integer getDnisId() {
		return dnisId;
	}

	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setDnisId(Integer dnisId) {
		this.dnisId = dnisId;
	}

	/**
	 * @return the assetManagementDNISTransferNumberId
	 */
	public Integer getAssetManagementDNISTransferNumberId() {
		return assetManagementDNISTransferNumberId;
	}

	/**
	 * @param assetManagementDNISTransferNumberId
	 *            the assetManagementDNISTransferNumberId to set
	 */
	public void setAssetManagementDNISTransferNumberId(Integer assetManagementDNISTransferNumberId) {
		this.assetManagementDNISTransferNumberId = assetManagementDNISTransferNumberId;
	}

	/**
	 * @return the lastMaintenanceTimestamp
	 */
	public Date getLastMaintenanceTimestamp() {
		return lastMaintenanceTimestamp;
	}

	/**
	 * @param lastMaintenanceTimestamp
	 *            the lastMaintenanceTimestamp to set
	 */
	public void setLastMaintenanceTimestamp(Date lastMaintenanceTimestamp) {
		this.lastMaintenanceTimestamp = lastMaintenanceTimestamp;
	}

	/**
	 * @return the lastMaintenanceId
	 */
	public String getLastMaintenanceId() {
		return lastMaintenanceId;
	}

	/**
	 * @param lastMaintenanceId
	 *            the lastMaintenanceId to set
	 */
	public void setLastMaintenanceId(String lastMaintenanceId) {
		this.lastMaintenanceId = lastMaintenanceId;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber
	 *            the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the descriptionText
	 */
	public String getDescriptionText() {
		return descriptionText;
	}

	/**
	 * @param descriptionText
	 *            the descriptionText to set
	 */
	public void setDescriptionText(String descriptionText) {
		this.descriptionText = descriptionText;
	}

	/**
	 * @return the defaultIndicator
	 */
	public String getDefaultIndicator() {
		return defaultIndicator;
	}

	/**
	 * @param defaultIndicator
	 *            the defaultIndicator to set
	 */
	public void setDefaultIndicator(String defaultIndicator) {
		this.defaultIndicator = defaultIndicator;
	}
	
}
