package com.dstsystems.ivradmin.transferNumber.bean;

import java.util.List;

import lombok.Data;

/**
 * Bean that will keep CallTransferNumber data from Backend to Frontend for display.
 * 
 * @author dt77649
 */
@Data
public class CallTransferNumber {

	private String name;
	private String phoneNumber;
	private String isDefaultInd;
	private String isUseIntTransInd;
	private int assetManagementDnisCallTransferNumberId;
	private List<CallTransferNumberShowHours> dnisCallTransferNumberHours;
	
}
