/**
 * 
 */
package com.dstsystems.ivradmin.core.dao;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.domain.CodeSetValueDisplay;
import com.dstsystems.ivradmin.core.domain.IVRRecording;
import com.dstsystems.ivradmin.core.domain.mapper.IVRRecordingRowMapper;

/**
 * @author dt86783
 *
 */
@Repository
public class IVRRecordingDaoImpl extends BaseJdbcDAO
{
   @Autowired
   private IVRRecordingRowMapper ivrRowMapper;
   
   @Autowired
   private CodeSetValueDaoImpl codeSetValueDaoImpl;
   
   private static final String        RECORDING_ID = "RECORDING_ID";
   private static final String        RECORDING_IDS = "RECORDING_IDS";
   
   private static final StringBuilder GET_ALL = new StringBuilder()
         .append("SELECT  IVR.RECORDING_ID, ") 
         .append("        IVR.GENDER_CD, ")
         .append("        IVR.RECORDING_TYPE_CVID, ")
         .append("        IVR.REQUESTOR_ID, ")
         .append("        IVR.IVR_LANGUAGE_CVID, ")
         .append("        IVR.ENGLISH_SCRIPT_TXT, ")
         .append("        IVR.STATUS_CVID, ")
         .append("        IVR.ALTERNATE_LANGUAGE_SCRIPT_TXT, ")
         .append("        IVR.NOTES_TXT ")
         .append("FROM    IVR_RECORDING IVR");

   
   private static final StringBuilder GET_BY_RECORDING_ID = new StringBuilder()
         .append(  GET_ALL.toString() ).append( " " )
         .append("WHERE   IVR.RECORDING_ID = :RECORDING_ID");
   
    private static final StringBuilder GET_BY_RECORDING_IDS = new StringBuilder()
         .append(  GET_ALL.toString() ).append( " " )
         .append("WHERE   IVR.RECORDING_ID IN (:RECORDING_IDS)");
    
    private final static Logger        LOG            = LoggerFactory.getLogger( IVRRecordingDaoImpl.class );
    
    public List< IVRRecording > getAll()
    {
       List< IVRRecording > ivrList = null;
       
       try
       {
          ivrList = getNamedParameterJdbcOperations().query( GET_ALL.toString(), ivrRowMapper );
          fillCodeSetValue( ivrList );
       }
       catch( Exception e )
       {
          LOG.error( e.getMessage() );
       }
       
       return ivrList;
    }
    
    public IVRRecording getById( Integer id )
    {
       SqlParameterSource parameters = new MapSqlParameterSource().addValue( RECORDING_ID,
                                                                             id );
       
       IVRRecording ivr = null;
       
       try
       {
          ivr = getNamedParameterJdbcOperations().queryForObject( GET_BY_RECORDING_ID.toString(), parameters, ivrRowMapper );
          fillCodeSetValue( Collections.singletonList( ivr ) );
       }
       catch( Exception e )
       {
          LOG.error( e.getMessage() );
       }
       
       return ivr;
    } 
    
    public List< IVRRecording > getByIds( Set< Integer > ids )
    {
       SqlParameterSource parameters = new MapSqlParameterSource().addValue( RECORDING_IDS,
                                                                             ids );
       
       List< IVRRecording > ivrList = null;
       
       try
       {
          ivrList = getNamedParameterJdbcOperations().query( GET_BY_RECORDING_IDS.toString(), parameters, ivrRowMapper );
          fillCodeSetValue( ivrList );
       }
       catch( Exception e )
       {
          LOG.error( e.getMessage() );
       }
       
       return ivrList;
    }
    
    public Map< Integer, IVRRecording > getByIdsAsMap( Set< Integer > ids )
    {
       List< IVRRecording > ivrList = null;
       Map< Integer, IVRRecording > ivrMap = null;
       
       ivrList = getByIds( ids );
       
       ivrMap = ivrList.stream().collect( Collectors.toMap( IVRRecording::getIvrRecordingId , i -> i ) );
       
       return ivrMap;
    }
    
    private void fillCodeSetValue( List< IVRRecording > ivrList ) 
    {
       Set< Integer > codeSetIds = new HashSet< Integer >();
       
       Map< Integer , CodeSetValueDisplay > csvdMap = null;
       
       // Add language code set value id.
       codeSetIds.addAll( ivrList.stream().map( IVRRecording::getIvrLangCvid ).collect( Collectors.toSet() ) );
       
       // Add recoding type code set value id.
       codeSetIds.addAll( ivrList.stream().map( IVRRecording::getRecordingTypeCvid ).collect( Collectors.toSet() ) );
       
       // Add status code set value id.
       codeSetIds.addAll( ivrList.stream().map( IVRRecording::getStatusCvid ).collect( Collectors.toSet() ) );
       
       csvdMap = codeSetValueDaoImpl.getByCodeSetValueIdsAsMap( codeSetIds );
       
       // Fill code set value object.
       for( IVRRecording ivr : ivrList )
       {
          ivr.setIvrLanguage( csvdMap.get( ivr.getIvrLangCvid() ) );
          
          ivr.setRecordingType( csvdMap.get( ivr.getRecordingTypeCvid() ) );
          
          ivr.setStatus( csvdMap.get( ivr.getStatusCvid() ) );
       }
    } 
}
