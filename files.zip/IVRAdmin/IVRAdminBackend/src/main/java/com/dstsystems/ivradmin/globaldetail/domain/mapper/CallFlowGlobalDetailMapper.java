/*
 * FILE : CallFlowGlobalDetailMapper.java
 *
 * CLASS : CallFlowGlobalDetailMapper
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.globaldetail.domain.mapper;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.core.dao.CallFlowDaoImpl;
import com.dstsystems.ivradmin.globaldetail.domain.CallFlowGlobalDetail;

/**
 * Maps call flow data from the {@link CallFlowDaoImpl#getGlobalDetails(CallFlowGlobalDetail)} query to {@link CallFlowGlobalDetail}.
 * 
 * @author dt63314
 *
 */
public class CallFlowGlobalDetailMapper implements
                                        RowMapper<CallFlowGlobalDetail>
{
    
    /* (non-Javadoc)
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
     */
    @Override
    public CallFlowGlobalDetail mapRow( ResultSet rs,
                                        int rowNum ) throws SQLException
    {
        // FIXME Test
        return CallFlowGlobalDetail.builder()
                                   .dnis( rs.getString( CallFlowDaoImpl.DNIS_NBR ) )
                                   .callFlowStatusCvid( new BigInteger( rs.getString( CallFlowDaoImpl.CALL_FLOW_STATUS_CVID ) ) )
                                   .callFlowDescription( rs.getString( CallFlowDaoImpl.CALL_FLOW_DESCRIPTION_TXT ) )
                                   .accountGroupMethodText( rs.getString( CallFlowDaoImpl.ACCOUNT_GROUP_METHOD_TXT ) )
                                   .build();
    }
    
}
