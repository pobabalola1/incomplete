package com.dstsystems.ivradmin.web.config;

public class Tomcat
{
    private String baseDir;
    private String docBase;
    
    public String getBaseDir()
    {
        return baseDir;
    }
    public void setBaseDir( String baseDir )
    {
        this.baseDir = baseDir;
    }
    public String getDocBase()
    {
        return docBase;
    }
    public void setDocBase( String docBase )
    {
        this.docBase = docBase;
    }
}
