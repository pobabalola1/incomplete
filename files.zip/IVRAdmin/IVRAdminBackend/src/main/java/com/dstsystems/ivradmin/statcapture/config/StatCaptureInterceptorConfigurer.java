/*
 * FILE : StatCaptureInterceptorConfigurer.java
 *
 * CLASS : StatCaptureInterceptorConfigurer
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.statcapture.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.dstsystems.ivradmin.statcapture.interceptor.StatCaptureInterceptor;

/**
 * Responsible for registering Interceptors that are used in IVR.
 * 
 * @author DT19643, dt63314
 *
 */
@Configuration
public class StatCaptureInterceptorConfigurer extends WebMvcConfigurerAdapter
{
    private StatCaptureInterceptor statCaptureInterceptor;
    
    @Autowired
    public void statCaptureInterceptor( StatCaptureInterceptor statCaptureInterceptor )
    {
        this.statCaptureInterceptor = statCaptureInterceptor;
    }
    
    @Override
    public void addInterceptors( InterceptorRegistry registry )
    {
        InterceptorRegistration registration = registry.addInterceptor( statCaptureInterceptor );
        registration.addPathPatterns( "/api/**" );
        
    }
    
}
