package com.dstsystems.ivradmin.fund.domain;

public class IvrMutualFundCategory {
	private Integer callFlowId;
	private Integer ivrMutualFundCategoryId;
	private String ivrMutualFundCategoryNm;
	private Integer fundCnt;
	private String lastMaintenanceOperatorId;
	
	
	
  /**
	 * @return the fundCnt
	 */
	public Integer getFundCnt() {
		return fundCnt;
	}

	/**
	 * @param fundCnt the fundCnt to set
	 */
	public void setFundCnt(Integer fundCnt) {
		this.fundCnt = fundCnt;
	}



	
	/**
     * @return the ivrMutualFundCategoryId
     */
	public Integer getIvrMutualFundCategoryId() {
		return ivrMutualFundCategoryId;
	}
	
	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setIvrMutualFundCategoryId(Integer ivrMutualFundCategoryId) {
		this.ivrMutualFundCategoryId = ivrMutualFundCategoryId;
	}
	
	/**
     * @return the lastMaintenanceOperatorId
     */
	public String getLastMaintenanceOperatorId() {
		return lastMaintenanceOperatorId;
	}
	
	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setLastMaintenanceOperatorId(String lastMaintenanceOperatorId) {
		this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
	}
	
	/**
     * @return the ivrMutualFundCategoryNm
     */
	public String getIvrMutualFundCategoryNm() {
		return ivrMutualFundCategoryNm;
	}
	
	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setIvrMutualFundCategoryNm(String ivrMutualFundCategoryNm) {
		this.ivrMutualFundCategoryNm = ivrMutualFundCategoryNm;
	}
	
	/**
     * @return the dnisId
     */
	public Integer getCallFlowId() {
		return callFlowId;
	}
	
	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setCallFlowId(Integer dnisId) {
		this.callFlowId = dnisId;
	}
}
