package com.dstsystems.ivradmin.transferoption.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.transferoption.domain.TransferHierarchy;


public class DnisCallTransferHierarchyRowMapper implements RowMapper< TransferHierarchy > {
	
    private final String CALL_FLOW_ID                   = "CALL_FLOW_ID";
    private final String TRANSFER_TYPE_HIERARCHY_CVID   = "TRANSFER_TYPE_HIERARCHY_CVID";
    private final String SEQUENCE_NBR                   = "SEQUENCE_NBR";
    
	@Override
	public TransferHierarchy mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
	    TransferHierarchy th = TransferHierarchy.builder()
	                                     .callFlowId( rs.getInt( CALL_FLOW_ID ) )
	                                     .hierarchyCvid( rs.getInt( TRANSFER_TYPE_HIERARCHY_CVID ) )
	                                     .sequenceNumber( rs.getInt( SEQUENCE_NBR ) )
	                                     .build();
	   
		
		return th;
	}
}
