package com.dstsystems.ivradmin.core.domain;

import lombok.Data;

/**
 * The ErrorBean is a resource that can be used to return information from a RestfulController to the calling entity. Simply include this
 * bean in your ResponseBody object.
 * 
 * @author dt63314
 *
 */
@Data
public class ErrorBean
{
	private String	key;
	private String	message;

	public ErrorBean(String key, String message)
	{
		this.key = key;
		this.message = message;
	}

}
