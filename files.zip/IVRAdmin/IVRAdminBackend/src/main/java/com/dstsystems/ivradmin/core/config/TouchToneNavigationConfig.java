/*
 * FILE : TouchToneNavigationConfig.java
 *
 * CLASS : TouchToneNavigationConfig
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.config;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.annotation.Validated;

import lombok.Data;

/**
 * Handler for the Touch Tone Navigation configurations.
 * 
 * @author dt63314
 *
 */
@Configuration
@PropertySource("classpath:config/xml-files.yml")
@ConfigurationProperties(prefix = "ttnav")
@Validated
@Data
public class TouchToneNavigationConfig
{
    // FIXME Test
    private static final String PLACE_HOLDER = "%DNIS%";
    
    @Value("${resource-type}:")
    @Pattern(regexp = "classpath:?|file:?")
    private String              resourceType;
    
    // Match characters and dash, 0-10 characters
    // Match a single /
    // Match characters and dash, 1-10 characters
    @Pattern(regexp = "[\\w\\-]{0,10}\\/[\\w\\-]{1,10}")
    @Value("${xml-directory}")
    private String              xmlDirectory;
    
    @Value("${xml-pattern}")
    @Pattern(regexp = "[\\w\\-]{1,20}%DNIS%\\.xml")
    private String              xmlFilePattern;
    
    @Pattern(regexp = "[\\w\\-]{0,10}\\/[\\w\\-]{0,10}")
    @Value("${xsd-directory}")
    private String              xsdDirectory;
    
    @Value("${xsd-name}")
    @Pattern(regexp = "[\\w\\-]{1,20}\\.xsd")
    private String              xsdFileName;
    
    /**
     * Returns the configuration file name for the given dnis.
     * @param dnis the dnis for a given configuration file.
     * @return the XML file name.
     */
    public String getFileFor( @NotEmpty String dnis )
    {
        return xmlFilePattern.replaceFirst( PLACE_HOLDER, dnis );
    }
    
    
}
