/**
 * 
 */
package com.dstsystems.ivradmin.closure.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.dstsystems.ivradmin.closure.domain.Closure;
import com.dstsystems.ivradmin.closure.domain.ClosureResponse;
import com.dstsystems.ivradmin.closure.domain.mapper.DefaultClosureRowMapper;
import com.dstsystems.ivradmin.closure.domain.mapper.OverrideClosureRowMapper;
import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.core.dao.IVRRecordingDaoImpl;
import com.dstsystems.ivradmin.core.domain.IVRRecording;

/**
 * @author dt86783
 *
 */

@Repository
public class ClosureDaoImpl extends BaseJdbcDAO
{  
   
   @Autowired
   private DefaultClosureRowMapper defaultRowMapper;
   
   @Autowired
   private OverrideClosureRowMapper overrideRowMapper;
   
   @Autowired
   private IVRRecordingDaoImpl ivrRecordingDaoImpl;
   
   private static final String        CALL_FLOW_ID = "CALL_FLOW_ID";
  
   private static final String        LINE_OF_BUSINESS_ID = "LINE_OF_BUSINESS_ID";
   private static final String        TRANSFER_CLOSED_DT = "TRANSFER_CLOSED_DT";
   private static final String        LAST_MAINTENANCE_ID = "LAST_MAINTENANCE_ID";
   private static final String        TRANSFER_CLOSED_DATE_NM = "TRANSFER_CLOSED_DATE_NM";
   
   
   private static final StringBuilder ADD_NEW_CLOSURE = new StringBuilder()
		   .append("INSERT INTO IVR.TRANSFER_CLOSED_DATE ")
		   .append("(LINE_OF_BUSINESS_ID, TRANSFER_CLOSED_DT, LAST_MAINTENANCE_ID, TRANSFER_CLOSED_DATE_NM) VALUES ")
		   .append("(:LINE_OF_BUSINESS_ID, :TRANSFER_CLOSED_DT, :LAST_MAINTENANCE_ID, :TRANSFER_CLOSED_DATE_NM ); ");   
   
   //private static final String        CALL_FLOW_ID = "CALL_FLOW_ID";
   private static final String        CALL_FLOW_TRANSFER_OVERRIDE_DT = "CALL_FLOW_TRANSFER_OVERRIDE_DT";
   private static final String        LAST_MAINTENANCE_TS = "LAST_MAINTENANCE_TS";
   //private static final String        LAST_MAINTENANCE_ID = "LAST_MAINTENANCE_ID";
   private static final String        OPEN_IND = "OPEN_IND";
   private static final String        USE_NORMAL_BUSINESS_HOURS_IND = "USE_NORMAL_BUSINESS_HOURS_IND";
   private static final String        OPEN_TM = "OPEN_TM";
   private static final String        CLOSED_TM = "CLOSED_TM";
   private static final String        OVERRIDE_TRANSFER_CLOSED_RECORDING_ID = "OVERRIDE_TRANSFER_CLOSED_RECORDING_ID";
   private static final String       CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM = "CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM";
   
   private static final StringBuilder ADD_NEW_CLOSURE_OVERRIDE = new StringBuilder()
		   .append("INSERT INTO IVR.CALL_FLOW_TRANSFER_OVERRIDE_DATE ")
		   .append("(CALL_FLOW_ID, CALL_FLOW_TRANSFER_OVERRIDE_DT, LAST_MAINTENANCE_ID, OPEN_IND, USE_NORMAL_BUSINESS_HOURS_IND, OPEN_TM, CLOSED_TM, OVERRIDE_TRANSFER_CLOSED_RECORDING_ID, CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM) VALUES ")
		   .append("(:CALL_FLOW_ID, :CALL_FLOW_TRANSFER_OVERRIDE_DT, :LAST_MAINTENANCE_ID, :OPEN_IND, :USE_NORMAL_BUSINESS_HOURS_IND, :OPEN_TM, :CLOSED_TM, :OVERRIDE_TRANSFER_CLOSED_RECORDING_ID, :CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM); ");

   //--------
   private static final String        OLD_TRANSFER_CLOSED_DT = "OLD_TRANSFER_CLOSED_DT";
   //UPDATE `IVR`.`TRANSFER_CLOSED_DATE` SET `TRANSFER_CLOSED_DT`='2018-01-05', `LAST_MAINTENANCE_TS`='2018-05-07 02:25:03.192904', `LAST_MAINTENANCE_ID`='DT77648', `TRANSFER_CLOSED_DATE_NM`='New Year1' WHERE `LINE_OF_BUSINESS_ID`='3' and`TRANSFER_CLOSED_DT`='2018-01-01';

   private static final StringBuilder UPDATE_CLOSURE = new StringBuilder()
		   .append("UPDATE IVR.TRANSFER_CLOSED_DATE SET ")
		   .append("TRANSFER_CLOSED_DT=:TRANSFER_CLOSED_DT, LAST_MAINTENANCE_ID=:LAST_MAINTENANCE_ID, TRANSFER_CLOSED_DATE_NM=:TRANSFER_CLOSED_DATE_NM WHERE LINE_OF_BUSINESS_ID=:LINE_OF_BUSINESS_ID and TRANSFER_CLOSED_DT=:OLD_TRANSFER_CLOSED_DT;");

   //UPDATE `IVR`.`CALL_FLOW_TRANSFER_OVERRIDE_DATE` SET `CALL_FLOW_TRANSFER_OVERRIDE_DT`='2019-12-01', `LAST_MAINTENANCE_TS`='2018-05-08 05:32:04.614778', `LAST_MAINTENANCE_ID`='DT77648', `OPEN_IND`='N', `USE_NORMAL_BUSINESS_HOURS_IND`='Y', `OPEN_TM`='08:00:00', `CLOSED_TM`='17:00:00', `OVERRIDE_TRANSFER_CLOSED_RECORDING_ID`='155', `CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM`='Tum BD1' WHERE `CALL_FLOW_ID`='1' and`CALL_FLOW_TRANSFER_OVERRIDE_DT`='2018-12-01';
   private static final StringBuilder UPDATE_CLOSURE_OVERRIDE = new StringBuilder()
		   .append("UPDATE IVR.CALL_FLOW_TRANSFER_OVERRIDE_DATE SET ")
		   .append("CALL_FLOW_TRANSFER_OVERRIDE_DT=:CALL_FLOW_TRANSFER_OVERRIDE_DT, LAST_MAINTENANCE_ID=:LAST_MAINTENANCE_ID, OPEN_IND=:OPEN_IND, USE_NORMAL_BUSINESS_HOURS_IND=:USE_NORMAL_BUSINESS_HOURS_IND, OPEN_TM=:OPEN_TM, CLOSED_TM=:CLOSED_TM, OVERRIDE_TRANSFER_CLOSED_RECORDING_ID=:OVERRIDE_TRANSFER_CLOSED_RECORDING_ID, CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM=:TRANSFER_CLOSED_DATE_NM WHERE CALL_FLOW_ID=:CALL_FLOW_ID and CALL_FLOW_TRANSFER_OVERRIDE_DT=:OLD_TRANSFER_CLOSED_DT; ");

   
   // @TODO Need more clarify when table completed. 
   private static final StringBuilder GET_DEFAULT_CLOSURE_BY_CALL_FLOW_ID = new StringBuilder() 
         .append("select     TF.LINE_OF_BUSINESS_ID, ")
         .append("           TF.TRANSFER_CLOSED_DT, ")
         .append("           TBH.OPEN_TM, ")
         .append("           TBH.CLOSED_TM ")
         .append("from       TRANSFER_CLOSED_DATE TF, ")
         .append("           CALL_FLOW_TRANSFER_BUSINESS_HOURS TBH, ")
         .append("           LINE_OF_BUSINESS LOB, ")
         .append("           LINE_OF_BUSINESS_CLIENT LOBC, ")
         .append("           CALL_FLOW CF, ")
         .append("           CODE_SET CS, ")
         .append("           CODE_SET_VALUE CSV ")
         .append("where      TF.LINE_OF_BUSINESS_ID = LOB.LINE_OF_BUSINESS_ID    and ")
         .append("           LOB.LINE_OF_BUSINESS_ID = LOBC.LINE_OF_BUSINESS_ID  and ")
         .append("           LOBC.IVR_CLIENT_ID = CF.IVR_CLIENT_ID               and ")
         .append("           CS.CODE_SET_ID = CSV.CODE_SET_ID                    and ")
         .append("           CS.EFFECTIVE_DT <= CURRENT_DATE                     and ")
         .append("           ( ")
         .append("               CS.EXPIRATION_DT IS NULL                or ")
         .append("               CURRENT_DATE <= CS.EXPIRATION_DT ")
         .append("           )                                               and ")
         .append("           CSV.EFFECTIVE_DT <= CURRENT_DATE                and ")
         .append("           (  ")
         .append("               CSV.EXPIRATION_DT IS NULL               or  ")
         .append("               CURRENT_DATE <= CSV.EXPIRATION_DT ")
         .append("           ) and ")
         .append("           CS.CODE_SET_ABBREVIATED_NM = 'Weekday'          and ")
         .append("           CSV.CODE_SET_VALUE_ABBREVIATED_NM = DATE_FORMAT(TF.TRANSFER_CLOSED_DT, '%a') and ")
         .append("           TBH.DAY_OF_WEEK_CVID = CSV.CODE_SET_VALUE_ID    and ")
         .append("           TBH.CALL_FLOW_ID = CF.CALL_FLOW_ID              and ")
         .append("           CF.CALL_FLOW_ID = :CALL_FLOW_ID ")
         .append("order by   TF.TRANSFER_CLOSED_DT");
   
   // @TODO Need more clarify when table completed.
   private static final StringBuilder GET_OVERRIDED_CLOSURE_BY_CALL_FLOW_ID = new StringBuilder()
          .append("select   TOD.CALL_FLOW_TRANSFER_OVERRIDE_DT, ")
          .append("         TOD.OPEN_IND, ")
          .append("         TOD.USE_NORMAL_BUSINESS_HOURS_IND, ")
          .append("         TOD.OPEN_TM, ")
          .append("         TOD.CLOSED_TM ")
          .append("from     CALL_FLOW_TRANSFER_OVERRIDE_DATE TOD ")
          .append("where    TOD.CALL_FLOW_ID = :CALL_FLOW_ID ")
          .append("order by TOD.CALL_FLOW_TRANSFER_OVERRIDE_DT"); 
   
   private final static Logger        LOG            = LoggerFactory.getLogger( ClosureDaoImpl.class );
   
   public List< ClosureResponse > addNewClosures( String lineId, String transDT, String maintId, String transNM,
		   String closeAllDay, String oBusinessHRS, String nBusinessHRS,
		   String openTM, String closeTM, String useDef, String recID, String callFlowID)
   {
	  List< ClosureResponse > resList = new ArrayList<ClosureResponse>();
	  
	  
	  ClosureResponse temp = ClosureResponse.builder().build();

	  SqlParameterSource parameters = new MapSqlParameterSource()
			  .addValue( LINE_OF_BUSINESS_ID,lineId )
			  .addValue( TRANSFER_CLOSED_DT,transDT )
			  .addValue( LAST_MAINTENANCE_ID,maintId )
			  .addValue( TRANSFER_CLOSED_DATE_NM,transNM );
	  
	  try 
      {
		 getNamedParameterJdbcOperations().update(ADD_NEW_CLOSURE.toString(), parameters);
         
		 if(oBusinessHRS.equalsIgnoreCase("Y")) {
			  SqlParameterSource overParameters = new MapSqlParameterSource()
					  .addValue( CALL_FLOW_ID,callFlowID )
					  .addValue( CALL_FLOW_TRANSFER_OVERRIDE_DT,transDT )
					  .addValue( LAST_MAINTENANCE_ID,maintId )
					  .addValue( OPEN_IND,"Y" )
					  .addValue( USE_NORMAL_BUSINESS_HOURS_IND,"N" )
					  .addValue( OPEN_TM,openTM )
					  .addValue( CLOSED_TM,closeTM )
					  .addValue( OVERRIDE_TRANSFER_CLOSED_RECORDING_ID,recID )
					  .addValue( CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM,transNM );
			  
			  getNamedParameterJdbcOperations().update(ADD_NEW_CLOSURE_OVERRIDE.toString(), overParameters);
		 }
		 
		 if(nBusinessHRS.equalsIgnoreCase("Y")) {
			  SqlParameterSource normalParameters = new MapSqlParameterSource()
					  .addValue( CALL_FLOW_ID,callFlowID )
					  .addValue( CALL_FLOW_TRANSFER_OVERRIDE_DT,transDT )
					  .addValue( LAST_MAINTENANCE_ID,maintId )
					  .addValue( OPEN_IND,"Y" )
					  .addValue( USE_NORMAL_BUSINESS_HOURS_IND,"Y" )
					  .addValue( OPEN_TM,"" )
					  .addValue( CLOSED_TM,"" )
					  .addValue( OVERRIDE_TRANSFER_CLOSED_RECORDING_ID,recID )
					  .addValue( CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM,transNM );
			  getNamedParameterJdbcOperations().update(ADD_NEW_CLOSURE_OVERRIDE.toString(), normalParameters);
		 }
		 
         temp.setCodeRes("");
 		 temp.setTextRes("success");
 		 temp.setIsSuccess(true);
      }
      catch ( Exception e ) 
      {
         LOG.error( e.getMessage() );
 		 temp.setTextRes(e.getMessage());
 		 temp.setIsSuccess(false);
      }
	  resList.add(temp);
	  
	  return resList;
   }
   
   public List< ClosureResponse > updateClosures( String lineId, String transDT, String maintId, String transNM,
		   String closeAllDay, String oBusinessHRS, String nBusinessHRS,
		   String openTM, String closeTM, String useDef, String recID, String callFlowID, String oldTransDT)
   {
	  List< ClosureResponse > resList = new ArrayList<ClosureResponse>();
	  
	  
	  ClosureResponse temp = ClosureResponse.builder().build();

	  SqlParameterSource parameters = new MapSqlParameterSource()
			  .addValue( LINE_OF_BUSINESS_ID,lineId )
			  .addValue( TRANSFER_CLOSED_DT,transDT )
			  .addValue( LAST_MAINTENANCE_ID,maintId )
			  .addValue( TRANSFER_CLOSED_DATE_NM,transNM )
			  .addValue( OLD_TRANSFER_CLOSED_DT,oldTransDT );
			  
	  
	  try 
      {
		  System.out.println("--------1------");
		 getNamedParameterJdbcOperations().update(UPDATE_CLOSURE.toString(), parameters);
         
		 if(oBusinessHRS.equalsIgnoreCase("Y")) {
			  SqlParameterSource overParameters = new MapSqlParameterSource()
					  .addValue( CALL_FLOW_ID,callFlowID )
					  .addValue( CALL_FLOW_TRANSFER_OVERRIDE_DT,transDT )
					  .addValue( LAST_MAINTENANCE_ID,maintId )
					  .addValue( OPEN_IND,"Y" )
					  .addValue( USE_NORMAL_BUSINESS_HOURS_IND,"N" )
					  .addValue( OPEN_TM,openTM )
					  .addValue( CLOSED_TM,closeTM )
					  .addValue( OVERRIDE_TRANSFER_CLOSED_RECORDING_ID,recID )
					  //.addValue( CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM,transNM )
					  .addValue( TRANSFER_CLOSED_DATE_NM,transNM )
					  .addValue( OLD_TRANSFER_CLOSED_DT,oldTransDT );
			  System.out.println("--------2------");
			  getNamedParameterJdbcOperations().update(UPDATE_CLOSURE_OVERRIDE.toString(), overParameters);
		 }
		 
		 if(nBusinessHRS.equalsIgnoreCase("Y")) {
			  SqlParameterSource normalParameters = new MapSqlParameterSource()
					  .addValue( CALL_FLOW_ID,callFlowID )
					  .addValue( CALL_FLOW_TRANSFER_OVERRIDE_DT,transDT )
					  .addValue( LAST_MAINTENANCE_ID,maintId )
					  .addValue( OPEN_IND,"Y" )
					  .addValue( USE_NORMAL_BUSINESS_HOURS_IND,"Y" )
					  .addValue( OPEN_TM,"" )
					  .addValue( CLOSED_TM,"" )
					  .addValue( OVERRIDE_TRANSFER_CLOSED_RECORDING_ID,recID )
					  //.addValue( CALL_FLOW_TRANSFER_OVERRIDE_DATE_NM,transNM )//delete
					  .addValue( TRANSFER_CLOSED_DATE_NM,transNM )
			          .addValue( OLD_TRANSFER_CLOSED_DT,oldTransDT );
			  System.out.println("--------3------");
			  getNamedParameterJdbcOperations().update(UPDATE_CLOSURE_OVERRIDE.toString(), normalParameters);
		 }
		 
         temp.setCodeRes("");
 		 temp.setTextRes("success");
 		 temp.setIsSuccess(true);
      }
      catch ( Exception e ) 
      {
         LOG.error( e.getMessage() );
 		 temp.setTextRes(e.getMessage());
 		 temp.setIsSuccess(false);
      }
	  resList.add(temp);
	  
	  return resList;
   }
   
   public List< Closure > getDefaultCloseDatesByCallFlowId( Integer callFlowId )
   {
      SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                            callFlowId ); 
      
      List< Closure > defaultClosureList = null;
      try 
      {
         defaultClosureList = getNamedParameterJdbcOperations().query( GET_DEFAULT_CLOSURE_BY_CALL_FLOW_ID.toString(), parameters, defaultRowMapper );
         
         
         // Mock testing.
         for( Closure closure : defaultClosureList ) 
         {
            closure.setOverrideTransferClosedRecordId( 1 );
         }
         
         fillIVRRecording( defaultClosureList );
      }
      catch ( Exception e ) 
      {
         LOG.error( e.getMessage() );
      }
      
      return defaultClosureList;
   }
   
   public List< Closure > getOverrideCloseDatesByCallFlowId( Integer callFlowId )
   {
      SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                            callFlowId ); 
      
      List< Closure > overrideClosureList = null;
      try 
      {
         overrideClosureList = getNamedParameterJdbcOperations().query( GET_OVERRIDED_CLOSURE_BY_CALL_FLOW_ID.toString(), parameters, overrideRowMapper );
         
         // Mock testing.
         for( Closure closure : overrideClosureList ) 
         {
            closure.setOverrideTransferClosedRecordId( 2 );
         }
         
         fillIVRRecording( overrideClosureList );
      }
      catch ( Exception e ) 
      {
         LOG.error( e.getMessage() );
      }
      
      return overrideClosureList;
   }
 
   private void fillIVRRecording( List< Closure > closureList ) 
   {
      Set< Integer > ivrRecordingIds = new HashSet< Integer >();
      
      Map< Integer, IVRRecording > ivrRecordsMap = null;
      
      // Add override transfer closed record ids for query.
      ivrRecordingIds.addAll( closureList.stream().map( Closure::getOverrideTransferClosedRecordId ).collect( Collectors.toSet() ) );
      
      ivrRecordsMap = ivrRecordingDaoImpl.getByIdsAsMap( ivrRecordingIds );
      
      for( Closure closure : closureList )
      {
         closure.setOverrideTransferClosedRecord( ivrRecordsMap.get( closure.getOverrideTransferClosedRecordId() ) );
      }
   } 
   
}
