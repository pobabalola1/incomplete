package com.dstsystems.ivradmin.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.callflowfunction.domain.BusinessFunction;
import com.dstsystems.ivradmin.callflowfunction.domain.mapper.BusinessFunctionRowMapper;
import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;

@Repository
public class BusinessFunctionDaoImpl extends BaseJdbcDAO 
{
   private static final String FUNCTION_ID = "FUNCTION_ID";//Primary Key

   private static final StringBuilder GET_ALL = new StringBuilder()
			.append(" select     BF.FUNCTION_ID, BF.LAST_MAINTENANCE_OPERATOR_ID, BF.FUNCTION_NM, BF.LINE_OF_BUSINESS_ID ")
			.append(" from       BUSINESS_FUNCTION BF ");
			
   private static final StringBuilder GET_ALL_BY_FUNCTION_ID = new StringBuilder()
			.append(" select     BF.FUNCTION_ID, BF.LAST_MAINTENANCE_OPERATOR_ID, BF.FUNCTION_NM, BF.LINE_OF_BUSINESS_ID ")
			.append(" from       BUSINESS_FUNCTION BF ")
			.append(" where      BF.FUNCTION_ID = :FUNCTION_ID");
	
   private final static Logger     LOG = LoggerFactory.getLogger( BusinessFunctionDaoImpl.class );
	 
   public List< BusinessFunction > getAll()
   {
      List< BusinessFunction > businessFunctionList = null; 
      try 
      {
    	  businessFunctionList = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new BusinessFunctionRowMapper() );
      }
      catch( Exception e )
      {
    	  LOG.error( e.getMessage() );
      }
      return businessFunctionList;
   }
   
   public BusinessFunction getByFunctionId( int id )
   {
	   BusinessFunction businessFunction = null;
       SqlParameterSource parameters = new MapSqlParameterSource().addValue( FUNCTION_ID,
                                                                            id );
       try 
       {     
    	   businessFunction =  getNamedParameterJdbcOperations().query( GET_ALL_BY_FUNCTION_ID.toString(), 
                                                                           parameters, 
                                                                           new BusinessFunctionRowMapper() ).get( 0 );
	   }
	   catch( Exception e )
	   {
	 	  LOG.error( e.getMessage() );
	   }
      return businessFunction;
   }
	   
}
