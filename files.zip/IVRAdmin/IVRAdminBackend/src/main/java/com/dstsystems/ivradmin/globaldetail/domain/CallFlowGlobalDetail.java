/*
 * FILE : CallFlowGlobalDetail.java
 *
 * CLASS : CallFlowGlobalDetail
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.globaldetail.domain;

import java.math.BigInteger;

import com.dstsystems.ivradmin.core.dao.CallFlowDaoImpl;
import com.dstsystems.ivradmin.globaldetail.domain.mapper.CallFlowGlobalDetailMapper;

import lombok.Builder;
import lombok.Getter;

/**
 * A container for values returned by {@link CallFlowDaoImpl#getGlobalDetails(BigInteger)} and mapped by {@link CallFlowGlobalDetailMapper}.
 * 
 * @author dt63314
 *
 */
@Getter
@Builder
public class CallFlowGlobalDetail
{
    private String     dnis;
    private BigInteger callFlowStatusCvid;
    private String     callFlowDescription;
    private String     accountGroupMethodText;
    
}
