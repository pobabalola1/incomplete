package com.dstsystems.ivradmin.web;


import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.catalina.connector.Connector;
import org.apache.coyote.ajp.AjpNioProtocol;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.dstsystems.ivradmin.web.config.ServerProperties;
import com.dstsystems.ivradmin.web.container.EmbeddedTomcatFactory;

/**
 * The configuration class for creating Embedded Tomcat Factory.
 */
@EnableConfigurationProperties({ ServerProperties.class })
@Configuration
public class EmbeddedTomcatBeanConfig {

    private static final Logger logger = LoggerFactory.getLogger(EmbeddedTomcatBeanConfig.class);

    private static final boolean SECURE_TRUE = true;
    private static final boolean SECURE_FALSE = false;

    /**
     * Overrides embed-tomcat to add DBCP as a resource and set HTTP, HTTPS and AJP connectors
     *
     * @return embed tomcat factory
     */
    @Bean
    public TomcatEmbeddedServletContainerFactory tomcatFactory(
            ServerProperties serverProperties ) throws UnknownHostException {
        
        logger.debug("Create TomcatEmbeddedServletContainer");

        EmbeddedTomcatFactory factory = new EmbeddedTomcatFactory();

        //Common
        factory.setBaseDirectory(factory.makeDirectory(serverProperties.getTomcat().getBaseDir()));
        factory.setDocumentRoot(factory.makeDirectory(serverProperties.getTomcat().getDocBase()));

        // HTTP
        factory.setPort(serverProperties.getPort());
        if (serverProperties.isAjpEnabled()) {
            factory.addAdditionalTomcatConnectors(createAjpNioConnector(serverProperties));
        }

        return factory;
    }
    
    /**
     * Define an AJP Connector with port from configuration (default is 8010) by using AjpNioProtocol implementation
     *
     * @param serverProperties which contains configuration from application.yml
     * @return connector which is AjpNioProtocol
     */
    protected Connector createAjpNioConnector(ServerProperties serverProperties) throws UnknownHostException {
        logger.debug("Create AJP protocol connector");

        Connector connector = new Connector("org.apache.coyote.ajp.AjpNioProtocol");

        if (serverProperties.getAjpAddress() != null) {
            AjpNioProtocol protocol = (AjpNioProtocol) connector.getProtocolHandler();
            protocol.setAddress(InetAddress.getByName(serverProperties.getAjpAddress()));
        }

        connector.setSecure( SECURE_FALSE );
        connector.setPort(serverProperties.getAjpPort());
        if (serverProperties.getAjpPacketSize() > 0) {
            connector.setAttribute("packetSize", serverProperties.getAjpPacketSize());
        }

        return connector;
    }
    
}

