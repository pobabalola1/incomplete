package com.dstsystems.ivradmin.core.domain;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CodeSetValueDisplay {
   
	private Integer    id;
    private String     name;
	private String     abbreviatedName;
	private String     descriptionText; 
	private boolean    isExpired;
	
}
