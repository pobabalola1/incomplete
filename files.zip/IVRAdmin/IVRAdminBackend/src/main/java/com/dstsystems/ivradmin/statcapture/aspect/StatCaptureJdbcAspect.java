/*
 * FILE : StatCaptureJdbcAspect.java
 *
 * CLASS : StatCaptureJdbcAspect
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.statcapture.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;

import com.dstsystems.statcapture.web.WebStatisticContext;

import lombok.extern.slf4j.Slf4j;

/**
 * This class names the Pointcuts and activities that should occur when key JDBC activities occur in the Admin Tool.
 * @author DT63314
 *
 */
@Aspect
@Configuration
@Slf4j
public class StatCaptureJdbcAspect extends StatCaptureAspect
{
    
    /**
     * A Pointcut method is used for identifying when an Aspect should execute. The actual activity for the Pointcut should
     * be declared in another method with the appropriate action (@Before, @After, whatever) annotated.
     */
    @Pointcut("execution (* org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate.query*(String, ..))")
    public void namedParameterJdbcTemplateQueryExecution()
    {
    }
    
    /**
     * Generates the EV4 record details that will be captured when the JdbcTemplate executes a Query beginning with a String argument.
     * 
     * @param joinPoint - provided by the Aspect.
     * @return Whatever is returned by the Pointcut method(s).
     * @throws Throwable rethrowing any exceptions thrown during execution.
     */
    @Around("namedParameterJdbcTemplateQueryExecution()")
    public Object aroundNamedParameterJdbcTemplateQueryExecution( ProceedingJoinPoint joinPoint ) throws Throwable
    {
        log.trace( "Executing @Around for NamedParameterJdbcTemplate.query*" );
        WebStatisticContext webStatisticContext = statCaptureConfig.getWebStatisticContext();
        if( webStatisticContext != null )
        {
            String sqlStatement = joinPoint.getArgs()[ 0 ].toString();
            String ev4 = String.format( "ev4_type=jdbc.query ev4_id=%s",
                                        sqlStatement );
            return logAroundProceed( joinPoint, webStatisticContext, ev4 );
        }
        else
        {
            log.warn( "WebStatisticsContext is null while attempting to log the SQL statement record." );
            return joinPoint.proceed();
        }
    }

    /**
     * A Pointcut method is used for identifying when an Aspect should execute. The actual activity for the Pointcut should
     * be declared in another method with the appropriate action (@Before, @After, whatever) annotated.
     */
    @Pointcut("execution(* org.apache.tomcat.jdbc.pool.DataSourceProxy.getConnection())")
    public void datasouceGetConnectionExecution()
    {
    }
    
    /**
     * Generates the EV4 record details that will be captured when the datasource connection is retrieved.
     * 
     * @param joinPoint - provided by the Aspect.
     * @return Whatever is returned by the Pointcut method(s).
     * @throws Throwable rethrowing any exceptions thrown during execution.
     */
    @Around("datasouceGetConnectionExecution()")
    public Object aroundDatasouceGetConnection( ProceedingJoinPoint joinPoint ) throws Throwable
    {
        log.trace( "Executing @Around for datasouceGetConnectionExecution" );
        WebStatisticContext webStatisticContext = statCaptureConfig.getWebStatisticContext();
        if( webStatisticContext != null )
        {
            return logAroundProceed( joinPoint,
                                     webStatisticContext,
                                     "ev4_type=jdbc.connect" );
        }
        else
        {
            log.warn( "WebStatisticsContext is null while attempting to log the datasource connection record." );
            return joinPoint.proceed();
        }
        
    }
    
}