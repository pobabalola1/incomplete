package com.dstsystems.ivradmin.domain;

import java.util.Date;

public class AssetManagementDnisCallTransferOverrideDate {

	private Integer dnisId;
	private Date assetManagementDNISOverrideTransferClosedDate;
	private Date lastMaintenanceTimestamp;
	private String lastMaintenanceId;
	private Date openTime;
	private Date closedTime;
	private String useNormalBusinessHoursIndicator;

	/**
	 * @return the dnisId
	 */
	public Integer getDnisId() {
		return dnisId;
	}
	
	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setDnisId(Integer dnisId) {
		this.dnisId = dnisId;
	}

	/**
	 * @return the assetManagementDNISOverrideTransferClosedDate
	 */
	public Date getAssetManagementDNISOverrideTransferClosedDate() {
		return assetManagementDNISOverrideTransferClosedDate;
	}
	
	/**
	 * @param assetManagementDNISOverrideTransferClosedDate
	 *            the assetManagementDNISOverrideTransferClosedDate to set
	 */
	public void setAssetManagementDNISOverrideTransferClosedDate(Date assetManagementDNISOverrideTransferClosedDate) {
		this.assetManagementDNISOverrideTransferClosedDate = assetManagementDNISOverrideTransferClosedDate;
	}

	/**
	 * @return the lastMaintenanceTimestamp
	 */
	public Date getLastMaintenanceTimestamp() {
		return lastMaintenanceTimestamp;
	}
	
	/**
	 * @param lastMaintenanceTimestamp
	 *            the lastMaintenanceTimestamp to set
	 */
	public void setLastMaintenanceTimestamp(Date lastMaintenanceTimestamp) {
		this.lastMaintenanceTimestamp = lastMaintenanceTimestamp;
	}

	/**
	 * @return the lastMaintenanceId
	 */
	public String getLastMaintenanceId() {
		return lastMaintenanceId;
	}
	
	/**
	 * @param lastMaintenanceId
	 *            the lastMaintenanceId to set
	 */
	public void setLastMaintenanceId(String lastMaintenanceId) {
		this.lastMaintenanceId = lastMaintenanceId;
	}

	/**
	 * @return the openTime
	 */
	public Date getOpenTime() {
		return openTime;
	}
	
	/**
	 * @param openTime
	 *            the openTime to set
	 */
	public void setOpenTime(Date openTime) {
		this.openTime = openTime;
	}

	/**
	 * @return the closedTime
	 */
	public Date getClosedTime() {
		return closedTime;
	}
	
	/**
	 * @param closedTime
	 *            the closedTime to set
	 */
	public void setClosedTime(Date closedTime) {
		this.closedTime = closedTime;
	}

	/**
	 * @return the useNormalBusinessHoursIndicator
	 */
	public String getUseNormalBusinessHoursIndicator() {
		return useNormalBusinessHoursIndicator;
	}
	
	/**
	 * @param useNormalBusinessHoursIndicator
	 *            the useNormalBusinessHoursIndicator to set
	 */
	public void setUseNormalBusinessHoursIndicator(String useNormalBusinessHoursIndicator) {
		this.useNormalBusinessHoursIndicator = useNormalBusinessHoursIndicator;
	}
	
}
