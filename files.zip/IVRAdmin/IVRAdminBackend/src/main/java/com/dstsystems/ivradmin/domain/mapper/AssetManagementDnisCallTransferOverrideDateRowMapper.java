package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.domain.AssetManagementDnisCallTransferOverrideDate;

public class AssetManagementDnisCallTransferOverrideDateRowMapper  implements RowMapper<AssetManagementDnisCallTransferOverrideDate> {
	
	private final String DNIS_Id = "DNIS_Id";
	private final String Asset_Management_DNIS_Override_Transfer_Closed_Date  = "Asset_Management_DNIS_Override_Transfer_Closed_Date ";
	private final String Last_Maintenance_Timestamp = "Last_Maintenance_Timestamp";
	private final String Last_Maintenance_Id = "Last_Maintenance_Id";
	private final String Open_Time = "Open_Time";
	private final String Closed_Time = "Closed_Time";
	private final String Use_Normal_Business_Hours_Indicator = "Use_Normal_Business_Hours_Indicator";
	
	@Override
	public AssetManagementDnisCallTransferOverrideDate mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		AssetManagementDnisCallTransferOverrideDate assetManagementDnisCallTransferOverrideDate = new AssetManagementDnisCallTransferOverrideDate();
		
		assetManagementDnisCallTransferOverrideDate.setDnisId( rs.getInt( DNIS_Id ) );
		assetManagementDnisCallTransferOverrideDate.setAssetManagementDNISOverrideTransferClosedDate( rs.getDate( Asset_Management_DNIS_Override_Transfer_Closed_Date ) );
		assetManagementDnisCallTransferOverrideDate.setLastMaintenanceTimestamp( rs.getDate( Last_Maintenance_Timestamp ) );
		assetManagementDnisCallTransferOverrideDate.setLastMaintenanceId( rs.getString( Last_Maintenance_Id ) );
		assetManagementDnisCallTransferOverrideDate.setOpenTime( rs.getDate( Open_Time ));
		assetManagementDnisCallTransferOverrideDate.setClosedTime( rs.getDate( Closed_Time ));
		assetManagementDnisCallTransferOverrideDate.setUseNormalBusinessHoursIndicator( rs.getString( Use_Normal_Business_Hours_Indicator ) );
		return assetManagementDnisCallTransferOverrideDate;
	}
}
