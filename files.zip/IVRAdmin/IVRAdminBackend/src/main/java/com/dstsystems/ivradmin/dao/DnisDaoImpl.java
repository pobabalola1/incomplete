package com.dstsystems.ivradmin.dao;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.core.domain.CallFlow;
import com.dstsystems.ivradmin.core.domain.mapper.CallFlowRowMapper;

@Repository
public class DnisDaoImpl extends BaseJdbcDAO
{
    private static final String        IVR_CLIENT_ID                 = "IVR_CLIENT_ID";
    private static final String        IVR_CLIENT_IDS                = "IVR_CLIENT_IDS";
    private static final String        CALL_FLOW_STATUS_PILOT        = "CALL_FLOW_STATUS_PILOT";
    
    private static final StringBuilder GET_ALL                       = new StringBuilder().append( " select CF.CALL_FLOW_ID, CF.DNIS_NBR, CF.IVR_CLIENT_ID " )
                                                                                          .append( " from CALL_FLOW CF " );
    
    private static final StringBuilder GET_ALL_DNIS_BY_CLIENT_ID     = new StringBuilder()                                                                        //
                                                                                           .append( " select CF.CALL_FLOW_ID, CF.DNIS_NBR, CF.IVR_CLIENT_ID " )   //
                                                                                           .append( " from CALL_FLOW CF " )
                                                                                           .append( " where CF.IVR_CLIENT_ID = :IVR_CLIENT_ID" );
    
    private static final StringBuilder GET_ALL_DNIS_BY_IN_CLIENT_IDS = new StringBuilder().append( GET_ALL )
                                                                                          .append( "where CF.IVR_CLIENT_ID IN (:IVR_CLIENT_IDS)" )
                                                                                          .append( "and CF.CALL_FLOW_STATUS_CVID = :CALL_FLOW_STATUS_PILOT" );
    
    private final static Logger        LOG                           = LoggerFactory.getLogger( DnisDaoImpl.class );
    
    public List<CallFlow> getAll()
    {
        List<CallFlow> callFlowList = null;
        try
        {
            callFlowList = getNamedParameterJdbcOperations().query( GET_ALL.toString(),
                                                                    new CallFlowRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callFlowList;
    }
    
    public List<CallFlow> getAllDnisByLineOfBusinessClientId( int lineOfBusinessClientId )
    {
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( IVR_CLIENT_ID,
                                                                              lineOfBusinessClientId );
        List<CallFlow> callFlowList = null;
        try
        {
            callFlowList = getNamedParameterJdbcOperations().query( GET_ALL_DNIS_BY_CLIENT_ID.toString(),
                                                                    parameters,
                                                                    new CallFlowRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callFlowList;
    }
    
    public List<CallFlow> getAllDnisByLineOfBusinessClientIds( Set<Integer> lineOfBusinessClientIds,
                                                               Integer callFlowStatusPilot )
    {
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( IVR_CLIENT_IDS,
                                                                              lineOfBusinessClientIds )
                                                                   .addValue( CALL_FLOW_STATUS_PILOT,
                                                                              callFlowStatusPilot );
        List<CallFlow> callFlowList = null;
        try
        {
            callFlowList = getNamedParameterJdbcOperations().query( GET_ALL_DNIS_BY_IN_CLIENT_IDS.toString(),
                                                                    parameters,
                                                                    new CallFlowRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callFlowList;
    }
    
}
