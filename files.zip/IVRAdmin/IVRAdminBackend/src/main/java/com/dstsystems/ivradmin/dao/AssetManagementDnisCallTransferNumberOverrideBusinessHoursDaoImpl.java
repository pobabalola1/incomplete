package com.dstsystems.ivradmin.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.AssetManagementDnisCallTransferNumberOverrideBusinessHours;
import com.dstsystems.ivradmin.domain.mapper.AssetManagementDnisCallTransferNumberOverrideBusinessHoursRowMapper;

@Repository
public class AssetManagementDnisCallTransferNumberOverrideBusinessHoursDaoImpl extends BaseJdbcDAO {

	private static final String DNIS_ID = "DNIS_ID";//PK FK
	private static final String ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_NUMBER_ID = "ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_NUMBER_ID";//PK FK
	private static final String DAY_OF_THE_WEEK_ID = "DAY_OF_THE_WEEK_ID";//PK FK
	
	private static final StringBuilder GET_ALL = new StringBuilder()
			.append(" select     AMDCTNOBH.DNIS_ID, AMDCTNOBH.ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_NUMBER_ID, AMDCTNOBH.DAY_OF_THE_WEEK_ID, "
					          + "AMDCTNOBH.Last_Maintenance_Timestamp, AMDCTNOBH.Last_Maintenance_Id, AMDCTNOBH.Open_Time, AMDCTNOBH.Closed_Time ")
			.append(" from       ASSET_MANAGEMENT_DNIS_CALL_TRANSFER_NUMBER_OVERRIDE_BUSINESS_HOURS AMDCTNOBH ");
	
	private final static Logger     LOG = LoggerFactory.getLogger( AssetManagementDnisCallTransferNumberOverrideBusinessHoursDaoImpl.class );
	
	public List< AssetManagementDnisCallTransferNumberOverrideBusinessHours > getAll()
    {
    	List< AssetManagementDnisCallTransferNumberOverrideBusinessHours > assetManagementDnisCallTransferNumberOverrideBusinessHours = null; 
    	try 
    	{
    		assetManagementDnisCallTransferNumberOverrideBusinessHours = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new AssetManagementDnisCallTransferNumberOverrideBusinessHoursRowMapper() );
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return assetManagementDnisCallTransferNumberOverrideBusinessHours;
    }
	
}
