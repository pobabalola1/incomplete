/*
 * FILE : DnisTouchToneNavigationDao.java
 *
 * CLASS : DnisTouchToneNavigationDao
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.dao;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.FileSystems;

import javax.validation.constraints.NotNull;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;
import org.springframework.validation.annotation.Validated;
import org.xml.sax.SAXException;

import com.dstsystems.ivradmin.core.config.TouchToneNavigationConfig;
import com.dstsystems.ivradmin.core.domain.DnisNavigationCache;
import com.dstsystems.ivradmin.core.domain.DnisNavigationCache.DnisNavigationCacheBuilder;
import com.dstsystems.ivradmin.core.exception.DaoException;

import lombok.extern.slf4j.Slf4j;

/**
 * This class is responsible for activities related to the Touch Tone Navigation resources. It makes use of configurations
 * that identify the directory path and file names to access. This dao only searches for files outside of the
 * classpath. Finally, all files accessed by this class will be validated against the related schema before handling
 * the contents of the file. XML documents that fail validation will not be parsed.
 * 
 * @author dt63314
 *
 */
@Repository
@Validated
@Slf4j
public class DnisTouchToneNavigationDao
{
    private static final String       SCHEMA_FACTORY_PROPERTY = "http://www.w3.org/2001/XMLSchema";
    private static final String       SEPARATOR               = FileSystems.getDefault()
                                                                           .getSeparator();
    
    /*
     * These are the nodes in the navigation file that we use to build a DnisNavigationCache entity.
     * The final read node is used for breaking out of the read loop, since we aren't looking for
     * nodes after the default transfer number for this mini-call flow. They are in lower case because
     * we want to perform a case-insensitive switch statement on these values.
     */
    static final String               CALL_FLOW_ID_ELEMENT    = "callflowid";
    static final String               INPUT_MODE_ELEMENT      = "inputmode";
    static final String               LANGUAGE_ELEMENT        = "language";
    static final String               GENDER_ELEMENT          = "gender";
    static final String               FINAL_READ_ELEMENT      = "messages";
    
    private TouchToneNavigationConfig touchToneNavigationConfig;
    
    @Autowired
    public void setTouchToneNavigationConfig( TouchToneNavigationConfig touchToneNavigationConfig )
    {
        this.touchToneNavigationConfig = touchToneNavigationConfig;
    }
    
    /**
     * Reads the Touch Tone Navigation configuration file, validates its contents, and if valid (gently?) shoves the XML into its associated bean. 
     * 
     * @param dnis the dnis navigation to load.
     * @return the DnisNavigationCache bean.
     * @throws DaoException 
     */
    public DnisNavigationCache getDnisNavigationCacheFor( @NotBlank String dnis ) throws DaoException
    {
        
        DnisNavigationCache dnisNavigationCache = null;
        
        try
        {
            Source xmlSource = new StreamSource( getXmlResource( dnis,
                                                                 touchToneNavigationConfig.getResourceType() ) );
            Source schemaSource = new StreamSource( getSchemaResource( touchToneNavigationConfig.getResourceType() ) );
            validateXmlSource( xmlSource, schemaSource );
            // No SAX exception == valid, continue.
            dnisNavigationCache = buildDnisNavigationFromXmlSource( dnis,
                                                                    xmlSource );
        }
        catch( IOException ex )
        {
            // File error may be xml or xsd
            String message = new StringBuilder().append( "File IO error encountered for DNIS " )
                                                .append( dnis )
                                                .append( ": " )
                                                .append( ex.getMessage() )
                                                .toString();
            log.error( message );
            throw new DaoException( message, ex );
        }
        catch( SAXException | XMLStreamException ex )
        {
            // validation error.
            String message = new StringBuilder().append( "Error handling " )
                                                .append( touchToneNavigationConfig.getXmlDirectory() )
                                                .append( SEPARATOR )
                                                .append( touchToneNavigationConfig.getFileFor( dnis ) )
                                                .append( ": " )
                                                .append( ex.getMessage() )
                                                .toString();
            log.error( message );
            throw new DaoException( message, ex );
        }
        catch( Exception ex )
        {
            log.error( "Exception thrown working on dnis " + dnis
                       + " touch tone navigation configuration file. Error message: "
                       + ex.getMessage() );
        }
        
        return dnisNavigationCache;
    }
    
    /**
     * Reads the Xml Source for specific elements. When a start element is encountered, the element name is evaluated 
     * for inclusion in the {@link DnisNavigationCache.DnisNavigationCacheBuilder}. Processing continues until the {@value #FINAL_READ_ELEMENT}
     * is encountered. This method assumes it is working with a valid / validated Xml Source. Operations are not guaranteed to work
     * as intended if the Xml has invalid content, as described by its schema.
     * 
     * @param dnis - the dnis for this request.
     * @param xmlSource - the xml input stream.
     * @return the populated DnisNavigationCache object, carrying a small portion of the navigation document's information.
     * @throws XMLStreamException thrown if an error is encountered iterating over the provided Xml Source.
     */
    DnisNavigationCache buildDnisNavigationFromXmlSource( @NotBlank String dnis,
                                                          @NotNull Source xmlSource ) throws XMLStreamException
    {
        log.debug( String.format( "Processing navigation document for DNIS %s.",
                                  dnis ) );
        XMLInputFactory xmlInputFactory = XMLInputFactory.newFactory();
        XMLStreamReader xmlStreamReader = null;
        DnisNavigationCacheBuilder builder = DnisNavigationCache.builder()
                                                                .dnis( dnis );
        
        try
        {
            xmlStreamReader = xmlInputFactory.createXMLStreamReader( xmlSource );
            
            // Skip the "START_DOCUMENT" element.
            xmlStreamReader.nextTag();
            
            String elementName = null;
            
            search: while( xmlStreamReader.hasNext() )
            {
                switch( xmlStreamReader.getEventType() )
                {
                    case XMLStreamConstants.START_ELEMENT:
                        elementName = xmlStreamReader.getName()
                                                     .toString();
                        break;
                    case XMLStreamConstants.END_ELEMENT:
                        elementName = "";
                        if( xmlStreamReader.getLocalName()
                                           .equalsIgnoreCase( FINAL_READ_ELEMENT ) )
                        {
                            // Exit loop when we find the node after the last element we need.
                            break search;
                        }
                        break;
                    case XMLStreamConstants.CHARACTERS:
                        log.debug( "Parsing element " + elementName
                                   + " on dnis " + dnis + "." );
                        evaluateElement( builder,
                                         elementName,
                                         xmlStreamReader.getText() );
                        break;
                    case XMLStreamConstants.END_DOCUMENT:
                        // Defensive for self-closing tag leading to END_DOCUMENT.
                        break search;
                    default:
                        // Ignore other events.
                        break;
                }
                
                xmlStreamReader.next();
            }
        }
        finally
        {
            if( xmlStreamReader != null )
            {
                try
                {
                    xmlStreamReader.close();
                }
                catch( XMLStreamException ex )
                {
                    // Ignore.
                }
            }
        }
        
        log.debug( "Returning builder with the following contents: "
                   + builder.toString() );
        
        return builder.build();
    }
    
    /**
     * Applies the elementText to the Builder if it is a recognized node name (localName). If invalid content is caught during 
     * any build operation, the exception will be rethrown as an XMLStreamException because the data causing the issue originates
     * in the XML source.
     * 
     * @param builder - the builder to which we apply the elementText.
     * @param elementName - the name of the current element.
     * @param elementText - the contents to apply to the builder. 
     * @throws XMLStreamException thrown if a runtime exception is thrown for invalid element text.
     */
    void evaluateElement( @NotNull DnisNavigationCacheBuilder builder,
                          @NotBlank String elementName,
                          @NotBlank String elementText ) throws XMLStreamException
    {
        try
        {
            switch( elementName.toLowerCase() )
            {
                case CALL_FLOW_ID_ELEMENT:
                    builder.callFlowId( new BigInteger( elementText ) );
                    break;
                case INPUT_MODE_ELEMENT:
                    builder.inputMode( elementText );
                    break;
                case LANGUAGE_ELEMENT:
                    builder.language( elementText );
                    break;
                case GENDER_ELEMENT:
                    builder.gender( elementText );
                    break;
                default:
                    // Ignore others.
                    break;
            }
        }
        catch( RuntimeException ex )
        {
            throw new XMLStreamException( "Invalid contents in the current element ("
                                          + elementName + "): " + elementText
                                          + ".",
                                          ex );
        }
        
    }
    
    /**
     * Fetches the Schema File from the specified resource (i.e. classpath:, file:). Throws an IOException
     * if the Resource does not find a file or is otherwise unable to access the Schema file. The file name
     * and directory are taken from the configuration settings.
     * 
     * @param resourceType identifies how the resource should be accessed.
     * @return the schema file.
     * @throws IOException thrown if the Resource fails to access the file.
     */
    File getSchemaResource( @NotBlank String resourceType ) throws IOException
    {
        Resource resource = getResource( resourceType,
                                         touchToneNavigationConfig.getXsdDirectory(),
                                         touchToneNavigationConfig.getXsdFileName() );
        return resource.getFile();
    }
    
    /**
     * Constructs a Resource for the given resourceType (i.e. file:, classpath:), path, and named file. Refer to {@link Resource}
     * for more information about this type.
     * 
     * @param resourceType identifies whether this resource is on the classpath or a file outside of the application code.
     * @param directory the directory name
     * @param fileName the file to load
     * @return the resource.
     */
    Resource getResource( @NotBlank String resourceType,
                          @NotBlank String directory,
                          @NotBlank String fileName )
    {
        StringBuilder builder = new StringBuilder();
        builder.append( resourceType );
        builder.append( directory )
               .append( SEPARATOR );
        builder.append( fileName );
        
        log.debug( "Loading resource: " + builder.toString() );
        
        return new DefaultResourceLoader().getResource( builder.toString() );
    }
    
    /**
     * Fetches the Dnis XML File from the specified resource (i.e. classpath:, file:). Throws an IOException
     * if the Resource does not find a file or is otherwise unable to access the file. The file name
     * and directory are taken from the configuration settings in combination with the given Dnis.
     * 
     * @param dnis the client identifier for the navigation file.
     * @param resourceType identifies how the resource should be accessed.
     * @return the Dnis xml file.
     * @throws IOException thrown if the Resource fails to access the file.
     */
    File getXmlResource( @NotBlank String dnis,
                         @NotBlank String resourceType ) throws IOException
    {
        Resource resource = getResource( resourceType,
                                         touchToneNavigationConfig.getXmlDirectory(),
                                         touchToneNavigationConfig.getFileFor( dnis ) );
        return resource.getFile();
    }
    
    /**
     * Validates the given Source against the provided schema.
     * 
     * @param xmlSource - the xml Source.
     * @param schemaSource - the schema Source.
     * @throws SAXException thrown if an error occurs during validation.
     * @throws IOException thrown if an error occurs handling the XML source.
     */
    void validateXmlSource( @NotNull Source xmlSource,
                            @NotNull Source schemaSource ) throws SAXException,
                                                           IOException
    {
        SchemaFactory schemaFactory = SchemaFactory.newInstance( SCHEMA_FACTORY_PROPERTY );
        Schema schema = schemaFactory.newSchema( schemaSource );
        Validator validator = schema.newValidator();
        log.debug( "Validating the xml source." );
        validator.validate( xmlSource );
    }
}
