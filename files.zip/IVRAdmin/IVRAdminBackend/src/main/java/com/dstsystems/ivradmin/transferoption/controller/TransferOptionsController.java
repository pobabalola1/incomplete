/**
 * 
 */
package com.dstsystems.ivradmin.transferoption.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.core.controller.BaseController;
import com.dstsystems.ivradmin.core.dao.CallFlowDaoImpl;
import com.dstsystems.ivradmin.core.domain.CallFlowExt;
import com.dstsystems.ivradmin.transferoption.dao.DnisCallTransferHierarchyDaoImpl;
import com.dstsystems.ivradmin.transferoption.domain.TransferHierarchy;
import com.dstsystems.ivradmin.transferoption.domain.TransferOption;

/**
 * @author dt86783
 */
@RestController
public class TransferOptionsController extends BaseController
{
    @Autowired
    private DnisCallTransferHierarchyDaoImpl transferHierarchyDaoImpl;
    
    @Autowired
    private CallFlowDaoImpl                  callFlowDaoImpl;
    
    
    @RequestMapping(path = "/transfer-hierarchy/{callFlowId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public List<TransferHierarchy> getTransferHierarchiesByDnis( @PathVariable Integer callFlowId )
    {
        
        List<TransferHierarchy> thList = transferHierarchyDaoImpl.getByCallFlowId( callFlowId );
        return thList;
    }
    
    @RequestMapping(path = "/transfer-option/{callFlowId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public TransferOption getTransferOptionByDnis( @PathVariable Integer callFlowId )
    {
        CallFlowExt cf = callFlowDaoImpl.getExtByCallFlowId( callFlowId );
        List<TransferHierarchy> thList = transferHierarchyDaoImpl.getByCallFlowId( callFlowId );
        
        TransferOption to = TransferOption.builder()
                                          .callFlow( cf )
                                          .transferHierarchies( thList )
                                          .build();
        return to;
    }
    
    
}
