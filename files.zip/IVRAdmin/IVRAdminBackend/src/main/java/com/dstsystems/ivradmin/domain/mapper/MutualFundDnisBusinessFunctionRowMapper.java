package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.fund.domain.MutualFundDnisBusinessFunction;

public class MutualFundDnisBusinessFunctionRowMapper implements RowMapper<MutualFundDnisBusinessFunction>{

	private final String DNIS_ID = "DNIS_ID";
	private final String IVR_MUTUAL_FUND_ID = "IVR_MUTUAL_FUND_ID";
	private final String FUNCTION_ID = "FUNCTION_ID";
	private final String LAST_MAINTENANCE_OPERATOR_ID = "LAST_MAINTENANCE_OPERATOR_ID";
	
	@Override
	public MutualFundDnisBusinessFunction mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		MutualFundDnisBusinessFunction mutualFundDnisBusinessFunction = new MutualFundDnisBusinessFunction();
		mutualFundDnisBusinessFunction.setDnisId( rs.getInt( DNIS_ID ) );
		mutualFundDnisBusinessFunction.setIvrMutualFundId( rs.getInt( IVR_MUTUAL_FUND_ID ) );
		mutualFundDnisBusinessFunction.setFunctionId( rs.getInt( FUNCTION_ID ) );
		mutualFundDnisBusinessFunction.setLastMaintenanceOperatorId( rs.getString( LAST_MAINTENANCE_OPERATOR_ID ) );
		return mutualFundDnisBusinessFunction;
	}
	
}
