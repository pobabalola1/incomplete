/**
 * 
 */
package com.dstsystems.ivradmin.core.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.dstsystems.ivradmin.core.domain.CodeSetValue;
import com.dstsystems.ivradmin.core.domain.IVRRecording;

/**
 * @author dt86783
 *
 */
@Component
public class IVRRecordingRowMapper implements RowMapper< IVRRecording >   
{
   private final String RECORDING_ID = "RECORDING_ID";  
   private final String GENDER_CD = "GENDER_CD";  
   private final String RECORDING_TYPE_CVID = "RECORDING_TYPE_CVID";    
   private final String IVR_LANGUAGE_CVID = "IVR_LANGUAGE_CVID"; 
   private final String ENGLISH_SCRIPT_TXT = "ENGLISH_SCRIPT_TXT";
   private final String STATUS_CVID = "STATUS_CVID";
   private final String ALTERNATE_LANGUAGE_SCRIPT_TXT = "ALTERNATE_LANGUAGE_SCRIPT_TXT";  
   private final String NOTES_TXT = "NOTES_TXT"; 
   
   @Override
   public IVRRecording mapRow( ResultSet rs, int rowNum ) throws SQLException
   {
      IVRRecording ivr = IVRRecording.builder()
                           .ivrRecordingId( rs.getInt( RECORDING_ID ) )
                           .gender( IVRRecording.Gender.toGenderFromCode( rs.getString( GENDER_CD ) ) )
                           .recordingTypeCvid( rs.getInt( RECORDING_TYPE_CVID ) )
                           .ivrLangCvid( rs.getInt( IVR_LANGUAGE_CVID )  )
                           .engScriptText( rs.getString( ENGLISH_SCRIPT_TXT ) )
                           .statusCvid( rs.getInt( STATUS_CVID ) )
                           .altScriptText( rs.getString( ALTERNATE_LANGUAGE_SCRIPT_TXT ) )
                           .notesText( rs.getString( NOTES_TXT ) )
                           .build();
      
      return ivr;
   }
   
}
