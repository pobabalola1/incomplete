package com.dstsystems.ivradmin.callflowfunction.domain;

public class CallFlowFunctionGroup
{
    private Integer callFlowId;
    private Integer functionGrpId;
    private String  functionGrpName;
    //private String lastMaintenanceDateTime; 
    private String  lastMaintenanceOperatorId;
    
    /**
     * @return the dnisId
     */
    public Integer getCallFlowId()
    {
        return callFlowId;
    }
    
    /**
     * @param dnisId the dnisId to set
     */
    public void setCallFlowId( Integer callFlowId )
    {
        this.callFlowId = callFlowId;
    }
    
    /**
     * @return the functionId
     */
    public Integer getFunctionGrpId()
    {
        return functionGrpId;
    }
    
    /**
     * @param functionId the functionId to set
     */
    public void setFunctionGrpId( Integer functionId )
    {
        this.functionGrpId = functionId;
    }
    
    /**
     * @return the lastMaintenanceOperatorId
     */
    public String getLastMaintenanceOperatorId()
    {
        return lastMaintenanceOperatorId;
    }
    
    /**
     * @param lastMaintenanceOperatorId the lastMaintenanceOperatorId to set
     */
    public void setLastMaintenanceOperatorId( String lastMaintenanceOperatorId )
    {
        this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
    }
    
    public String getFunctionGrpName()
    {
        return functionGrpName;
    }
    
    public void setFunctionGrpName( String functionName )
    {
        this.functionGrpName = functionName;
    }
    
    
}
