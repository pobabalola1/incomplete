/*
 * FILE : AdminApplication.java
 *
 * CLASS : AdminApplication
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.dstsystems.ivradmin.core.config.TouchToneNavigationConfig;
import com.dstsystems.ivradmin.hazelcast.config.HazelcastServerConfigProperties;
import com.dstsystems.ivradmin.session.config.SessionConfigProperties;
import com.dstsystems.ivradmin.web.config.ServerProperties;


@SpringBootApplication
@EnableConfigurationProperties({ ServerProperties.class,
                                 SessionConfigProperties.class,
                                 HazelcastServerConfigProperties.class,
                                 TouchToneNavigationConfig.class})
public class AdminApplication
{
    
    public static void main( String[] args )
    {
        SpringApplication.run( AdminApplication.class, args );
    }
}
