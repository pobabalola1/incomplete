/**
 * 
 */
package com.dstsystems.ivradmin.callflowfunction.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowTransferNumber;

/**
 * @author dt76669
 *
 */
public class CallFlowTransferNumbersRowMapper implements
                                              RowMapper<CallFlowTransferNumber>
{
    private final String CALL_FLOW_ID                 = "CALL_FLOW_ID";
    private final String CALL_FLOW_TRANSFER_NUMBER_ID = "CALL_FLOW_TRANSFER_NUMBER_ID";
    private final String TRANSFER_NUMBER_NM           = "TRANSFER_NUMBER_NM";
    private final String LAST_MAINTENANCE_ID          = "LAST_MAINTENANCE_ID";
    
    
    @Override
    public CallFlowTransferNumber mapRow( ResultSet rs,
                                          int rowNum ) throws SQLException
    {
        CallFlowTransferNumber callFlowTransferNumber = new CallFlowTransferNumber();
        callFlowTransferNumber.setCallFlowId( rs.getInt( CALL_FLOW_ID ) );
        callFlowTransferNumber.setTransferNumberId( rs.getInt( CALL_FLOW_TRANSFER_NUMBER_ID ) );
        callFlowTransferNumber.setTransferNumberName( rs.getString( TRANSFER_NUMBER_NM ) );
        callFlowTransferNumber.setLastMaintenanceId( rs.getString( LAST_MAINTENANCE_ID ) );
        return callFlowTransferNumber;
    }
}
