/**
 * 
 */
package com.dstsystems.ivradmin.closure.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.dstsystems.ivradmin.closure.domain.Closure;

/**
 * @author dt86783
 *
 */
@Component
public class DefaultClosureRowMapper implements RowMapper< Closure >
{
   private static final String TRANSFER_CLOSED_DT = "TRANSFER_CLOSED_DT";
   private static final String OPEN_TM = "OPEN_TM";
   private static final String CLOSED_TM = "CLOSED_TM";
   
   private static final SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
   
   @Override
   public Closure mapRow( ResultSet rs, int rowNum ) throws SQLException
   {
      Closure closure = Closure.builder()
                        .closeDate( rs.getDate( TRANSFER_CLOSED_DT ) )
                        .startTime( sdf.format( Time.valueOf( rs.getString( OPEN_TM ) ) ) )
                        .closeTime( sdf.format( Time.valueOf( rs.getString( CLOSED_TM ) ) ) )
                        .defaultCloseDate( true )
                        .closedAllDay( true )
                        .overridedHours( false )
                        .normalBusinessHours( false )
                        .name( "MOCK DATE " + rs.getDate( TRANSFER_CLOSED_DT ) ) //Define later.
                        .useDefaultIvr( true )
                        .build();
      return closure;
   }
   
}
