/*
 * FILE : HazelcastHttpSessionConfig.java
 *
 * CLASS : HazelcastHttpSessionConfig
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.session.config;

import static org.springframework.session.hazelcast.HazelcastSessionRepository.PRINCIPAL_NAME_ATTRIBUTE;

import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.hazelcast.HazelcastSessionRepository;
import org.springframework.session.hazelcast.PrincipalNameExtractor;
import org.springframework.session.hazelcast.config.annotation.web.http.EnableHazelcastHttpSession;
import org.springframework.session.hazelcast.config.annotation.web.http.HazelcastHttpSessionConfiguration;

import com.dstsystems.ivradmin.hazelcast.config.HazelcastServerConfig;
import com.hazelcast.config.Config;
import com.hazelcast.config.MapAttributeConfig;
import com.hazelcast.config.MapIndexConfig;
import com.hazelcast.core.HazelcastInstance;


/**
 * @EnableHazelcastHttpSession must be annotated here.
 * Otherwise override sessionRepository method is not called.
 * 
 * This code is taken from the implementation found in the ivr-core project.
 */
@EnableHazelcastHttpSession
@Configuration
@AutoConfigureAfter({ HazelcastServerConfig.class })
public class HazelcastHttpSessionConfig extends HazelcastHttpSessionConfiguration
{
    private SessionConfigProperties sessionConfig;
    
    public HazelcastHttpSessionConfig( SessionConfigProperties sessionConfig )
    {
        this.sessionConfig = sessionConfig;
    }
    
    @Override
    @Bean
    public HazelcastSessionRepository sessionRepository( HazelcastInstance hazelcastInstance,
                                                         ApplicationEventPublisher eventPublisher )
    {
        setMaxInactiveIntervalInSeconds( sessionConfig.getTimeoutInSeconds() );
        setSessionMapName( sessionConfig.getMapName() );
        
        setSessionCacheConfig( hazelcastInstance.getConfig() );
        
        return super.sessionRepository( hazelcastInstance, eventPublisher );
    }
    
    private void setSessionCacheConfig( Config config )
    {
        MapAttributeConfig attributeConfig = new MapAttributeConfig();
        attributeConfig.setName( PRINCIPAL_NAME_ATTRIBUTE ).setExtractor( PrincipalNameExtractor.class.getName() );
        
        config.getMapConfig( sessionConfig.getMapName() ).addMapAttributeConfig( attributeConfig ).addMapIndexConfig( new MapIndexConfig( PRINCIPAL_NAME_ATTRIBUTE,
                                                                                                                                          false ) );
    }
}
