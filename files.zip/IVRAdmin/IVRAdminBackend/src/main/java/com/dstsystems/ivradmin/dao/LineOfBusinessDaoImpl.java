/**
 * 
 */
package com.dstsystems.ivradmin.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.LineOfBusiness;
import com.dstsystems.ivradmin.domain.mapper.LineOfBusinessRowMapper;

/**
 * @author dt86783
 *
 */
@Repository
public class LineOfBusinessDaoImpl extends BaseJdbcDAO
{
    
    private static final String         LINE_OF_BUSINESS_ID       = "LINE_OF_BUSINESS_ID";
    
    private static final StringBuilder  GET_ALL_LOB_WITH_NO_CHILD = new StringBuilder().append( " select   lob.LINE_OF_BUSINESS_ID, lob.LINE_OF_BUSINESS_NM " )
                                                                                       .append( " from    LINE_OF_BUSINESS lob " );
    
    private static final StringBuilder  GET_ALL_LOB_BY_ID         = new StringBuilder().append( GET_ALL_LOB_WITH_NO_CHILD.toString() )
                                                                                       .append( " where lob.LINE_OF_BUSINESS_ID = :LINE_OF_BUSINESS_ID" );
    
    private final static Logger         LOG                       = LoggerFactory.getLogger( LineOfBusinessDaoImpl.class );
    
    @Autowired
    private LineOfBusinessClientDaoImpl lineOfBusinessClientDao;
    
    public List<LineOfBusiness> getAll()
    {
        List<LineOfBusiness> lineOfBusinessList = null;
        try
        {
            lineOfBusinessList = getNamedParameterJdbcOperations().query( GET_ALL_LOB_WITH_NO_CHILD.toString(),
                                                                          new LineOfBusinessRowMapper() );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return lineOfBusinessList;
    }
    
    public LineOfBusiness getAllLineOfBusinessById( int id, int callFlowStatus )
    {
        return getAllLineOfBusinessById( id, true, callFlowStatus );
    }
    
    public LineOfBusiness getAllLineOfBusinessById( int id,
                                                    boolean fetchChild,
                                                    int callFlowStatus )
    {
        LineOfBusiness lineOfBusiness = null;
        try
        {
            SqlParameterSource parameters = new MapSqlParameterSource().addValue( LINE_OF_BUSINESS_ID,
                                                                                  id );
            
            lineOfBusiness = getNamedParameterJdbcOperations().query( GET_ALL_LOB_BY_ID.toString(),
                                                                      parameters,
                                                                      new LineOfBusinessRowMapper() )
                                                              .get( 0 );
            
            if( fetchChild )
            {
                lineOfBusiness.setLineOfBusinessClients( lineOfBusinessClientDao.getAllLineOfBusinessClientByLineOfBusinessId( id,
                                                                                                                               callFlowStatus ) );
            }
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        
        return lineOfBusiness;
    }
}
