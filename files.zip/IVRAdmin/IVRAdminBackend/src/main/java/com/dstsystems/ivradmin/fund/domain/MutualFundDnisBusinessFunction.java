package com.dstsystems.ivradmin.fund.domain;

public class MutualFundDnisBusinessFunction {
	private Integer dnisId;
	private Integer ivrMutualFundId;
	private Integer functionId;
  //private String lastMaintenanceDateTime; 
    private String lastMaintenanceOperatorId;
    
    /**
     * @return the dnisId
     */
	public Integer getDnisId() {
		return dnisId;
	}
	
	/**
	 * @param dnisId the dnisId to set
	 */
	public void setDnisId(Integer dnisId) {
		this.dnisId = dnisId;
	}
	
    /**
     * @return the ivrMutualFundId
     */
	public Integer getIvrMutualFundId() {
		return ivrMutualFundId;
	}
	
	/**
	 * @param ivrMutualFundId the ivrMutualFundId to set
	 */
	public void setIvrMutualFundId(Integer ivrMutualFundId) {
		this.ivrMutualFundId = ivrMutualFundId;
	}
	
    /**
     * @return the functionId
     */	
	public Integer getFunctionId() {
		return functionId;
	}
	
	/**
	 * @param functionId the functionId to set
	 */
	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}
	
    /**
     * @return the lastMaintenanceOperatorId
     */	
	public String getLastMaintenanceOperatorId() {
		return lastMaintenanceOperatorId;
	}
	
	/**
	 * @param lastMaintenanceOperatorId the lastMaintenanceOperatorId to set
	 */
	public void setLastMaintenanceOperatorId(String lastMaintenanceOperatorId) {
		this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
	}
    
    
    
}
