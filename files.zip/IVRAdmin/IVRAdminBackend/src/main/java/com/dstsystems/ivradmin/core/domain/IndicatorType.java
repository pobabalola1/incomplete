package com.dstsystems.ivradmin.core.domain;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

public enum IndicatorType {
   
   YES ( "Y" ), NO ( "N" ), NA ( "Z" );
   
   private static Map<String, IndicatorType> typeMapping = new HashMap<String, IndicatorType>();
   static {
      typeMapping.put( YES.getValue(), YES );
      typeMapping.put( NO.getValue(), NO );
      typeMapping.put( NA.getValue(), NA );
  }
   
   private final String indicator;
   
   IndicatorType( String ind )
   {
      this.indicator = ind;
   }
   
   @JsonValue
   public String getValue() 
   {
      return this.indicator;
   }
   
   public static IndicatorType asIndType( String ind ) 
   {
      return typeMapping.get( ind );
   }
      
   
}
