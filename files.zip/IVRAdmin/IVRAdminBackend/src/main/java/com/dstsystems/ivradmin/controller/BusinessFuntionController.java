package com.dstsystems.ivradmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.callflowfunction.domain.BusinessFunction;
import com.dstsystems.ivradmin.dao.BusinessFunctionDaoImpl;

@RestController
public class BusinessFuntionController {
	   @Autowired
	   private BusinessFunctionDaoImpl businessFunctionDaoImpl;
	   
	   @RequestMapping(path = "/api/data/business-functions" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	   @ResponseBody
	   public List< BusinessFunction > getAll()
	   {
	      return businessFunctionDaoImpl.getAll();
	   }
	   
	   @RequestMapping(path = "/api/data/business-function/{functionId}" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	   @ResponseBody
	   public BusinessFunction getAllByFunctionId( @PathVariable int functionId ) 
	   {
	      return businessFunctionDaoImpl.getByFunctionId( functionId );
	   } 
}
 