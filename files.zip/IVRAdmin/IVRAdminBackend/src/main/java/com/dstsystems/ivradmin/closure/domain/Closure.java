/**
 * 
 */
package com.dstsystems.ivradmin.closure.domain;

import java.sql.Time;
import java.util.Date;

import com.dstsystems.ivradmin.core.domain.IVRRecording;

import lombok.Builder;
import lombok.Data;

/**
 * @author dt86783
 *
 */

@Data
@Builder
public class Closure
{
   private String name;
   private Date closeDate;
   private String startTime;
   private String closeTime;
   private boolean defaultCloseDate; 
   private Integer overrideTransferClosedRecordId;
   private IVRRecording overrideTransferClosedRecord;
   private boolean closedAllDay;
   private boolean overridedHours;
   private boolean normalBusinessHours;
   private boolean useDefaultIvr;
   
}
