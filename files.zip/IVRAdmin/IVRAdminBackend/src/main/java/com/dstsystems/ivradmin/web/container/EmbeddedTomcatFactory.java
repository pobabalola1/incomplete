/*
 * COPYRIGHT:
 *
 *   The computer systems, procedures, data bases and programs
 *   created and maintained by DST Systems, Inc., are proprietary
 *   in nature and as such are confidential.  Any unauthorized
 *   use or disclosure of such information may result in civil
 *   liabilities.
 *
 *   Copyright 2017 by DST Systems, Inc.
 *   All Rights Reserved.
 */
package com.dstsystems.ivradmin.web.container;

import java.io.File;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;

public class EmbeddedTomcatFactory extends TomcatEmbeddedServletContainerFactory {

    private static final Logger logger = LoggerFactory.getLogger(EmbeddedTomcatFactory.class);

    public EmbeddedTomcatFactory() {
        super();
    }

    @Override
    protected TomcatEmbeddedServletContainer getTomcatEmbeddedServletContainer(Tomcat tomcat) {
        tomcat.enableNaming();
        return super.getTomcatEmbeddedServletContainer(tomcat);
    }

    @Override
    protected void postProcessContext(Context context) {
    }

    public File makeDirectory(String pathname) {
        File directory = new File(pathname);
        directory.mkdirs();
        return directory;
    }

}

