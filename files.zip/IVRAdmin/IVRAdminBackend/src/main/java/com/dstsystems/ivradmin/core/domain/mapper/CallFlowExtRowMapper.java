package com.dstsystems.ivradmin.core.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.dstsystems.ivradmin.core.dao.CodeSetValueDaoImpl;
import com.dstsystems.ivradmin.core.domain.CallFlowExt;
import com.dstsystems.ivradmin.core.domain.IndicatorType;

@Component
public class CallFlowExtRowMapper  implements RowMapper< CallFlowExt > {
	   
   private final String CALL_FLOW_ID                    = "CALL_FLOW_ID";
   private final String IVR_CLIENT_ID                   = "IVR_CLIENT_ID";
   private final String DNIS_NBR                        = "DNIS_NBR";
   private final String CALL_FLOW_STATUS_CVID           = "CALL_FLOW_STATUS_CVID";
   private final String ALWAYS_TRANSFER_IND             = "ALWAYS_TRANSFER_IND";
   private final String ALWAYS_TRANSFER_STOP_MAIL_IND   = "ALWAYS_TRANSFER_STOP_MAIL_IND";
   private final String USE_EXTERNAL_PIN_IND            = "USE_EXTERNAL_PIN_IND";
   private final String USER_AUTHENTICATION_METHOD_CVID = "USER_AUTHENTICATION_METHOD_CVID";
   private final String ACCOUNT_GROUP_METHOD_CVID       = "ACCOUNT_GROUP_METHOD_CVID";
   private final String TRANSFER_CLOSED_RECORDING_ID    = "TRANSFER_CLOSED_RECORDING_ID";
	
   @Autowired
   private CodeSetValueDaoImpl csvd; 
   
	@Override
	public CallFlowExt mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
	   
	   //Handle nullable numeric columns.
	   int temp = 0;
	   
	   Integer userAuthenticationMethodCvid = null;
	   temp = rs.getInt( USER_AUTHENTICATION_METHOD_CVID );
	   if ( temp == 0 ) 
	   {
	      if ( !rs.wasNull() ) 
	      {
	         userAuthenticationMethodCvid = 0;
	      }
	   }
	   
	   Integer accountGroupMethodCvid = null;
	   temp = rs.getInt( ACCOUNT_GROUP_METHOD_CVID ); 
	   if ( temp == 0) 
	   {
	      if ( !rs.wasNull() ) 
          {
	         accountGroupMethodCvid = 0;
          }
	   }
	   
	   Integer transferClosedRecordingId = null;
       temp = rs.getInt( TRANSFER_CLOSED_RECORDING_ID ); 
       if ( temp == 0) 
       {
          if ( !rs.wasNull() ) 
          {
             transferClosedRecordingId = 0;
          }
       }
	   
	   
	   CallFlowExt callFlow = CallFlowExt.builder()
		                                          .callFlowId( rs.getInt( CALL_FLOW_ID ) )
		                                          .ivrClientId( rs.getInt( IVR_CLIENT_ID ) )
		                                          .dnisNbr( rs.getString( DNIS_NBR ) )
		                                          .callFlowStatusCvid( rs.getInt( CALL_FLOW_STATUS_CVID ) )
		                                          .alwaysTransferIndicator( IndicatorType.asIndType( rs.getString( ALWAYS_TRANSFER_IND ) ) )
		                                          .alwaysTransferOnStopMailIndicator( IndicatorType.asIndType( rs.getString( ALWAYS_TRANSFER_STOP_MAIL_IND ) ) )
		                                          .useExternalPinValidationIndicator( IndicatorType.asIndType( rs.getString( USE_EXTERNAL_PIN_IND ) ) )
		                                          .userAuthenticationMethodCvid( userAuthenticationMethodCvid )
		                                          .accountGroupMethodCvid( accountGroupMethodCvid )
		                                          .transferClosedRecordingId( transferClosedRecordingId )
		                                          .build();
	   
	   //Get code set value.
	   callFlow.setCallFlowStatus( csvd.getByCodeSetValueId( callFlow.getCallFlowStatusCvid() ) );
	   
	   if ( callFlow.getUserAuthenticationMethodCvid() != null ) 
	   {
	      callFlow.setUserAuthenticationMethod( csvd.getByCodeSetValueId( callFlow.getUserAuthenticationMethodCvid() ) );
	   }
	   
	   if ( callFlow.getAccountGroupMethodCvid() != null ) 
	   {
	      callFlow.setAccountGroupMethod( csvd.getByCodeSetValueId( callFlow.getAccountGroupMethodCvid() ) );
	   }
	                                        
	   
		return callFlow; 
	}
	
	
}
