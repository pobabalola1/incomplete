/*
 * FILE : HazelcastServerConfigProperties.java
 *
 * CLASS : HazelcastServerConfigProperties
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.hazelcast.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

/**
 * This code is a copy of the same class in the ivr-core project.
 * @author dt63314
 *
 */
@ConfigurationProperties(prefix = "spring.hazelcast.server")
@Data
public class HazelcastServerConfigProperties
{
    private String configClasspath;
    private String instanceName;
    private String jmx = "false";
}
