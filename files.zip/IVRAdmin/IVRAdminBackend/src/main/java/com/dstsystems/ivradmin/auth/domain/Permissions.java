package com.dstsystems.ivradmin.auth.domain;

import lombok.Data;

@Data
public class Permissions {
	
	String[] permissionList;
	String role;
	

}
