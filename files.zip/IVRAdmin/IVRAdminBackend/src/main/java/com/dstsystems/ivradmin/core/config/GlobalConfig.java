/*
 * FILE : GlobalConfigProperties.java
 *
 * CLASS : GlobalConfigProperties
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.config;

import java.math.BigInteger;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "global-config")
public class GlobalConfig
{
    private int        callFlowStatusPilot;
    private int        functionTransferHeirarchy;
    private BigInteger bigCallFlowStatusPilot;
    
    /**
     * @return the callFlowStatusPilot
     */
    public int getCallFlowStatusPilot()
    {
        return callFlowStatusPilot;
    }
    
    /**
     * @param callFlowStatusPilot the callFlowStatusPilot to set
     */
    public void setCallFlowStatusPilot( int callFlowStatusPilot )
    {
        this.callFlowStatusPilot = callFlowStatusPilot;
        this.bigCallFlowStatusPilot = new BigInteger( String.valueOf( callFlowStatusPilot ) );
    }
    
    /**
     * @return the functionTransferHeirarchy
     */
    public int getFunctionTransferHeirarchy()
    {
        return functionTransferHeirarchy;
    }
    
    /**
     * @param functionTransferHeirarchy the functionTransferHeirarchy to set
     */
    public void setFunctionTransferHeirarchy( int functionTransferHeirarchy )
    {
        this.functionTransferHeirarchy = functionTransferHeirarchy;
    }
    
    /**
     * 
     * @return bigCallFlowStatusPilot a convenience method for retrieving the "Pilot" 
     * status code as a BigInteger.
     */
    public BigInteger getCallFlowStatusPilotAsBigInteger()
    {
        return bigCallFlowStatusPilot;
    }
    
}
