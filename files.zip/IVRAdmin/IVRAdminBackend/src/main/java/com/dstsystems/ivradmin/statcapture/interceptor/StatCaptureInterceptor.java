/*
 * FILE : StatCaptureInterceptor.java
 *
 * CLASS : StatCaptureInterceptor
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.statcapture.interceptor;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.dstsystems.ivradmin.auth.domain.Associate;
import com.dstsystems.ivradmin.session.domain.AdminSessionAttributes;
import com.dstsystems.ivradmin.session.service.AdminSessionService;
import com.dstsystems.ivradmin.statcapture.config.StatCaptureProperties;
import com.dstsystems.statcapture.web.RequestStatistic;
import com.dstsystems.statcapture.web.WebStatisticContextImpl;

import lombok.extern.slf4j.Slf4j;


/**
 * Custom Implementation of StatCaptureIntercepter to override DST Spring's
 * StatCaptureIntercepter that works with Spring's Interceptors instead of
 * javax.Aspects.
 * 
 * dt63314
 *
 */
@Slf4j
public class StatCaptureInterceptor extends HandlerInterceptorAdapter
{
    private StatCaptureProperties properties;
    private AdminSessionService   sessionService;
    
    private static final String   WEBSTAT_CONTEXT_ATTRIBUTE_NAME = "webstatcontext";
    public static final String    LOGIN_USER_NAME                = "loginUserName";
    
    public StatCaptureInterceptor( StatCaptureProperties properties,
                                   AdminSessionService sessionService )
    {
        super();
        this.properties = properties;
        this.sessionService = sessionService;
    }
    
    @Override
    public boolean preHandle( HttpServletRequest request,
                              HttpServletResponse response,
                              Object handler ) throws Exception
    {
        WebStatisticContextImpl context = WebStatisticContextImpl.createInstance( properties,
                                                                                  request );
        
        request.setAttribute( WEBSTAT_CONTEXT_ATTRIBUTE_NAME, context );
        
        String className = "";
        String methodName = "";
        
        try
        {
            HandlerMethod handlerMethod = ( HandlerMethod ) handler;
            className = handlerMethod.getMethod().getDeclaringClass().getSimpleName();
            methodName = handlerMethod.getMethod().getName();
        }
        catch( Exception e )
        {
            className = request.getRequestURI();
        }
        
        RequestStatistic requestStatistic = context.getRequestStatistic();
        
        if( requestStatistic != null )
        {
            logDebug( request.getServletPath(),
                      "Session id {} - class {} - method {}",
                      request.getSession().getId(),
                      className,
                      methodName );
            requestStatistic.setApplicationName( properties.getApplicationName() );
            requestStatistic.setClassName( className );
            requestStatistic.setScreenName( methodName );
        }
        else
        {
            logDebug( request.getServletPath(),
                      "RequestStatistic is null in preHandle" );
        }
        
        return true;
    }
    
    @Override
    public void postHandle( HttpServletRequest request,
                            HttpServletResponse response,
                            Object handler,
                            ModelAndView modelAndView ) throws Exception
    {
        WebStatisticContextImpl context = ( WebStatisticContextImpl ) request.getAttribute( WEBSTAT_CONTEXT_ATTRIBUTE_NAME );
        
        if( context != null )
        {
            Associate associate = getSessionAssociate( request );
            
            if( associate.hasRole() )
            {
                addAssociateDetailsToStatistic( request.getServletPath(),
                                                associate,
                                                context );
            }
            else
            {
                logDebug( request.getServletPath(),
                          "Associate does not have necessary Role for this application. Associate: {}",
                          associate.toString() );
            }
            context.setId( request.getSession().getId() );
            context.writeStatistics();
        }
        else
        {
            logDebug( request.getServletPath(),
                      "RequestStatistic context is null in postHandle" );
        }
        
        WebStatisticContextImpl.removeInstance();
    }
    
    /**
     * Adds the associate information to the request statistic.
     * @param servletPath
     * @param associate
     * @param context 
     */
    private void addAssociateDetailsToStatistic( String servletPath,
                                                 Associate associate,
                                                 WebStatisticContextImpl context )
    {
        RequestStatistic requestStatistic = context.getRequestStatistic();
        
        if( requestStatistic != null )
        {
            // NOTE Application Defined Field 1,2, & 3 are defined as CHARACTER(35) on DB5
            requestStatistic.setAppDefinedField1( String.format( "user=%s",
                                                                 associate.getId() ) );
            requestStatistic.setAppDefinedField2( String.format( "role=%s",
                                                                 associate.getRole() ) );
            
            logDebug( servletPath,
                      "Set requestStatistic : dstId={}, role={}",
                      StringUtils.defaultIfEmpty( associate.getId(), "" ),
                      StringUtils.defaultIfEmpty( associate.getRole().toString(),
                                                  "" ) );
            
            requestStatistic.setRequestEndTime( System.currentTimeMillis() );
        }
        else
        {
            logDebug( servletPath,
                      "RequestStatistic is null while assigning Associate" );
        }
    }
    
    /**
     * Retrieves the Associate from session.
     * @return
     */
    private Associate getSessionAssociate( HttpServletRequest request )
    {
        Associate associate = new Associate();
        String loginUserName = request.getAttribute( LOGIN_USER_NAME ) != null ? request.getAttribute( LOGIN_USER_NAME ).toString()
                                                                               : "unknown";
        associate.setId( loginUserName );
        ArrayList<String> roles = new ArrayList<String>();
        roles.add( "unknown" );
        associate.setRole( roles );
        
        if( sessionService != null )
        {
            AdminSessionAttributes attributes = sessionService.getAttributes();
            
            if( attributes != null && attributes.getAssociate() != null )
            {
                associate = attributes.getAssociate();
            }
            else
            {
                logDebug( request.getServletPath(),
                          "AdminSessionAttributes is null or does not have an Associate available" );
            }
        }
        else
        {
            logDebug( request.getServletPath(),
                      "AdminSessionService is null, session access is not possible" );
        }
        
        
        return associate;
    }
    
    /**
     * Helper method to log debug messages for this class.
     * @param servletPath 
     * @param msg
     * @param arguments
     */
    private void logDebug( String servletPath, String msg, Object... arguments )
    {
        if( ArrayUtils.isNotEmpty( arguments ) )
        {
            log.debug( msg + " when requesting: " + servletPath, arguments );
        }
        else
        {
            log.debug( msg + " when requesting: " + servletPath );
        }
    }
    
}
