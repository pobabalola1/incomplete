package com.dstsystems.ivradmin.callflowfunction.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowBusinessFunction;

public class CallFlowBusinessFunctionRowMapper implements
                                               RowMapper<CallFlowBusinessFunction>
{
    
    private final String CALL_FLOW_ID                 = "CALL_FLOW_ID";
    private final String FUNCTION_ID                  = "FUNCTION_ID";
    private final String FUNCTION_NM                  = "FUNCTION_NM";
    private final String TRANSFER_NUMBER_NM           = "TRANSFER_NUMBER_NM";
    private final String LAST_MAINTENANCE_OPERATOR_ID = "LAST_MAINTENANCE_ID";
    private final String TRANSFER_INDICATOR           = "TRANSFER_INDICATOR";
    
    @Override
    public CallFlowBusinessFunction mapRow( ResultSet rs,
                                            int rowNum ) throws SQLException
    {
        CallFlowBusinessFunction callFlowBusinessFunction = new CallFlowBusinessFunction();
        callFlowBusinessFunction.setCallFlowId( rs.getInt( CALL_FLOW_ID ) );
        callFlowBusinessFunction.setFunctionId( rs.getInt( FUNCTION_ID ) );
        callFlowBusinessFunction.setFunctionName( ( rs.getString( FUNCTION_NM ) ) );
        callFlowBusinessFunction.setLastMaintenanceOperatorId( rs.getString( LAST_MAINTENANCE_OPERATOR_ID ) );
        callFlowBusinessFunction.setFunctionTransferAllowed( rs.getString( TRANSFER_INDICATOR )
                                                               .equals( "1" ) );
        callFlowBusinessFunction.setTransferNumberNm( rs.getString( TRANSFER_NUMBER_NM ) );
        
        return callFlowBusinessFunction;
    }
    
}
