package com.dstsystems.ivradmin.callflowfunction.domain;

public class CallFlowBusinessFunction
{
    private Integer callFlowId;
    private Integer functionId;
    private String  functionName;
    private String  transferNumberNm;
    //private String lastMaintenanceDateTime; 
    private String  lastMaintenanceOperatorId;
    private boolean functionTransferAllowed;
    
    /**
     * @return the dnisId
     */
    public Integer getCallFlowId()
    {
        return callFlowId;
    }
    
    /**
     * @param dnisId the dnisId to set
     */
    public void setCallFlowId( Integer callFlowId )
    {
        this.callFlowId = callFlowId;
    }
    
    /**
     * @return the functionId
     */
    public Integer getFunctionId()
    {
        return functionId;
    }
    
    /**
     * @param functionId the functionId to set
     */
    public void setFunctionId( Integer functionId )
    {
        this.functionId = functionId;
    }
    
    /**
     * @return the functionName
     */
    public String getFunctionName()
    {
        return functionName;
    }
    
    /**
     * @param functionName the functionName to set
     */
    public void setFunctionName( String functionName )
    {
        this.functionName = functionName;
    }
    
    /**
     * @return the transferNumberNm
     */
    public String getTransferNumberNm()
    {
        return transferNumberNm;
    }
    
    /**
     * @param transferNumberNm the transferNumberNm to set
     */
    public void setTransferNumberNm( String transferNumberNm )
    {
        this.transferNumberNm = transferNumberNm;
    }
    
    /**
     * @return the lastMaintenanceOperatorId
     */
    public String getLastMaintenanceOperatorId()
    {
        return lastMaintenanceOperatorId;
    }
    
    /**
     * @param lastMaintenanceOperatorId the lastMaintenanceOperatorId to set
     */
    public void setLastMaintenanceOperatorId( String lastMaintenanceOperatorId )
    {
        this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
    }
    
    /**
     * @return the functionTransferAllowed
     */
    public boolean isFunctionTransferAllowed()
    {
        return functionTransferAllowed;
    }
    
    /**
     * @param functionTransferAllowed the functionTransferAllowed to set
     */
    public void setFunctionTransferAllowed( boolean functionTransferAllowed )
    {
        this.functionTransferAllowed = functionTransferAllowed;
    }
    
    
}
