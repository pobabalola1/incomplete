package com.dstsystems.ivradmin.core.domain;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CodeSetValue {
	private Integer codeSetValueId;
	private Integer codeSetId;
	private String  name;
	private String  abbreviatedName;
	private String  descriptionText; 
	private Date    effectiveDate;
	private Date    expirationDate;
}
