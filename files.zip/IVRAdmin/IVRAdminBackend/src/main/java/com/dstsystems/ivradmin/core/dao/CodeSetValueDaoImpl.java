package com.dstsystems.ivradmin.core.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.domain.CodeSetValue;
import com.dstsystems.ivradmin.core.domain.CodeSetValueDisplay;
import com.dstsystems.ivradmin.core.domain.mapper.CodeSetValueDisplayRowMapper;
import com.dstsystems.ivradmin.core.domain.mapper.CodeSetValueRowMapper;

@Repository
public class CodeSetValueDaoImpl extends BaseJdbcDAO {
	
    private static final String    CODE_SET_NM          = "CODE_SET_NM";
    private static final String    CODE_SET_VALUE_ID    = "CODE_SET_VALUE_ID";
    private static final String    CODE_SET_VALUE_IDS   = "CODE_SET_VALUE_IDS";
		
	private static final StringBuilder GET_ALL = new StringBuilder()
          .append(" select     CSV.CODE_SET_VALUE_ID, CSV.LAST_MAINTENANCE_TIMESTAMP, CSV.LAST_MAINTENANCE_ID, CSV.RECORD_ADD_TIMESTAMP, ")
          .append("            CSV.RECORD_ADD_ID, CSV.CODE_SET_ID, CSV.NAME,  CSV.ABBREVIATED_NAME, CSV.DESCRIPTION_TEXT, ")
          .append("            CSV.EFFECTIVE_DATE, CSV.EXPIRATION_DATE ")
          .append(" from       CODE_SET_VALUE  CSV ");
	
	private static final StringBuilder GET_BY_CODE_SET_NAME = new StringBuilder()
	      .append("  select   CSV.CODE_SET_VALUE_ID, ")
	      .append("           CSV.CODE_SET_VALUE_NM, ")
	      .append("           CSV.CODE_SET_VALUE_ABBREVIATED_NM ")
	      .append("   from    CODE_SET CS, ")
	      .append("           CODE_SET_VALUE CSV ")
	      .append("   where   ")
	      .append("           CS.CODE_SET_ID = CSV.CODE_SET_ID        and ")
	      .append("           CS.CODE_SET_NM = :CODE_SET_NM           and ")
	      .append("           CS.EFFECTIVE_DT <= CURRENT_DATE         and ")
	      .append("           ( ")
	      .append("               CS.EXPIRATION_DT IS NULL            or ")
	      .append("               CURRENT_DATE <= CS.EXPIRATION_DT ")
	      .append("           )                                       and ")
	      .append("           CSV.EFFECTIVE_DT <= CURRENT_DATE        and ")
	      .append("           (  ")
	      .append("               CSV.EXPIRATION_DT IS NULL           or  ")
	      .append("               CURRENT_DATE <= CSV.EXPIRATION_DT ")
	      .append("           ) ");
	
	private static final StringBuilder GET_BY_VALUE_ID = new StringBuilder()
          .append("    SELECT  CSV.CODE_SET_VALUE_NM,  ")
          .append("           CSV.CODE_SET_VALUE_ID,  ")
          .append("           CSV.CODE_SET_VALUE_ABBREVIATED_NM,  ")
          .append("           CSV.DESCRIPTION_TXT,  ")
          .append("           CSV.EXPIRATION_DT AS CSV_EXPIRATION_DT, ")
          .append("           CS.EXPIRATION_DT AS CS_EXPIRATION_DT    ")
          .append("   FROM    CODE_SET_VALUE  CSV     ")
          .append("           LEFT JOIN CODE_SET CS ON CS.CODE_SET_ID = CSV.CODE_SET_ID   ")
          .append("   WHERE   CSV.CODE_SET_VALUE_ID = :CODE_SET_VALUE_ID  ");
	
	private static final StringBuilder GET_BY_VALUE_IDS = new StringBuilder()
	      .append("    SELECT  CSV.CODE_SET_VALUE_NM,  ")
	      .append("           CSV.CODE_SET_VALUE_ID,  ")
	      .append("           CSV.CODE_SET_VALUE_ABBREVIATED_NM,  ")
	      .append("           CSV.DESCRIPTION_TXT,  ")
	      .append("           CSV.EXPIRATION_DT AS CSV_EXPIRATION_DT, ")
	      .append("           CS.EXPIRATION_DT AS CS_EXPIRATION_DT    ")
	      .append("   FROM    CODE_SET_VALUE  CSV     ")
	      .append("           LEFT JOIN CODE_SET CS ON CS.CODE_SET_ID = CSV.CODE_SET_ID   ")
	      .append("   WHERE   CSV.CODE_SET_VALUE_ID IN (:CODE_SET_VALUE_IDS)  ");
	
	private final static Logger    LOG = LoggerFactory.getLogger( CodeSetValueDaoImpl.class );
	
	public List< CodeSetValue > getAll()
    {
    	List< CodeSetValue > codeSetValue = null; 
    	try 
    	{
    		codeSetValue = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new CodeSetValueRowMapper() );
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return codeSetValue;
    }
	
	public List< CodeSetValue > getByCodeSetName( String codeSetName )
	{
	   List< CodeSetValue > codeSetValue = null;
	   try
	   {
	      SqlParameterSource parameters = new MapSqlParameterSource().addValue( CODE_SET_NM,
                                                                                codeSetName );     
	      
	      codeSetValue = getNamedParameterJdbcOperations().query( GET_BY_CODE_SET_NAME.toString(), parameters, new CodeSetValueRowMapper() ); 
	   } 
	   catch( Exception e ) 
	   {
	      
	      LOG.error( e.getMessage() );
	   }
	   
	   return codeSetValue;
	}

	public CodeSetValueDisplay getByCodeSetValueId( Integer codeValueSetId )
    {
       CodeSetValueDisplay codeSetValueDisplay = null;
       try
       {
          SqlParameterSource parameters = new MapSqlParameterSource().addValue( CODE_SET_VALUE_ID,
                                                                                codeValueSetId );     
          
          codeSetValueDisplay = getNamedParameterJdbcOperations().queryForObject( GET_BY_VALUE_ID.toString(), parameters, new CodeSetValueDisplayRowMapper() ); 
       } 
       catch( Exception e ) 
       {
          
          LOG.error( e.getMessage() );
       }
       
       return codeSetValueDisplay;
    }
	
	public List< CodeSetValueDisplay > getByCodeSetValueIds( Set< Integer > codeValueSetIds )
    {
       List< CodeSetValueDisplay > codeSetValueDisplayList = null;
       try
       {
          SqlParameterSource parameters = new MapSqlParameterSource().addValue( CODE_SET_VALUE_IDS,
                                                                                codeValueSetIds );     
          
          codeSetValueDisplayList = getNamedParameterJdbcOperations().query( GET_BY_VALUE_IDS.toString(), parameters, new CodeSetValueDisplayRowMapper() ); 
       } 
       catch( Exception e ) 
       {
          
          LOG.error( e.getMessage() );
       }
       
       return codeSetValueDisplayList;
    }

	public Map< Integer, CodeSetValueDisplay > getByCodeSetValueIdsAsMap(  Set< Integer > codeValueSetIds )
	{
	   List< CodeSetValueDisplay > codeSetValueDisplayList = null; 
	   Map< Integer, CodeSetValueDisplay > codeSetValueDisplayMap = null;
	   
	   codeSetValueDisplayList = getByCodeSetValueIds( codeValueSetIds );
	   codeSetValueDisplayMap = codeSetValueDisplayList.stream().collect( Collectors.toMap( CodeSetValueDisplay::getId , i -> i ) ); 
	   
	   return codeSetValueDisplayMap;
	}
}
