package com.dstsystems.ivradmin.transferNumber.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.transferNumber.bean.CallTransferNumber;
import com.dstsystems.ivradmin.transferNumber.dao.CallTransferNumberDaoImpl;

/**
 * To get data to show for Transfer Number landing card.
 * 
 * @author DT77649
 */
@RestController
public class CallTransferNumberController {
	
	@Autowired
	private CallTransferNumberDaoImpl callTransferNumberDaoImpl;
	
	/**
     * getting transfer data.
     *  
     * @param callFlowId - to tell what is callFlow that user is using.
     * @return CallTransferNumber list
     */
	@RequestMapping(path = "/api/data/asset-management-dnises-call-transfer-number/{callFlowId}" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public List< CallTransferNumber > getByDnis( @PathVariable int callFlowId )
    {
		return callTransferNumberDaoImpl.getByCallFlowIdDistinct( callFlowId );
    }
}
