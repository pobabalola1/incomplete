package com.dstsystems.ivradmin.web.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "server")
public class ServerProperties
{
    
    private int     port;
    private int     ajpPort;
    private int     ajpPacketSize;
    private String  ajpAddress;
    private boolean ajpEnabled = false;
    
    @NestedConfigurationProperty
    private Tomcat  tomcat     = new Tomcat();
    
    public int getPort()
    {
        return port;
    }
    
    public void setPort( int port )
    {
        this.port = port;
    }
    
    public int getAjpPort()
    {
        return ajpPort;
    }
    
    public void setAjpPort( int ajpPort )
    {
        this.ajpPort = ajpPort;
    }
    
    public int getAjpPacketSize()
    {
        return ajpPacketSize;
    }
    
    public void setAjpPacketSize( int ajpPacketSize )
    {
        this.ajpPacketSize = ajpPacketSize;
    }
    
    public boolean isAjpEnabled()
    {
        return ajpEnabled;
    }
    
    public void setAjpEnabled( boolean ajpEnabled )
    {
        this.ajpEnabled = ajpEnabled;
    }
    
    public String getAjpAddress()
    {
        return ajpAddress;
    }
    
    public void setAjpAddress( String ajpAddress )
    {
        this.ajpAddress = ajpAddress;
    }
    
    public Tomcat getTomcat()
    {
        return tomcat;
    }
}

