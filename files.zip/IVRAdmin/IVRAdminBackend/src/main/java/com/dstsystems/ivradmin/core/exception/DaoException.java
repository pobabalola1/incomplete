/*
 * FILE : DaoException.java
 *
 * CLASS : DaoException
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.exception;

/**
 * An exception that can be thrown to the service or controller layer with messaging from the persistence tier.
 * 
 * @author dt63314
 *
 */
public class DaoException extends Exception
{
    private static final long serialVersionUID = 1L;
    
    /* (non-Javadoc)
     * @see java.lang.Exception#Exception()
     */
    public DaoException()
    {
        super();
    }
    
    /* (non-Javadoc)
     * @see java.lang.Exception#Exception(String, Throwable, boolean, boolean)
     */
    public DaoException( String message,
                         Throwable cause,
                         boolean enableSuppression,
                         boolean writableStackTrace )
    {
        super( message, cause, enableSuppression, writableStackTrace );
    }
    
    /* (non-Javadoc)
     * @see java.lang.Exception#Exception(String, Throwable)
     */
    public DaoException( String message, Throwable cause )
    {
        super( message, cause );
    }
    
    /* (non-Javadoc)
     * @see java.lang.Exception#Exception(String)
     */
    public DaoException( String message )
    {
        super( message );
    }
    
    /* (non-Javadoc)
     * @see java.lang.Exception#Exception(Throwable)
     */
    public DaoException( Throwable cause )
    {
        super( cause );
    }
    
}
