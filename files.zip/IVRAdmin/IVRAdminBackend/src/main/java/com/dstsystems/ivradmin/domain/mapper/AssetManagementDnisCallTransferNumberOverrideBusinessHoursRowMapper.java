package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.domain.AssetManagementDnisCallTransferNumberOverrideBusinessHours;

public class AssetManagementDnisCallTransferNumberOverrideBusinessHoursRowMapper   implements RowMapper<AssetManagementDnisCallTransferNumberOverrideBusinessHours> {

	private final String DNIS_Id = "DNIS_Id";
	private final String Asset_Management_DNIS_Call_Transfer_Number_Id = "Asset_Management_DNIS_Call_Transfer_Number_Id";
	private final String Day_of_the_Week_Id = "Day_of_the_Week_Id";
	private final String Last_Maintenance_Timestamp = "Last_Maintenance_Timestamp";
	private final String Last_Maintenance_Id = "Last_Maintenance_Id";	
	private final String Open_Time = "Open_Time";
	private final String Closed_Time = "Closed_Time";
	
	@Override
	public AssetManagementDnisCallTransferNumberOverrideBusinessHours mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		AssetManagementDnisCallTransferNumberOverrideBusinessHours assetManagementDnisCallTransferNumberOverrideBusinessHours = new AssetManagementDnisCallTransferNumberOverrideBusinessHours();
		assetManagementDnisCallTransferNumberOverrideBusinessHours.setDnisId( rs.getInt( DNIS_Id ) );
		assetManagementDnisCallTransferNumberOverrideBusinessHours.setAssetManagementDNISCallTransferNumberId( rs.getInt( Asset_Management_DNIS_Call_Transfer_Number_Id ) );
		assetManagementDnisCallTransferNumberOverrideBusinessHours.setDayOfTheWeekId( rs.getInt( Day_of_the_Week_Id ) );
		assetManagementDnisCallTransferNumberOverrideBusinessHours.setLastMaintenanceTimestamp( rs.getDate( Last_Maintenance_Timestamp ) );
		assetManagementDnisCallTransferNumberOverrideBusinessHours.setLastMaintenanceId( rs.getString( Last_Maintenance_Id ) );
		assetManagementDnisCallTransferNumberOverrideBusinessHours.setOpenTime( rs.getDate( Open_Time ) );
		assetManagementDnisCallTransferNumberOverrideBusinessHours.setClosedTime( rs.getDate( Closed_Time ) );
		return assetManagementDnisCallTransferNumberOverrideBusinessHours;
	}
}
