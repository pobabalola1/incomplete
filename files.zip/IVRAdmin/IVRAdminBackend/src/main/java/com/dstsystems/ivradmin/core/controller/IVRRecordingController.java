package com.dstsystems.ivradmin.core.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.core.dao.IVRRecordingDaoImpl;
import com.dstsystems.ivradmin.core.domain.IVRRecording;

@RestController
public class IVRRecordingController
{
   @Autowired
   private IVRRecordingDaoImpl ivrRecordingDaoImpl;
    
   @RequestMapping(path = "/api/data/ivr-recordings", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
   @ResponseBody
   public List< IVRRecording > getAllIVRRecording()
   {
      List< IVRRecording > allIVRRecordings = null;
      allIVRRecordings = ivrRecordingDaoImpl.getAll();
      
      return allIVRRecordings;
     
   }
}
