package com.dstsystems.ivradmin.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.dstsystems.ivradmin.core.domain.CallFlow;

public class LineOfBusinessClient
{
   
   private Integer ivrClientId;
   private Integer lineOfBusinessId;
   private Integer fundSponsorId;
   private String ivrClientName;
   private String systemId;
   private List< CallFlow > callFlow = new ArrayList< CallFlow >();
   
   /**
    * @return the ivrClientId
    */
   public Integer getIvrClientId()
   {
      return ivrClientId;
   }

   /**
    * @param ivrClientId the ivrClientId to set
    */
   public void setIvrClientId( Integer ivrClientId )
   {
      this.ivrClientId = ivrClientId;
   }

   /**
    * @return the lineOfBusinessId
    */
   public Integer getLineOfBusinessId()
   {
      return lineOfBusinessId;
   }

   /**
    * @param lineOfBusinessId the lineOfBusinessId to set
    */
   public void setLineOfBusinessId( Integer lineOfBusinessId )
   {
      this.lineOfBusinessId = lineOfBusinessId;
   }

   /**
    * @return the fundSponsorId
    */
   public Integer getFundSponsorId()
   {
      return fundSponsorId;
   }

   /**
    * @param fundSponsorId the fundSponsorId to set
    */
   public void setFundSponsorId( Integer fundSponsorId )
   {
      this.fundSponsorId = fundSponsorId;
   }

   /**
    * @return the ivrClientNm
    */
   public String getIvrClientName()
   {
      return ivrClientName;
   }

   /**
    * @param ivrClientNm the ivrClientNm to set
    */
   public void setIvrClientName( String ivrClientNm )
   {
      this.ivrClientName = ivrClientNm;
   }

   /**
    * @return the systemId
    */
   public String getSystemId()
   {
      return systemId;
   }

   /**
    * @param systemId the systemId to set
    */
   public void setSystemId( String systemId )
   {
      this.systemId = systemId;
   }

   /**
    * @return the callFlow
    */
   public List<CallFlow> getCallFlow()
   {
      return callFlow;
   }

   /**
    * @param dnis the callFlow to set
    */
   public void setCallFlow( List<CallFlow> callFlow )
   {
      this.callFlow = callFlow;
   }

}
