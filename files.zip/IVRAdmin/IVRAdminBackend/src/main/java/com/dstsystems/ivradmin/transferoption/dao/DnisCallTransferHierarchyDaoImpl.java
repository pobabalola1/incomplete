package com.dstsystems.ivradmin.transferoption.dao;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.core.dao.CodeSetValueDaoImpl;
import com.dstsystems.ivradmin.core.domain.CodeSetValueDisplay;
import com.dstsystems.ivradmin.transferoption.domain.TransferHierarchy;
import com.dstsystems.ivradmin.transferoption.domain.mapper.DnisCallTransferHierarchyRowMapper;

@Repository
public class DnisCallTransferHierarchyDaoImpl extends BaseJdbcDAO 
{
    @Autowired
    private CodeSetValueDaoImpl codeSetValueDao;

	private static final String CALL_FLOW_ID = "CALL_FLOW_ID"; 

	private static final StringBuilder GET_ALL = new StringBuilder()
	      .append("select      TH.CALL_FLOW_ID, ")
	      .append("            TH.TRANSFER_TYPE_HIERARCHY_CVID, ")
	      .append("            TH.SEQUENCE_NBR ")
	      .append("from        CALL_FLOW_TRANSFER_HIERARCHY TH");

	private static final StringBuilder GET_BY_CALL_FLOW_ID = new StringBuilder()
	      .append( GET_ALL.toString() ).append( " " )
	      .append( "where      TH.CALL_FLOW_ID = :CALL_FLOW_ID " )
	      .append( "order by   TH.SEQUENCE_NBR");
	 
	private final static Logger    LOG = LoggerFactory.getLogger( DnisCallTransferHierarchyDaoImpl.class );
	
    public List< TransferHierarchy > getAll()
    {
    	List< TransferHierarchy > dnisCallTransferHierarchyList = null; 
    	try 
    	{
    	   dnisCallTransferHierarchyList = getNamedParameterJdbcOperations().query( GET_ALL.toString(), 
    	                                                                            new DnisCallTransferHierarchyRowMapper() );
    	   
    	   fillCodeSetValueDisplay( dnisCallTransferHierarchyList );
    	   
    	}
        catch( Exception e )
        {
        	LOG.error( e.getMessage() );
        }
    	return dnisCallTransferHierarchyList;
    }

   public List< TransferHierarchy > getByCallFlowId( Integer callFlowId )
   {
      SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                            callFlowId );
      List< TransferHierarchy > dnisCallTransferHierarchyList = null;
      
      try 
      {
         
         dnisCallTransferHierarchyList = getNamedParameterJdbcOperations().query( GET_BY_CALL_FLOW_ID.toString(), 
                                                                                  parameters,
                                                                                  new DnisCallTransferHierarchyRowMapper() );
         
         if( !dnisCallTransferHierarchyList.isEmpty() ) 
         {
            fillCodeSetValueDisplay( dnisCallTransferHierarchyList );
         }
         
      }
      catch( Exception e )
      {
         e.printStackTrace(); 
         LOG.error( e.getMessage() );
      }
      
      return dnisCallTransferHierarchyList;
   } 
    
   private void fillCodeSetValueDisplay( List< TransferHierarchy > transferHierarchyList )
   {
      // Get all hierachy cvids as set for retrieval.  
      Set< Integer > hierarchyIds = transferHierarchyList
                                    .stream()
                                    .map( e -> e.getHierarchyCvid() )
                                    .collect( Collectors.toSet() );
      if ( !hierarchyIds.isEmpty() ) 
      {
         List< CodeSetValueDisplay > csvdList = codeSetValueDao.getByCodeSetValueIds( hierarchyIds );
         
         List< CodeSetValueDisplay > tempCSVDList = null;
         
         // Allocate cvid to the hierarchy.
         for ( TransferHierarchy transferHierarchy :  transferHierarchyList ) 
         {
            tempCSVDList = csvdList.stream().filter( e -> e.getId().equals( transferHierarchy.getHierarchyCvid() ) ).collect( Collectors.toList() );
              
            transferHierarchy.setTransferTypeHierarchy( tempCSVDList.size() > 0 ? tempCSVDList.get( 0 ) : null );
         }
      }
   }	
    
    
	
}
