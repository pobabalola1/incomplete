package com.dstsystems.ivradmin.core.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.core.domain.CodeSetValue;

public class CodeSetValueRowMapper implements RowMapper<CodeSetValue> {

    private final String CODE_SET_VALUE_ID = "CODE_SET_VALUE_ID";
    private final String CODE_SET_VALUE_NM = "CODE_SET_VALUE_NM";
    private final String CODE_SET_VALUE_ABBREVIATED_NM = "CODE_SET_VALUE_ABBREVIATED_NM";
	
    //As for display.
    private final String CSV_EXPIRATION_DT  = "CSV_EXPIRATION_DT";
    private final String CS_EXPIRATION_DT   = "CS_EXPIRATION_DT";
    
    
	
	/*private final String Last_Maintenance_Timestamp = "Last_Maintenance_Timestamp";
	private final String Last_Maintenance_Id = "Last_Maintenance_Id";
	private final String Record_Add_Timestamp = "Record_Add_Timestamp";
	private final String Record_Add_Id = "Record_Add_Id";
	private final String Code_Set_Id = "Code_Set_Id";
	private final String Name = "Name";
	private final String Abbreviated_Name = "Abbreviated_Name"; 
	private final String Description_Text = "Description_Text";
	private final String Effective_Date = "Effective_Date";
	private final String Expiration_Date = "Epiration_Date";
	*/
    
	@Override
	public CodeSetValue mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		//CodeSetValue codeSetValue = new CodeSetValue();
		//codeSetValue.setCodeSetValueId( rs.getInt( CODE_SET_VALUE_ID ) );
		//codeSetValue.setLastMaintenanceTimestamp( rs.getDate( Last_Maintenance_Timestamp ) );
		//codeSetValue.setLastMaintenanceId( rs.getString( Last_Maintenance_Id ) );
		//codeSetValue.setRecordAddTimestamp( rs.getDate( Record_Add_Timestamp ) );
		//codeSetValue.setRecordAddId( rs.getString( Record_Add_Id ) );
		//codeSetValue.setCodeSetId( rs.getInt( Code_Set_Id ) );
		//codeSetValue.setName( rs.getString( Name ) );
		//codeSetValue.setName( rs.getString( CODE_SET_VALUE_NM ) );
		//codeSetValue.setAbbreviatedName( rs.getString( CODE_SET_VALUE_ABBREVIATED_NM ) );
		//codeSetValue.setDescriptionText( rs.getString( Description_Text ) );
		//codeSetValue.setEffectiveDate( rs.getDate( Effective_Date ) );
		//codeSetValue.setExpirationDate( rs.getDate( Expiration_Date ) );
		return null; //codeSetValue;
	}
	
	
	
	
}
