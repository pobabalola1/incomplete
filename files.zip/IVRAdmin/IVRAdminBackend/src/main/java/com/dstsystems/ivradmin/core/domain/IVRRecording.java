/**
 * 
 */
package com.dstsystems.ivradmin.core.domain;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonValue;

import lombok.Builder;
import lombok.Data;

/**
 * @author dt86783
 *
 */
@Data
@Builder
public class IVRRecording
{  
   public enum Gender { 
      MALE ("M"), FEMALE ("F");
      
      private static Map< String, Gender > genderMapping = new HashMap< String, Gender >();
      
      static {
         genderMapping.put( "M", MALE );
         genderMapping.put( "F", FEMALE );
      }
       
      private final String genderCd;
      
      Gender( String genderCd )
      {
         this.genderCd = genderCd;
      }
      
      @JsonValue
      public String getCode() 
      {
         return this.genderCd;
      }
      
      public static Gender toGenderFromCode( String genderCd ) 
      {
         return genderMapping.get( genderCd );
      } 
   };
   
   private Integer ivrRecordingId;
   private String engScriptText;
   private String altScriptText;
   
   private Gender gender;
   
   private Integer recordingTypeCvid;
   private CodeSetValueDisplay recordingType;
   
   private Integer statusCvid;
   private CodeSetValueDisplay status;
   
   private Integer ivrLangCvid;
   private CodeSetValueDisplay ivrLanguage;
   
   private String notesText;
   
}
