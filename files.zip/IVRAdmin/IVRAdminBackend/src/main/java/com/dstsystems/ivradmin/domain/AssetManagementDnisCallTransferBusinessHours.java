package com.dstsystems.ivradmin.domain;

import java.util.Date;

public class AssetManagementDnisCallTransferBusinessHours {

	private Integer dnisId;
	private Integer dayOfTheWeekId;
	private Date lastMaintenanceTimestamp; 
	private String lastMaintenanceId; 
	private Date openTime;
	private Date closedTime;

	/**
	 * @return the dnisId
	 */
	public Integer getdNISId() {
		return dnisId;
	}

	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setdNISId(Integer dNISId) {
		this.dnisId = dNISId;
	}

	/**
	 * @return the dayOfTheWeekId
	 */
	public Integer getDayOfTheWeekId() {
		return dayOfTheWeekId;
	}

	/**
	 * @param dayOfTheWeekId
	 *            the dayOfTheWeekId to set
	 */
	public void setDayOfTheWeekId(Integer dayOfTheWeekId) {
		this.dayOfTheWeekId = dayOfTheWeekId;
	}

	/**
	 * @return the lastMaintenanceTimestamp
	 */
	public Date getLastMaintenanceTimestamp() {
		return lastMaintenanceTimestamp;
	}

	/**
	 * @param lastMaintenanceTimestamp
	 *            the lastMaintenanceTimestamp to set
	 */
	public void setLastMaintenanceTimestamp(Date lastMaintenanceTimestamp) {
		this.lastMaintenanceTimestamp = lastMaintenanceTimestamp;
	}

	/**
	 * @return the lastMaintenanceId
	 */
	public String getLastMaintenanceId() {
		return lastMaintenanceId;
	}

	/**
	 * @param lastMaintenanceId
	 *            the lastMaintenanceId to set
	 */
	public void setLastMaintenanceId(String lastMaintenanceId) {
		this.lastMaintenanceId = lastMaintenanceId;
	}

	/**
	 * @return the openTime
	 */
	public Date getOpenTime() {
		return openTime;
	}

	/**
	 * @param openTime
	 *            the openTime to set
	 */
	public void setOpenTime(Date openTime) {
		this.openTime = openTime;
	}

	/**
	 * @return the closedTime
	 */
	public Date getClosedTime() {
		return closedTime;
	}

	/**
	 * @param closedTime
	 *            the closedTime to set
	 */
	public void setClosedTime(Date closedTime) {
		this.closedTime = closedTime;
	}

}
