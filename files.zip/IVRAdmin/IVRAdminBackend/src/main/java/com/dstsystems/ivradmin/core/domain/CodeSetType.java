package com.dstsystems.ivradmin.core.domain;

public enum CodeSetType 
{
   
   REC_TYPE ( "Rec Type" ), 
   IVR_LANG ("IVR Lang"),
   REC_STATUS ("REC STATUS"),
   XFR_HIER ("XFR HIER"),
   WEEKDAY ("Weekday"),
   USER_AUTH ("User Auth"),
   ACCT_GRP ("Acct Grp"),
   CAL_FLW_ST ("Cal Flw St");
   
   private final String abbreviateName;
   
   CodeSetType( String abbrName)
   {
      this.abbreviateName = abbrName;
   } 
   
   public String getAbbreviateName()
   {
      return this.abbreviateName;
   }
}
