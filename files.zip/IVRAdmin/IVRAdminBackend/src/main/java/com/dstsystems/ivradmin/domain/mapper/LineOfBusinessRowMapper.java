package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.domain.LineOfBusiness;

public class LineOfBusinessRowMapper implements RowMapper<LineOfBusiness>
{
   private final String LINE_OF_BUSINESS_ID = "LINE_OF_BUSINESS_ID";
   private final String LINE_OF_BUSINESS_NM = "LINE_OF_BUSINESS_NM";
   
   @Override
   public LineOfBusiness mapRow( ResultSet rs, int rowNum ) throws SQLException
   {
      LineOfBusiness lineOfBusiness = new LineOfBusiness();
      lineOfBusiness.setLineOfBusinessId( rs.getInt( LINE_OF_BUSINESS_ID ) );
      lineOfBusiness.setLineOfBusinessName( rs.getString( LINE_OF_BUSINESS_NM ) );
      return lineOfBusiness;
   }
   
   
}
