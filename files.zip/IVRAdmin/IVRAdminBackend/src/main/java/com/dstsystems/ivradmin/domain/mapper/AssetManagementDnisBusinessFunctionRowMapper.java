package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.domain.AssetManagementDnisBusinessFunction;

public class AssetManagementDnisBusinessFunctionRowMapper implements RowMapper<AssetManagementDnisBusinessFunction> {
	
	private final String DNIS_Id = "DNIS_Id";
	private final String Business_Function_Id = "Business_Function_Id";
	private final String Last_Maintenance_Timestamp = "Last_Maintenance_Timestamp";
	private final String Last_Maintenance_Id = "Last_Maintenance_Id";	
	private final String Asset_Management_DNIS_Call_Transfer_Number_Id = "Asset_Management_DNIS_Call_Transfer_Number_Id";

	@Override
	public AssetManagementDnisBusinessFunction mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		AssetManagementDnisBusinessFunction assetManagementDnisBusinessFunction = new AssetManagementDnisBusinessFunction();
		assetManagementDnisBusinessFunction.setDnisId( rs.getInt( DNIS_Id ) );
		assetManagementDnisBusinessFunction.setBusinessFunctionIdprivate( rs.getInt( Business_Function_Id ) );
		assetManagementDnisBusinessFunction.setLastMaintenanceTimestamp( rs.getDate( Last_Maintenance_Timestamp ) );
		assetManagementDnisBusinessFunction.setLastMaintenanceId( rs.getString( Last_Maintenance_Id ) );
		assetManagementDnisBusinessFunction.setAssetManagementDNISTransferNumberId( rs.getInt( Asset_Management_DNIS_Call_Transfer_Number_Id ) );
		return assetManagementDnisBusinessFunction;
	}
}
