package com.dstsystems.ivradmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.core.controller.BaseController;
import com.dstsystems.ivradmin.fund.dao.IvrMutualFundDaoImpl;
import com.dstsystems.ivradmin.fund.domain.IvrMutualFund;
import com.dstsystems.ivradmin.fund.domain.IvrMutualFundCategory;

@RestController
public class IvrMutualFundController extends BaseController{
	
   @Autowired
   private IvrMutualFundDaoImpl ivrMutualFundDaoImpl;
	
   @RequestMapping(path = "/ivr-mutual-funds" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
   @ResponseBody
   public List< IvrMutualFund > getAll() 
   {
      return ivrMutualFundDaoImpl.getAll();
   }
   
   @RequestMapping(path = "/fund-details/{callFlowId}" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
   @ResponseBody
   public List< IvrMutualFund > getFundDetails( @PathVariable int callFlowId ) 
   {
      return ivrMutualFundDaoImpl.getFundDetails(callFlowId);
   }
   
   @RequestMapping(path = "/fund-categories/{callFlowId}" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
   @ResponseBody
   public List< IvrMutualFundCategory > getFundCategories( @PathVariable int callFlowId ) 
   {
      return ivrMutualFundDaoImpl.getFundCategories(callFlowId);
   }
	
}
