package com.dstsystems.ivradmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.fund.dao.IvrMutualFundCategoryDaoImpl;
import com.dstsystems.ivradmin.fund.domain.IvrMutualFundCategory;

@RestController
public class IvrMutualFundCategoryController {

   @Autowired
   private IvrMutualFundCategoryDaoImpl ivrMutualFundCategoryDaoImpl;	
	
   @RequestMapping(path = "/api/data/ivr-mutual-fund-categories" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
   @ResponseBody
   public List< IvrMutualFundCategory > getAll() 
   {
      return ivrMutualFundCategoryDaoImpl.getAll();
   } 	

}
