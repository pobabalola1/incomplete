/*
 * FILE : HazelcastServerConfig.java
 *
 * CLASS : HazelcastServerConfig
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.hazelcast.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.hazelcast.HazelcastAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hazelcast.config.ClasspathXmlConfig;
import com.hazelcast.config.Config;

/**
 * This code is a copy of the same class in the ivr-core project.
 * @author dt63314
 *
 */
@Configuration
@AutoConfigureBefore({ HazelcastAutoConfiguration.class })
public class HazelcastServerConfig
{
    private HazelcastServerConfigProperties hazelcastConfig;
    
    @Autowired
    public HazelcastServerConfig( HazelcastServerConfigProperties hazelcastConfig )
    {
        this.hazelcastConfig = hazelcastConfig;
    }
    
    @Bean
    public Config hazelCastConfig()
    {
        Config config = new ClasspathXmlConfig( hazelcastConfig.getConfigClasspath() );
        config.setInstanceName( hazelcastConfig.getInstanceName() );
        config.setProperty( "hazelcast.jmx", hazelcastConfig.getJmx() );
        return config;
    }
    
}
