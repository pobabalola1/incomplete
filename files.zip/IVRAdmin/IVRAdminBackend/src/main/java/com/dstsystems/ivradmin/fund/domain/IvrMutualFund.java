package com.dstsystems.ivradmin.fund.domain;

import java.math.BigDecimal;

public class IvrMutualFund {
	
	private Integer callFlowId;
	private Integer ivrMutualFundId;
	private Integer ivrMutualFundCategoryId;
	private String ivrFundCatNm;	
	private Integer ivrFundCd;
	private String ivrFundNm;
	private boolean activityCd;
	private Integer transferNumId;
	private String transferNumNm;
	// private String lastMaintenanceDateTime;
	private String lastMaintenanceOperatorId;




	/**
	 * @return the dnisId
	 */
	public Integer getCallFlowId() {
		return callFlowId;
	}

	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setCallFlowId(Integer dnisId) {
		this.callFlowId = dnisId;
	}

	/**
	 * @return the ivrMutualFundId
	 */
	public Integer getIvrMutualFundId() {
		return ivrMutualFundId;
	}

	/**
	 * @param ivrMutualFundId
	 *            the ivrMutualFundId to set
	 */
	public void setIvrMutualFundId(Integer ivrMutualFundId) {
		this.ivrMutualFundId = ivrMutualFundId;
	}

	/**
	 * @return the lastMaintenanceOperatorId
	 */
	public String getLastMaintenanceOperatorId() {
		return lastMaintenanceOperatorId;
	}

	/**
	 * @param lastMaintenanceOperatorId
	 *            the lastMaintenanceOperatorId to set
	 */
	public void setLastMaintenanceOperatorId(String lastMaintenanceOperatorId) {
		this.lastMaintenanceOperatorId = lastMaintenanceOperatorId;
	}

	/**
	 * @return the ivrMutualFundCategoryId
	 */
	public Integer getIvrMutualFundCategoryId() {
		return ivrMutualFundCategoryId;
	}

	/**
	 * @param ivrMutualFundCategoryId
	 *            the ivrMutualFundCategoryId to set
	 */
	public void setIvrMutualFundCategoryId(Integer ivrMutualFundCategoryId) {
		this.ivrMutualFundCategoryId = ivrMutualFundCategoryId;
	}

	/**
	 * @return the ivrFundNm
	 */
	public String getIvrFundNm() {
		return ivrFundNm;
	}

	/**
	 * @param ivrFundNm
	 *            the ivrFundNm to set
	 */
	public void setIvrFundNm(String ivrFundNm) {
		this.ivrFundNm = ivrFundNm;
	}

	/**
	 * @return the ivrFundCatNm
	 */
	public String getIvrFundCatNm() {
		return ivrFundCatNm;
	}

	/**
	 * @param ivrFundCatNm the ivrFundCatNm to set
	 */
	public void setIvrFundCatNm(String ivrFundCatNm) {
		this.ivrFundCatNm = ivrFundCatNm;
	}

	/**
	 * @return the activityCd
	 */
	public boolean isActivityCd() {
		return activityCd;
	}

	/**
	 * @param activityCd the activityCd to set
	 */
	public void setActivityCd(boolean activityCd) {
		this.activityCd = activityCd;
	}

	/**
	 * @return the transferNumId
	 */
	public Integer getTransferNumId() {
		return transferNumId;
	}

	/**
	 * @param transferNumId the transferNumId to set
	 */
	public void setTransferNumId(Integer transferNumId) {
		this.transferNumId = transferNumId;
	}

	/**
	 * @return the transferNumNm
	 */
	public String getTransferNumNm() {
		return transferNumNm;
	}

	/**
	 * @param transferNumNm the transferNumNm to set
	 */
	public void setTransferNumNm(String transferNumNm) {
		this.transferNumNm = transferNumNm;
	}

	/**
	 * @return the ivrFundCd
	 */
	public Integer getIvrFundCd() {
		return ivrFundCd;
	}

	/**
	 * @param ivrFundCd the ivrFundCd to set
	 */
	public void setIvrFundCd(Integer ivrFundCd) {
		this.ivrFundCd = ivrFundCd;
	}

}
