/*
 * FILE : AdminSessionService.java
 *
 * CLASS : AdminSessionService
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.session.service;

import javax.servlet.http.HttpSession;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Service;

import com.dstsystems.ivradmin.auth.domain.Associate;
import com.dstsystems.ivradmin.session.domain.AdminSessionAttributes;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * The code for this service comes from the IVRSessionService class found in the ivr-core project. It has been modified slightly to adjust for the Admin Tool needs.
 * @author dt63314
 *
 */
@Service
@Slf4j
public class AdminSessionService
{
    @Getter
    private AdminSessionAttributes attributes;
    
    /*
     * Note: Autowired annotation not required, Spring 4.3+++ supports implicit constructor injection.
     */
    public AdminSessionService( AdminSessionAttributes attributes )
    {
        this.attributes = attributes;
    }
    
    /**
     * Adds the associates ID to 
     * @param session
     * @param associate
     * @return
     */
    public boolean createSession( HttpSession session,
                                  @NotNull Associate associate )
    {
        setSessionAttributes( associate );
        log.debug( "Session {} initiated for associateId {}", session.getId(), associate.getId() );
        return true;
        
    }
    
    /**
     * Invalidates the given session, disallowing future activity or requests.
     * @param session
     */
    public void destroySession( HttpSession session )
    {
        session.invalidate();
    }
    
    /**
     * Adds the given Associate to the session bean.
     * @param associate
     */
    private void setSessionAttributes( Associate associate )
    {
        attributes.setAssociate( associate );
    }
}
