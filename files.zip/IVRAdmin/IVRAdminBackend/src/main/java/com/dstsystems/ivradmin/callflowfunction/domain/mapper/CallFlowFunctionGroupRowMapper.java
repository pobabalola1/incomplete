package com.dstsystems.ivradmin.callflowfunction.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.callflowfunction.domain.CallFlowFunctionGroup;

public class CallFlowFunctionGroupRowMapper implements
                                            RowMapper<CallFlowFunctionGroup>
{
    
    private final String CALL_FLOW_ID                 = "CALL_FLOW_ID";
    private final String FUNCTION_GROUP_ID            = "FUNCTION_GROUP_ID";
    private final String FUNCTION_GROUP_NM            = "FUNCTION_GROUP_NM";
    private final String LAST_MAINTENANCE_OPERATOR_ID = "LAST_MAINTENANCE_ID";
    
    @Override
    public CallFlowFunctionGroup mapRow( ResultSet rs,
                                         int rowNum ) throws SQLException
    {
        CallFlowFunctionGroup callFlowFunctionGroup = new CallFlowFunctionGroup();
        callFlowFunctionGroup.setCallFlowId( rs.getInt( CALL_FLOW_ID ) );
        callFlowFunctionGroup.setFunctionGrpId( rs.getInt( FUNCTION_GROUP_ID ) );
        callFlowFunctionGroup.setFunctionGrpName( ( rs.getString( FUNCTION_GROUP_NM ) ) );
        callFlowFunctionGroup.setLastMaintenanceOperatorId( rs.getString( LAST_MAINTENANCE_OPERATOR_ID ) );
        return callFlowFunctionGroup;
    }
    
}
