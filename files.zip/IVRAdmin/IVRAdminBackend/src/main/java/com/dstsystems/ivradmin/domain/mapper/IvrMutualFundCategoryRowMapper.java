package com.dstsystems.ivradmin.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.fund.domain.IvrMutualFundCategory;

public class IvrMutualFundCategoryRowMapper implements RowMapper<IvrMutualFundCategory> {

	private final String IVR_MUTUAL_FUND_CATEGORY_ID = "IVR_MUTUAL_FUND_CATEGORY_ID";	
	private final String IVR_CATEGORY_NM = "IVR_CATEGORY_NM";
	private final String CALL_FLOW_ID = "CALL_FLOW_ID";
	private final String LAST_MAINTENANCE_ID = "LAST_MAINTENANCE_ID";
	private final String FUND_COUNT = "FUND_CNT";
	
	@Override
	public IvrMutualFundCategory mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		IvrMutualFundCategory ivrMutualFundCategory = new IvrMutualFundCategory();
		ivrMutualFundCategory.setIvrMutualFundCategoryId( rs.getInt( IVR_MUTUAL_FUND_CATEGORY_ID ) );
		ivrMutualFundCategory.setLastMaintenanceOperatorId( rs.getString( LAST_MAINTENANCE_ID ) );
		ivrMutualFundCategory.setIvrMutualFundCategoryNm( rs.getString( IVR_CATEGORY_NM ) );
		ivrMutualFundCategory.setCallFlowId( rs.getInt( CALL_FLOW_ID ) );
		ivrMutualFundCategory.setFundCnt( rs.getInt(FUND_COUNT));
		return ivrMutualFundCategory;
	}
	
}
