/**
 * 
 */
package com.dstsystems.ivradmin.dao;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.core.domain.CallFlow;
import com.dstsystems.ivradmin.domain.LineOfBusinessClient;
import com.dstsystems.ivradmin.domain.mapper.LineOfBusinessClientRowMapper;

@Repository
public class LineOfBusinessClientDaoImpl extends BaseJdbcDAO
{
    private static final String        LINE_OF_BUSINESS_ID    = "LINE_OF_BUSINESS_ID";
    
    private static final StringBuilder GET_ALL                = new StringBuilder().append( " select      lobc.IVR_CLIENT_ID, lobc.LINE_OF_BUSINESS_ID, lobc.FUND_SPONSOR_ID, lobc.IVR_CLIENT_NM, lobc.SYSTEM_ID " )
                                                                                   .append( " from       LINE_OF_BUSINESS_CLIENT lobc " );
    
    
    private static final StringBuilder GET_ALL_LOBC_BY_LOB_ID = new StringBuilder().append( " select      lobc.IVR_CLIENT_ID, lobc.LINE_OF_BUSINESS_ID, lobc.FUND_SPONSOR_ID, lobc.IVR_CLIENT_NM, lobc.SYSTEM_ID " )
                                                                                   .append( " from       LINE_OF_BUSINESS_CLIENT lobc " )
                                                                                   .append( " where lobc.LINE_OF_BUSINESS_ID = :LINE_OF_BUSINESS_ID " );
    
    private final static Logger        LOG                    = LoggerFactory.getLogger( LineOfBusinessClientDaoImpl.class );
    
    
    @Autowired
    private DnisDaoImpl                dnisDao;
    
    public List<LineOfBusinessClient> getAll()
    {
        List<LineOfBusinessClient> lineOfBusinessClientList = null;
        try
        {
            lineOfBusinessClientList = getNamedParameterJdbcOperations().query( GET_ALL.toString(),
                                                                                new LineOfBusinessClientRowMapper() );
            
            for( LineOfBusinessClient lineOfBusinessClient : lineOfBusinessClientList )
            {
                lineOfBusinessClient.setCallFlow( dnisDao.getAllDnisByLineOfBusinessClientId( lineOfBusinessClient.getIvrClientId() ) );
            }
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        
        return lineOfBusinessClientList;
    }
    
    public List<LineOfBusinessClient> getAllLineOfBusinessClientByLineOfBusinessId( int lineOfBusinessId,
                                                                                    int callFlowStatus )
    {
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( LINE_OF_BUSINESS_ID,
                                                                              lineOfBusinessId );
        List<LineOfBusinessClient> lineOfBusinessClientList = null;
        try
        {
            lineOfBusinessClientList = getNamedParameterJdbcOperations().query( GET_ALL_LOBC_BY_LOB_ID.toString(),
                                                                                parameters,
                                                                                new LineOfBusinessClientRowMapper() );
            
            Set<Integer> ivrClientIds = lineOfBusinessClientList.stream()
                                                                .map( e -> e.getIvrClientId() )
                                                                .collect( Collectors.toSet() );
            
            List<CallFlow> callFlowList = dnisDao.getAllDnisByLineOfBusinessClientIds( ivrClientIds,
                                                                                       callFlowStatus );
            
            for( LineOfBusinessClient lineOfBusinessClient : lineOfBusinessClientList )
            {
                lineOfBusinessClient.setCallFlow( callFlowList.stream()
                                                              .filter( e -> e.getIvrClientId()
                                                                             .equals( lineOfBusinessClient.getIvrClientId() ) )
                                                              .collect( Collectors.toList() ) );
            }
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return lineOfBusinessClientList;
    }
}
