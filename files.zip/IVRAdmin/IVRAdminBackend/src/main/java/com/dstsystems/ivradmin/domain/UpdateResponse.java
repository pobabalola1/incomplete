package com.dstsystems.ivradmin.domain;

public class UpdateResponse
{
    private boolean sqlSuccess;
    private int     updateCnt;
    private String  errorCode;
    private String  errorMsg;
    
    /**
     * @return the sqlSuccess
     */
    public boolean isSqlSuccess()
    {
        return sqlSuccess;
    }
    
    /**
     * @param sqlSuccess the sqlSuccess to set
     */
    public void setSqlSuccess( boolean sqlSuccess )
    {
        this.sqlSuccess = sqlSuccess;
    }
    
    /**
     * @return the updateCnt
     */
    public int getUpdateCnt()
    {
        return updateCnt;
    }
    
    /**
     * @param updateCnt the updateCnt to set
     */
    public void setUpdateCnt( int updateCnt )
    {
        this.updateCnt = updateCnt;
    }
    
    /**
     * @return the errorCode
     */
    public String getErrorCode()
    {
        return errorCode;
    }
    
    /**
     * @param errorCode the errorCode to set
     */
    public void setErrorCode( String errorCode )
    {
        this.errorCode = errorCode;
    }
    
    /**
     * @return the errorMsg
     */
    public String getErrorMsg()
    {
        return errorMsg;
    }
    
    /**
     * @param errorMsg the errorMsg to set
     */
    public void setErrorMsg( String errorMsg )
    {
        this.errorMsg = errorMsg;
    }
    
}
