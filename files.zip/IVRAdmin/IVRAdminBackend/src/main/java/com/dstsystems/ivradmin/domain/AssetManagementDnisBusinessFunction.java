package com.dstsystems.ivradmin.domain;

import java.util.Date;

public class AssetManagementDnisBusinessFunction {

	private Integer dnisId;
	private Integer businessFunctionId; 
	private Date lastMaintenanceTimestamp;
	private String lastMaintenanceId;
	private Integer assetManagementDNISTransferNumberId;
	
	/**
	 * @return the dnisId
	 */
	public Integer getDnisId() {
		return dnisId;
	}

	/**
	 * @param dnisId
	 *            the dnisId to set
	 */
	public void setDnisId(Integer dnisId) {
		this.dnisId = dnisId;
	}

	/**
	 * @return the businessFunctionId
	 */
	public Integer getBusinessFunctionIdprivate() {
		return businessFunctionId;
	}

	/**
	 * @param businessFunctionId
	 *            the businessFunctionId to set
	 */
	public void setBusinessFunctionIdprivate(Integer businessFunctionIdprivate) {
		this.businessFunctionId = businessFunctionIdprivate;
	}

	/**
	 * @return the lastMaintenanceTimestamp
	 */
	public Date getLastMaintenanceTimestamp() {
		return lastMaintenanceTimestamp;
	}

	/**
	 * @param lastMaintenanceTimestamp
	 *            the lastMaintenanceTimestamp to set
	 */
	public void setLastMaintenanceTimestamp(Date lastMaintenanceTimestamp) {
		this.lastMaintenanceTimestamp = lastMaintenanceTimestamp;
	}

	/**
	 * @return the lastMaintenanceId
	 */
	public String getLastMaintenanceId() {
		return lastMaintenanceId;
	}

	/**
	 * @param lastMaintenanceId
	 *            the lastMaintenanceId to set
	 */
	public void setLastMaintenanceId(String lastMaintenanceId) {
		this.lastMaintenanceId = lastMaintenanceId;
	}

	/**
	 * @return the assetManagementDNISTransferNumberId
	 */
	public Integer getAssetManagementDNISTransferNumberId() {
		return assetManagementDNISTransferNumberId;
	}

	/**
	 * @param assetManagementDNISTransferNumberId
	 *            the assetManagementDNISTransferNumberId to set
	 */
	public void setAssetManagementDNISTransferNumberId(Integer assetManagementDNISTransferNumberId) {
		this.assetManagementDNISTransferNumberId = assetManagementDNISTransferNumberId;
	}
	
}
