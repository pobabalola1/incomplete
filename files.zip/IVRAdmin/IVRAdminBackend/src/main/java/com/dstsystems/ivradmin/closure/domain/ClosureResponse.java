package com.dstsystems.ivradmin.closure.domain;


import lombok.Builder;
import lombok.Data;

/**
 * @author dt77649
 *
 */

@Data
@Builder
public class ClosureResponse {
	
	private String codeRes;
	private String textRes;
	private Boolean isSuccess;
}
