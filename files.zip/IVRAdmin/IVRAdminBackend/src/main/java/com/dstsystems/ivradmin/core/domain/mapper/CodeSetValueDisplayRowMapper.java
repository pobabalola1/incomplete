package com.dstsystems.ivradmin.core.domain.mapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.dstsystems.ivradmin.core.domain.CodeSetValueDisplay;

@Component
public class CodeSetValueDisplayRowMapper implements RowMapper< CodeSetValueDisplay > {

    private final String CODE_SET_VALUE_ID              = "CODE_SET_VALUE_ID";
    private final String CODE_SET_VALUE_NM              = "CODE_SET_VALUE_NM";
    private final String CODE_SET_VALUE_ABBREVIATED_NM  = "CODE_SET_VALUE_ABBREVIATED_NM";
    private final String DESCRIPTION_TXT                = "DESCRIPTION_TXT";
    
    private final String CSV_EXPIRATION_DT              = "CSV_EXPIRATION_DT";
    private final String CS_EXPIRATION_DT               = "CS_EXPIRATION_DT";
        
	@Override
	public CodeSetValueDisplay mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
	   
	   Date csvExDate      = rs.getDate( CSV_EXPIRATION_DT );
	   Date csExDate       = rs.getDate( CS_EXPIRATION_DT );
	   Date todayDate      = new Date( Calendar.getInstance().getTimeInMillis() );
	   
	   //Check if the value is expired.
	   boolean isExpired   = false; 
	         
	   if ( csvExDate != null || csExDate != null ) 
	   {
	      if ( csExDate != null ) 
	      {
	         isExpired = todayDate.compareTo( csExDate ) > 0;
	      }
	      else if ( csvExDate != null ) 
	      {
	         isExpired = todayDate.compareTo( csvExDate ) > 0;
	      } 
	   }   
	       
	   
	   CodeSetValueDisplay csvd = CodeSetValueDisplay.builder()
	                                 .id(              rs.getInt( CODE_SET_VALUE_ID ) )
	                                 .name(            rs.getString( CODE_SET_VALUE_NM ) )
	                                 .abbreviatedName( rs.getString( CODE_SET_VALUE_ABBREVIATED_NM ) )
	                                 .descriptionText( rs.getString( DESCRIPTION_TXT ) )
	                                 .isExpired( isExpired )
	                                 .build();
	   
	                                 
	   return csvd;
	}	
	
}
