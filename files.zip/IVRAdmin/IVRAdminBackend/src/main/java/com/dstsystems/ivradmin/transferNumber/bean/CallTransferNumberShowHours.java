package com.dstsystems.ivradmin.transferNumber.bean;

import lombok.Data;

/**
 * Bean that will keep CallTransferNumber data from Backend to Frontend for display.
 * 
 * @author dt77649
 */
@Data
public class CallTransferNumberShowHours {
	private String dateStart;
	private String dateEnd;
	private String timeStart;
	private String timeEnd;
}
