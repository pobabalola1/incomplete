package com.dstsystems.ivradmin.callflowfunction.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.callflowfunction.domain.BusinessFunction;

public class BusinessFunctionRowMapper implements RowMapper<BusinessFunction> {
	
	private final String FUNCTION_ID = "FUNCTION_ID";
	private final String LAST_MAINTENANCE_OPERATOR_ID = "LAST_MAINTENANCE_OPERATOR_ID";
	private final String FUNCTION_NM = "FUNCTION_NM";
	private final String LINE_OF_BUSINESS_ID = "LINE_OF_BUSINESS_ID";
	
	@Override
	public BusinessFunction mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		BusinessFunction businessFunction = new BusinessFunction();
		businessFunction.setFunctionId( rs.getInt( FUNCTION_ID ) );
		businessFunction.setLastMaintenanceOperatorId( rs.getString( LAST_MAINTENANCE_OPERATOR_ID ) );
		businessFunction.setFunctionNm( rs.getString( FUNCTION_NM ) );
		businessFunction.setLineOfBusinessId( rs.getInt( LINE_OF_BUSINESS_ID ) );
		return businessFunction;
	}
}
