package com.dstsystems.ivradmin.domain;

import java.util.ArrayList;
import java.util.List;

public class LineOfBusiness
{
   private Integer lineOfBusinessId;
   private String  lineOfBusinessName;
   private List<LineOfBusinessClient> lineOfBusinessClients = new ArrayList< LineOfBusinessClient >();
   
   public Integer getLineOfBusinessId()
   {
      return lineOfBusinessId;
   }

   public void setLineOfBusinessId( Integer lineOfBusinessId )
   {
      this.lineOfBusinessId = lineOfBusinessId;
   }

   public String getLineOfBusinessName()
   {
      return lineOfBusinessName;
   }

   public void setLineOfBusinessName( String lineOfBusinessNm )
   {
      this.lineOfBusinessName = lineOfBusinessNm;
   }

   /**
    * @return the lineOfBusinessClients
    */
   public List<LineOfBusinessClient> getLineOfBusinessClients()
   {
      return lineOfBusinessClients;
   }

   /**
    * @param lineOfBusinessClients the lineOfBusinessClients to set
    */
   public void setLineOfBusinessClients( List<LineOfBusinessClient> lineOfBusinessClients )
   {
      this.lineOfBusinessClients = lineOfBusinessClients;
   }
}
