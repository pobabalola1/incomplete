package com.dstsystems.ivradmin.fund.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.dao.BaseJdbcDAO;
import com.dstsystems.ivradmin.domain.mapper.MutualFundDnisBusinessFunctionRowMapper;
import com.dstsystems.ivradmin.fund.domain.MutualFundDnisBusinessFunction;

@Repository
public class MutualFundDnisBusinessFunctionDaoImpl extends BaseJdbcDAO {

	
	private static final String DNIS_ID     = "DNIS_ID";//Primary Key
	private static final String FUNCTION_ID = "IVR_MUTUAL_FUND_ID";//Primary Key
	private static final String IVR_MUTUAL_FUND_ID     = "DNIS_ID";//Primary Key
	
	private static final StringBuilder GET_ALL = new StringBuilder()
			.append(" select     MFDBF.DNIS_ID, MFDBF.IVR_MUTUAL_FUND_ID, MFDBF.FUNCTION_ID, MFDBF.LAST_MAINTENANCE_OPERATOR_ID ")
			.append(" from       MUTUAL_FUND_DNIS_BUSINESS_FUNCTION MFDBF ");
	
	private final static Logger     LOG = LoggerFactory.getLogger( MutualFundDnisBusinessFunctionDaoImpl.class );
	 
	public List< MutualFundDnisBusinessFunction > getAll()
    {
      List< MutualFundDnisBusinessFunction > mutualFundDnisBusinessFunctionList = null;
      try 
      {
    	  mutualFundDnisBusinessFunctionList = getNamedParameterJdbcOperations().query( GET_ALL.toString(), new MutualFundDnisBusinessFunctionRowMapper() );
      }
      catch( Exception e )
      {
    	  LOG.error( e.getMessage() );
      }
      return mutualFundDnisBusinessFunctionList;
    }
		
}
