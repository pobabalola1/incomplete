package com.dstsystems.ivradmin.transferNumber.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.dstsystems.ivradmin.transferNumber.bean.CallTransferNumberShowHours;


/**
 * Mapping data to show date-time for Call transfer NUmber  
 * 
 * @author DT77649
 */
public class OpenCloseDateRowMapper implements RowMapper<CallTransferNumberShowHours> {
	
	private final String openTime = "OPEN_TM";
	private final String closedTime = "CLOSED_TM";
	private final String CODE_SET_VALUE_ABBREVIATED_NM = "CODE_SET_VALUE_ABBREVIATED_NM";

	/**
     * getting Call Transfer Number data.
     *  
     * @param rs - ResultSet from DB
     * @param rowNum - index to get row data
     * @return CallTransferNumberShowHours list
     */
	@Override
	public CallTransferNumberShowHours mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		CallTransferNumberShowHours dnisCallTransferNumberShowHours = new CallTransferNumberShowHours();
		dnisCallTransferNumberShowHours.setTimeStart( rs.getString( openTime ) ) ;
		dnisCallTransferNumberShowHours.setTimeEnd( rs.getString( closedTime ) ) ;
		dnisCallTransferNumberShowHours.setDateStart( rs.getString( CODE_SET_VALUE_ABBREVIATED_NM ) );
		dnisCallTransferNumberShowHours.setDateEnd( rs.getString( CODE_SET_VALUE_ABBREVIATED_NM ) );
		return dnisCallTransferNumberShowHours;
	}
}
