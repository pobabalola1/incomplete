/*
 * FILE : LoginRequest.java
 *
 * CLASS : LoginRequest
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.auth.domain;

import javax.validation.constraints.NotNull;

import lombok.Data;

/**
 * Login Request bean containing user's name, password and the LDAP domain name
 * (i.e. wss-master)
 * 
 * @author DT63314
 */
@Data
public class LoginRequest
{
    @NotNull
    private String userName;
    
    @NotNull
    private String password;

    @NotNull
    private String domain;
    
    
}
