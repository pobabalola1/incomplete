/*
 * FILE : GlobalDetailsDnisService.java
 *
 * CLASS : GlobalDetailsDnisService
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by DST Systems, Inc., are proprietary in nature and as such are
 * confidential. Any unauthorized use or disclosure of such information may result in civil liabilities.
 *
 * Copyright 2018 by DST Systems, Inc. All Rights Reserved.
 */
package com.dstsystems.ivradmin.core.service;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.validation.annotation.Validated;

import com.dstsystems.ivradmin.core.domain.DnisNavigationCache;
import com.dstsystems.ivradmin.core.exception.DaoException;
import com.dstsystems.ivradmin.core.service.impl.DnisNavigationServiceImpl;

/**
 * Exposes an API for retrieving Global Detail information from {@link DnisNavigationServiceImpl}.
 * @author dt63314
 *
 */
@Validated
public interface GlobalDetailsDnisService
{
    /**
     * Returns the DnisNavigationCache for the given DNIS. While a DNIS may have one to many call flow ids in
     * various states, the configuration files tied to a call flow exists once per call flow. The DaoException
     * will be thrown for any resource access errors and contains additional messaging to aid in identifying
     * the cause of the error.
     * 
     * @param dnis the dnis for the wanted details.
     * @return the navigation information if available, or null.
     * @throws DaoException thrown for errors encountered attempting to handle resources.
     */
    public DnisNavigationCache getDnisNavigation( @NotBlank String dnis ) throws DaoException;
}
