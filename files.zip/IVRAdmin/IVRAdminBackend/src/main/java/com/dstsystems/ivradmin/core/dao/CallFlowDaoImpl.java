package com.dstsystems.ivradmin.core.dao;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.dstsystems.ivradmin.core.domain.CallFlow;
import com.dstsystems.ivradmin.core.domain.CallFlowExt;
import com.dstsystems.ivradmin.core.domain.mapper.CallFlowExtRowMapper;
import com.dstsystems.ivradmin.core.domain.mapper.CallFlowRowMapper;
import com.dstsystems.ivradmin.core.exception.DaoException;
import com.dstsystems.ivradmin.dao.GlobalDetailsDao;
import com.dstsystems.ivradmin.globaldetail.domain.CallFlowGlobalDetail;
import com.dstsystems.ivradmin.globaldetail.domain.mapper.CallFlowGlobalDetailMapper;

import lombok.extern.slf4j.Slf4j;

@Repository
@Primary
@Slf4j
public class CallFlowDaoImpl extends BaseJdbcDAO implements GlobalDetailsDao
{
    @Autowired
    private CallFlowRowMapper          callFlowMapper;
    
    @Autowired
    private CallFlowExtRowMapper       callFlowExtMapper;
    
    private static final String        CALL_FLOW_ID                  = "CALL_FLOW_ID";                                                                                                 //Primary Key
    private static final String        IVR_CLIENT_ID                 = "IVR_CLIENT_ID";                                                                                                //Foreign Key
    private static final String        IVR_CLIENT_IDS                = "IVR_CLIENT_IDS";
    public static final String         DNIS_NBR                      = "DNIS_NBR";
    public static final String         CALL_FLOW_STATUS_CVID         = "CALL_FLOW_STATUS_CVID";
    public static final String         CALL_FLOW_DESCRIPTION_TXT     = "CALL_FLOW_DESCRIPTION_TXT";
    public static final String         ACCOUNT_GROUP_METHOD_TXT      = "ACCOUNT_GROUP_METHOD_TXT";
    
    private static final StringBuilder GET_ALL                       = new StringBuilder().append( "select CF.CALL_FLOW_ID," )
                                                                                          .append( " CF.DNIS_NBR," )
                                                                                          .append( " CF.IVR_CLIENT_ID " )
                                                                                          .append( "from CALL_FLOW CF " );
    
    private static final StringBuilder GET_ALL_DNIS_BY_CLIENT_ID     = new StringBuilder().append( GET_ALL )
                                                                                          .append( "where CF.IVR_CLIENT_ID = :IVR_CLIENT_ID" );
    
    private static final StringBuilder GET_ALL_DNIS_BY_IN_CLIENT_IDS = new StringBuilder().append( GET_ALL )
                                                                                          .append( "where CF.IVR_CLIENT_ID IN (:IVR_CLIENT_IDS)" );
    
    
    private static final StringBuilder GET_ALL_EXT                   = new StringBuilder().append( "select CF.CALL_FLOW_ID, " )
                                                                                          .append( " CF.IVR_CLIENT_ID, " )
                                                                                          .append( " CF.DNIS_NBR, " )
                                                                                          .append( " CF.CALL_FLOW_STATUS_CVID, " )
                                                                                          .append( "CF.ALWAYS_TRANSFER_IND, " )
                                                                                          .append( "CF.ALWAYS_TRANSFER_STOP_MAIL_IND, " )
                                                                                          .append( "CF.USE_EXTERNAL_PIN_IND, " )
                                                                                          .append( "CF.USER_AUTHENTICATION_METHOD_CVID, " )
                                                                                          .append( "CF.ACCOUNT_GROUP_METHOD_CVID, " )
                                                                                          .append( "CF.TRANSFER_CLOSED_RECORDING_ID " )
                                                                                          .append( "from CALL_FLOW CF" );
    
    private static final StringBuilder GET_EXT_BY_CALL_FLOW_ID       = new StringBuilder().append( GET_ALL_EXT.toString() )
                                                                                          .append( " " )
                                                                                          .append( "where      CF.CALL_FLOW_ID = :CALL_FLOW_ID" );
    
    private static final StringBuilder GET_EXT_BY_CLIENT_ID_DNIS_NBR = new StringBuilder().append( GET_ALL_EXT.toString() )
                                                                                          .append( " " )
                                                                                          .append( "where      CF.DNIS_NBR = :DNIS_NBR and" )
                                                                                          .append( "           CF.IVR_CLIENT_ID = :IVR_CLIENT_ID" );
    
    private static final String        CALL_FLOW_GLOBAL_DETAIL       = new StringBuilder().append( "select " )
                                                                                          .append( " CF.".concat( DNIS_NBR )
                                                                                                         .concat( "," ) )
                                                                                          .append( " CF.".concat( CALL_FLOW_STATUS_CVID )
                                                                                                         .concat( "," ) )
                                                                                          .append( " CF.".concat( CALL_FLOW_DESCRIPTION_TXT )
                                                                                                         .concat( "," ) )
                                                                                          .append( " coalesce( CSV.CODE_SET_VALUE_NM , \"\" ) as ".concat( ACCOUNT_GROUP_METHOD_TXT ) )
                                                                                          .append( " from CALL_FLOW CF" )
                                                                                          .append( " left outer join" )
                                                                                          .append( " CODE_SET_VALUE CSV" )
                                                                                          .append( " on CF.ACCOUNT_GROUP_METHOD_CVID = CSV.CODE_SET_VALUE_ID" )
                                                                                          .append( " where CF.CALL_FLOW_ID = :CALL_FLOW_ID" )
                                                                                          .toString();
    
    private final static Logger        LOG                           = LoggerFactory.getLogger( CallFlowDaoImpl.class );
    
    
    public List<CallFlow> getAll()
    {
        List<CallFlow> callFlowList = null;
        try
        {
            callFlowList = getNamedParameterJdbcOperations().query( GET_ALL.toString(),
                                                                    callFlowMapper );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callFlowList;
    }
    
    public List<CallFlow> getAllDnisByLineOfBusinessClientId( int lineOfBusinessClientId )
    {
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( IVR_CLIENT_ID,
                                                                              lineOfBusinessClientId );
        List<CallFlow> callFlowList = null;
        try
        {
            callFlowList = getNamedParameterJdbcOperations().query( GET_ALL_DNIS_BY_CLIENT_ID.toString(),
                                                                    parameters,
                                                                    callFlowMapper );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callFlowList;
    }
    
    public List<CallFlow> getAllDnisByLineOfBusinessClientIds( Set<Integer> lineOfBusinessClientIds )
    {
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( IVR_CLIENT_IDS,
                                                                              lineOfBusinessClientIds );
        List<CallFlow> callFlowList = null;
        try
        {
            callFlowList = getNamedParameterJdbcOperations().query( GET_ALL_DNIS_BY_IN_CLIENT_IDS.toString(),
                                                                    parameters,
                                                                    callFlowMapper );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callFlowList;
    }
    
    public List<CallFlowExt> getAllExt()
    {
        List<CallFlowExt> callflowList = null;
        try
        {
            callflowList = getNamedParameterJdbcOperations().query( GET_ALL_EXT.toString(),
                                                                    callFlowExtMapper );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        return callflowList;
    }
    
    public CallFlowExt getExtByCallFlowId( Integer callFlowId )
    {
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                              callFlowId );
        
        return queryExtWithParam( GET_EXT_BY_CALL_FLOW_ID.toString(),
                                  parameters );
    }
    
    public CallFlowExt getExtByClientIdDnisNumber( Integer clientId,
                                                   String dnisNbr )
    {
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( DNIS_NBR,
                                                                              dnisNbr )
                                                                   .addValue( IVR_CLIENT_ID,
                                                                              clientId );
        
        return queryExtWithParam( GET_EXT_BY_CLIENT_ID_DNIS_NBR.toString(),
                                  parameters );
    }
    
    /**
    * @param parameters
    * @return
    */
    private CallFlowExt queryExtWithParam( String sql,
                                           SqlParameterSource parameters )
    {
        CallFlowExt callflowExt = null;
        try
        {
            callflowExt = getNamedParameterJdbcOperations().queryForObject( sql,
                                                                            parameters,
                                                                            callFlowExtMapper );
        }
        catch( Exception e )
        {
            LOG.error( e.getMessage() );
        }
        
        return callflowExt;
    }
    
    /* (non-Javadoc)
     * @see com.dstsystems.ivradmin.dao.GlobalDetailsDao#getCallFlowFor(java.math.BigInteger)
     */
    @Override
    public CallFlowGlobalDetail getGlobalDetails( BigInteger callFlowId ) throws DaoException
    {
        CallFlowGlobalDetail callFlowGlobalDetail = null;
        
        SqlParameterSource parameters = new MapSqlParameterSource().addValue( CALL_FLOW_ID,
                                                                              callFlowId.toString() );
        
        try
        {
            callFlowGlobalDetail = getNamedParameterJdbcOperations().queryForObject( CALL_FLOW_GLOBAL_DETAIL,
                                                                                     parameters,
                                                                                     new CallFlowGlobalDetailMapper() );
        }
        catch( IncorrectResultSizeDataAccessException ex )
        {
            String message = new StringBuilder().append( "Call flow id [" )
                                                .append( callFlowId.toString() )
                                                .append( "] returned " )
                                                .append( String.valueOf( ex.getActualSize() ) )
                                                .append( " records. 1 was expected." )
                                                .toString();
            log.error( ex.getMessage() );
            throw new DaoException( message, ex );
            
            
        }
        catch( Exception ex )
        {
            log.error( ex.getMessage() );
        }
        
        return callFlowGlobalDetail;
    }
}
