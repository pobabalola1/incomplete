package com.dstsystems.ivradmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dstsystems.ivradmin.fund.dao.MutualFundDnisBusinessFunctionDaoImpl;
import com.dstsystems.ivradmin.fund.domain.MutualFundDnisBusinessFunction;

@RestController
public class MutualFundDnisBusinessFunctionController {
	
   @Autowired
   private MutualFundDnisBusinessFunctionDaoImpl mutualFundDnisBusinessFunctionDaoImpl;

   @RequestMapping(path = "/api/data/mutual-fund-dnis-business-functions" ,method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
   @ResponseBody
   public List< MutualFundDnisBusinessFunction > getAll() 
   {
      return mutualFundDnisBusinessFunctionDaoImpl.getAll();
   }
	
}

